package com.uestc.circuit_simulator

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    companion object {
        private const val NGSPICE_CHANNEL = "circuit_simulator/ngspice"
        private const val NATIVE_UNAVAILABLE =
            "当前尚未接入 ngspice 原生库，已自动使用本地 Dart MNA 求解器。"
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            NGSPICE_CHANNEL,
        ).setMethodCallHandler { call, result ->
            when (call.method) {
                "runNetlist" -> {
                    val netlist = call.argument<String>("netlist")
                    if (netlist.isNullOrBlank()) {
                        result.error("EMPTY_NETLIST", "SPICE 网表为空，无法执行仿真。", null)
                    } else {
                        // 课程演示版本尚未打包 libngspice.so。保留稳定的原生通道，
                        // 后续接入库后在此执行网表并返回 ngspice 文本输出。
                        result.success(NATIVE_UNAVAILABLE)
                    }
                }

                else -> result.notImplemented()
            }
        }
    }
}
