package com.uestc.circuit_simulator

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {
    private val CHANNEL = "circuit_simulator/ngspice"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            if (call.method == "runNetlist") {
                val netlist = call.argument<String>("netlist")
                // 这里未来将接入真实的 ngspice 原生库
                // 目前返回一个提示信息，告知已连接到 Android 原生端
                result.success("Android Native: Ngspice engine initialized. Netlist received (length: ${netlist?.length ?: 0}). \nNote: Actual simulation requires native libngspice.so which is not yet bundled.")
            } else {
                result.notImplemented()
            }
        }
    }
}
