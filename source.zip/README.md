# 电路仿真 APP

## 项目简介

电路仿真 APP 是一个基于 Flutter 的电路搭建与仿真教学软件原型。项目面向课程作业演示场景，提供电路元件放置、连线、参数编辑、SPICE 网表生成和仿真结果波形展示等功能，用于帮助用户理解基础电路结构和仿真流程。

当前版本已经完成从前端画布到 SPICE 网表生成，再到仿真结果展示的基本闭环。项目中已预留 ngspice 原生接口；在当前演示阶段，主要使用 Mock 仿真器生成演示波形，不应理解为已经完整接入真实 ngspice 求解器。

## 主要功能

- 电路元件放置
- 元件拖拽、旋转和改名
- 引脚连线与连线删除
- 电阻、电容、电感、电压源、LED、GND、电压表、电流表、开关等元件支持
- 参数编辑和单位输入
- 内置示例电路
- SPICE/ngspice 风格网表生成
- 仿真结果波形展示
- 电路保存、打开和分享

## 当前版本说明

- 已实现 `CanvasState.components` 和 `CanvasState.wires` 到内部 `CircuitModel` 的转换。
- 已实现 SPICE 网表生成和仿真接口封装。
- 已预留 `NativeNgspiceSimulator` 原生接口，后续可通过接入 ngspice 原生库实现真实电路求解。
- 当前演示阶段默认可回退到 `MockSpiceSimulator`，用于保证波形展示流程可运行。
- 当前版本主要面向 Android / 桌面端演示，部分文件操作依赖 `dart:io`，Web 端兼容性需要后续适配。

## 运行方式

```bash
flutter pub get
flutter analyze
flutter test
flutter run
```

如果运行 Android 项目，请确保本机已安装 Android SDK，并已在本机 Flutter 环境中重新生成 `android/local.properties` 等本地配置文件。

## 项目结构说明

```text
lib/
  main.dart                       应用入口和主界面
  models/                         元件、连线和电路数据模型
  state/                          画布状态管理
  widgets/                        画布、工具栏、属性面板和波形显示组件
  services/                       电路存储、内置案例、网表生成和映射服务
  spice/                          SPICE 模型、仿真配置、结果、Mock/Native 仿真器

test/
  spice_core_test.dart            单元测试，覆盖单位解析、网表生成、错误检查和仿真结果序列化

android/ ios/ linux/ macos/ web/ windows/
  Flutter 多平台工程目录
```

## 后续优化方向

- 接入真实 ngspice 原生库
- 完善 MNA 求解能力
- 增强电路合法性检查
- 支持更多电路元件和模型
- 优化移动端拖拽、缩放和连线交互体验
- 完善 Web 端文件操作适配

## 答辩定位

本项目应定位为“基于 Flutter 的电路仿真教学 APP 原型”。当前版本实现了电路搭建、参数编辑、SPICE 网表生成、仿真接口预留和 Mock 波形展示，已经形成从用户操作到结果展示的基本闭环，但还不是专业级真实 SPICE 仿真器。
