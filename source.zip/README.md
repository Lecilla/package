# 电路仿真 APP

## 项目简介

电路仿真 APP 是一个基于 Flutter 的电路搭建与仿真教学软件原型。项目面向课程作业演示场景，提供电路元件放置、连线、参数编辑、SPICE 网表生成和仿真结果波形展示等功能，用于帮助用户理解基础电路结构和仿真流程。

当前版本已经完成从前端画布、SPICE 网表生成、本地数值求解到结果展示的基本闭环。默认仿真内核为纯 Dart 实现的改进节点分析（MNA）求解器，结果由电路方程计算，不再使用预制 Mock 波形。项目同时保留 ngspice 原生接口，但尚未打包 ngspice 动态库。

## 主要功能

- 电路元件放置
- 元件拖拽、旋转和改名
- 引脚连线与连线删除
- 电阻、电容、电感、电压源、LED、GND、电压表、电流表、开关等元件支持
- 参数编辑和单位输入
- 内置示例电路
- SPICE/ngspice 风格网表生成
- 仿真结果波形展示
- 电路保存、打开和分享

## 当前版本说明

- 已实现 `CanvasState.components` 和 `CanvasState.wires` 到内部 `CircuitModel` 的转换。
- 已实现 SPICE 网表生成和仿真接口封装。
- 已实现 `DartMnaSpiceSimulator` 本地求解器，支持电阻、电容、电感、直流电压源、LED、开关、电压表和电流表的瞬态计算。
- 电容和电感采用后向欧拉伴随模型，LED 采用非线性模型和 Newton-Raphson 迭代。
- 已预留 `NativeNgspiceSimulator` 原生接口，后续可接入官方 ngspice 动态库替换或校验当前求解内核。
- 当前版本主要面向 Android / 桌面端演示，部分文件操作依赖 `dart:io`，Web 端兼容性需要后续适配。

## 运行方式

```bash
flutter pub get
flutter analyze
flutter test
flutter run
```

如果运行 Android 项目，请确保本机已安装 Android SDK，并已在本机 Flutter 环境中重新生成 `android/local.properties` 等本地配置文件。

## 项目结构说明

```text
lib/
  main.dart                       应用入口和主界面
  models/                         元件、连线和电路数据模型
  state/                          画布状态管理
  widgets/                        画布、工具栏、属性面板和波形显示组件
  services/                       电路存储、内置案例、网表生成和映射服务
  spice/                          SPICE 模型、MNA 求解器、仿真配置与 Native 接口

test/
  spice_core_test.dart            单元测试，覆盖单位解析、网表生成、错误检查和仿真结果序列化

android/ ios/ linux/ macos/ web/ windows/
  Flutter 多平台工程目录
```

## 后续优化方向

- 接入 ngspice 原生库并与本地 MNA 结果交叉验证
- 增加 AC、DC Sweep 和更多非线性器件模型
- 增强电路合法性检查
- 支持更多电路元件和模型
- 优化移动端拖拽、缩放和连线交互体验
- 完善 Web 端文件操作适配

## 答辩定位

本项目应定位为“基于 Flutter 的电路仿真教学 APP 原型”。当前版本实现了电路搭建、参数编辑、SPICE 网表生成以及基于 MNA 的本地瞬态数值求解。它已经能够根据电路方程计算基础元件的电压和电流，但尚未集成 ngspice 完整器件库，也不应包装为专业级商业 SPICE 仿真器。
