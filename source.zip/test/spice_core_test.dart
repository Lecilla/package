import 'package:flutter_test/flutter_test.dart';

import 'package:circuit_simulator/models/component.dart';
import 'package:circuit_simulator/models/wire.dart';
import 'package:circuit_simulator/services/builtin_circuits.dart';
import 'package:circuit_simulator/services/circuit_to_spice_mapper.dart';
import 'package:circuit_simulator/services/netlist_generator.dart';
import 'package:circuit_simulator/spice/mock_spice_simulator.dart';
import 'package:circuit_simulator/spice/simulation_config.dart';
import 'package:circuit_simulator/spice/simulation_result.dart';
import 'package:circuit_simulator/spice/spice_value_parser.dart';

void main() {
  group('SpiceValueParser', () {
    test('parses supported suffixes', () {
      expect(SpiceValueParser.parse('1k').value, 1000);
      expect(SpiceValueParser.parse('2.2k').value, 2200);
      expect(SpiceValueParser.parse('10u').value, closeTo(0.00001, 1e-12));
      expect(SpiceValueParser.parse('5m').value, 0.005);
      expect(SpiceValueParser.parse('1Meg').value, 1000000);
    });

    test('warns for uppercase M', () {
      final parsed = SpiceValueParser.parse('1M');
      expect(parsed.value, 0.001);
      expect(parsed.warnings.single, contains('检测到单位 M'));
    });
  });

  group('NetlistGenerator', () {
    test('generates voltage divider netlist', () {
      final builtin = BuiltinCircuits.voltageDivider();
      final circuit = CircuitToSpiceMapper().map(
        builtin.components,
        builtin.wires,
      );
      final netlist = NetlistGenerator().generate(
        circuit,
        SimulationConfig(nodesToPlot: circuit.observableNodes),
      );
      expect(netlist, contains('V1'));
      expect(netlist, contains('R1'));
      expect(netlist, contains('R2'));
      expect(netlist, contains('.tran 1ms 1s'));
      expect(netlist, contains('print time'));
    });

    test('generates RC netlist', () {
      final builtin = BuiltinCircuits.rcCharging();
      final circuit = CircuitToSpiceMapper().map(
        builtin.components,
        builtin.wires,
      );
      final netlist = NetlistGenerator().generate(
        circuit,
        const SimulationConfig(),
      );
      expect(netlist, contains('R1'));
      expect(netlist, contains('C1'));
      expect(netlist, contains('DC 5'));
    });

    test('generates LED netlist with model', () {
      final builtin = BuiltinCircuits.ledCircuit();
      final circuit = CircuitToSpiceMapper().map(
        builtin.components,
        builtin.wires,
      );
      final netlist = NetlistGenerator().generate(
        circuit,
        const SimulationConfig(),
      );
      expect(netlist, contains('D1'));
      expect(netlist, contains('.model Dled D(Is=1e-14 N=2)'));
    });
  });

  group('CircuitToSpiceMapper validation', () {
    test('rejects empty circuit', () {
      expect(
        () => CircuitToSpiceMapper().map([], []),
        throwsA(isA<CircuitMappingException>()),
      );
    });

    test('rejects missing ground', () {
      final components = [
        _component('r1', ComponentType.resistor, {'resistance': '1k'}),
      ];
      expect(
        () => CircuitToSpiceMapper().map(components, []),
        throwsA(
          predicate(
            (error) =>
                error is CircuitMappingException &&
                error.errors.any((msg) => msg.contains('缺少接地')),
          ),
        ),
      );
    });

    test('rejects floating endpoint', () {
      final r1 = _component('r1', ComponentType.resistor, {'resistance': '1k'});
      final gnd = _component('g1', ComponentType.ground, {});
      expect(
        () => CircuitToSpiceMapper().map(
          [r1, gnd],
          [_wire('w1', r1.id, 'p1', gnd.id, 'gnd')],
        ),
        throwsA(
          predicate(
            (error) =>
                error is CircuitMappingException &&
                error.errors.any((msg) => msg.contains('悬空端点')),
          ),
        ),
      );
    });

    test('rejects empty parameter', () {
      final r1 = _component('r1', ComponentType.resistor, {'resistance': ''});
      final gnd = _component('g1', ComponentType.ground, {});
      expect(
        () => CircuitToSpiceMapper().map(
          [r1, gnd],
          [
            _wire('w1', r1.id, 'p1', gnd.id, 'gnd'),
            _wire('w2', r1.id, 'p2', gnd.id, 'gnd'),
          ],
        ),
        throwsA(
          predicate(
            (error) =>
                error is CircuitMappingException &&
                error.errors.any((msg) => msg.contains('参数为空')),
          ),
        ),
      );
    });

    test('rejects invalid parameter', () {
      final r1 = _component('r1', ComponentType.resistor, {
        'resistance': 'abc',
      });
      final gnd = _component('g1', ComponentType.ground, {});
      expect(
        () => CircuitToSpiceMapper().map(
          [r1, gnd],
          [
            _wire('w1', r1.id, 'p1', gnd.id, 'gnd'),
            _wire('w2', r1.id, 'p2', gnd.id, 'gnd'),
          ],
        ),
        throwsA(
          predicate(
            (error) =>
                error is CircuitMappingException &&
                error.errors.any((msg) => msg.contains('参数格式无法识别')),
          ),
        ),
      );
    });
  });

  group('MockSpiceSimulator', () {
    test('returns time and node voltages for RC circuit', () async {
      final builtin = BuiltinCircuits.rcCharging();
      final circuit = CircuitToSpiceMapper().map(
        builtin.components,
        builtin.wires,
      );
      final result = await MockSpiceSimulator().runTransient(
        circuit,
        SimulationConfig(nodesToPlot: circuit.observableNodes),
      );

      expect(result.success, isTrue);
      expect(result.time.length, greaterThanOrEqualTo(200));
      expect(result.nodeVoltages, isNotEmpty);
      expect(result.nodeVoltages.values.first, isNotEmpty);
      expect(result.warnings.join('\n'), contains('Mock 仿真器'));
    });
  });

  group('SimulationResult', () {
    test('round trips json', () {
      const result = SimulationResult(
        success: true,
        time: [0, 1],
        nodeVoltages: {
          'n1': [0, 5],
        },
        branchCurrents: {
          'V1': [0.0, 0.01],
        },
        rawOutput: 'raw',
        warnings: ['warn'],
        netlist: 'netlist',
      );

      final decoded = SimulationResult.fromJson(result.toJson());
      expect(decoded.success, isTrue);
      expect(decoded.time, [0, 1]);
      expect(decoded.nodeVoltages['n1'], [0, 5]);
      expect(decoded.branchCurrents['V1'], [0, 0.01]);
      expect(decoded.rawOutput, 'raw');
      expect(decoded.warnings, ['warn']);
      expect(decoded.netlist, 'netlist');
    });
  });
}

CircuitComponent _component(
  String id,
  ComponentType type,
  Map<String, dynamic> properties,
) {
  return CircuitComponent(
    id: id,
    type: type,
    position: Offset.zero,
    properties: properties,
    pins: type == ComponentType.ground
        ? const [Pin(id: 'gnd', offset: Offset.zero)]
        : const [
            Pin(id: 'p1', offset: Offset(-10, 0)),
            Pin(id: 'p2', offset: Offset(10, 0)),
          ],
  );
}

Wire _wire(
  String id,
  String fromComponentId,
  String fromPinId,
  String toComponentId,
  String toPinId,
) {
  return Wire(
    id: id,
    fromComponentId: fromComponentId,
    fromPointId: fromPinId,
    toComponentId: toComponentId,
    toPointId: toPinId,
  );
}
