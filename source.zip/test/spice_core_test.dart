import 'package:flutter_test/flutter_test.dart';

import 'package:circuit_simulator/models/component.dart';
import 'package:circuit_simulator/models/wire.dart';
import 'package:circuit_simulator/services/builtin_circuits.dart';
import 'package:circuit_simulator/services/circuit_to_spice_mapper.dart';
import 'package:circuit_simulator/services/netlist_generator.dart';
import 'package:circuit_simulator/state/canvas_state.dart';
import 'package:circuit_simulator/spice/mock_spice_simulator.dart';
import 'package:circuit_simulator/spice/dart_mna_spice_simulator.dart';
import 'package:circuit_simulator/spice/simulation_config.dart';
import 'package:circuit_simulator/spice/simulation_result.dart';
import 'package:circuit_simulator/spice/spice_value_parser.dart';

void main() {
  group('SpiceValueParser', () {
    test('parses supported suffixes', () {
      expect(SpiceValueParser.parse('1k').value, 1000);
      expect(SpiceValueParser.parse('2.2k').value, 2200);
      expect(SpiceValueParser.parse('10u').value, closeTo(0.00001, 1e-12));
      expect(SpiceValueParser.parse('5m').value, 0.005);
      expect(SpiceValueParser.parse('1Meg').value, 1000000);
    });

    test('warns for uppercase M', () {
      final parsed = SpiceValueParser.parse('1M');
      expect(parsed.value, 0.001);
      expect(parsed.warnings.single, contains('检测到单位 M'));
    });
  });

  group('NetlistGenerator', () {
    test('generates voltage divider netlist', () {
      final builtin = BuiltinCircuits.voltageDivider();
      final circuit = CircuitToSpiceMapper().map(
        builtin.components,
        builtin.wires,
      );
      final netlist = NetlistGenerator().generate(
        circuit,
        SimulationConfig(nodesToPlot: circuit.observableNodes),
      );
      expect(netlist, contains('V1'));
      expect(netlist, contains('R1'));
      expect(netlist, contains('R2'));
      expect(netlist, contains('.tran 1ms 1s'));
      expect(netlist, contains('print time'));
    });

    test('generates RC netlist', () {
      final v1 = _component('v1', ComponentType.voltageSource, {
        'voltage': '5',
      });
      final am1 = _component('am1', ComponentType.ammeter, {'name': '电流表'});
      final vm1 = _component('vm1', ComponentType.voltmeter, {'name': '电压表'});
      final gnd = _component('g1', ComponentType.ground, {});
      final circuit = CircuitToSpiceMapper().map(
        [v1, am1, vm1, gnd],
        [
          _wire('w1', v1.id, 'p1', am1.id, 'p1'),
          _wire('w2', am1.id, 'p2', vm1.id, 'p1'),
          _wire('w3', vm1.id, 'p2', gnd.id, 'gnd'),
          _wire('w4', v1.id, 'p2', gnd.id, 'gnd'),
        ],
      );
      final netlist = NetlistGenerator().generate(
        circuit,
        const SimulationConfig(),
      );
      expect(netlist, contains('i(VAM1)'));
      expect(netlist, contains(RegExp(r'v\(n\d+,0\)')));
    });

    test('generates diode, MOSFET and timed switch syntax', () {
      final source = _component('v1', ComponentType.voltageSource, {
        'voltage': '5',
      });
      final switchComponent = _component('s1', ComponentType.switchComponent, {
        'isClosed': false,
        'onResistance': '1m',
        'offResistance': '1Meg',
      });
      final diode = _component('d1', ComponentType.diode, {
        'forwardVoltage': '0.7',
      });
      final ground = _component('g1', ComponentType.ground, {});
      final circuit = CircuitToSpiceMapper().map(
        [source, switchComponent, diode, ground],
        [
          _wire('w1', source.id, 'p1', switchComponent.id, 'p1'),
          _wire('w2', switchComponent.id, 'p2', diode.id, 'p1'),
          _wire('w3', diode.id, 'p2', ground.id, 'gnd'),
          _wire('w4', source.id, 'p2', ground.id, 'gnd'),
        ],
      );
      final netlist = NetlistGenerator().generate(
        circuit,
        SimulationConfig(
          switchEvents: [
            SwitchEvent(
              componentId: switchComponent.id,
              time: 0.02,
              isClosed: true,
            ),
          ],
        ),
      );
      expect(netlist, contains('r={if(time<0.02'));
      expect(netlist, contains('.model D_D1'));
    });
  });

  group('CircuitToSpiceMapper validation', () {
    test('rejects empty circuit', () {
      expect(
        () => CircuitToSpiceMapper().map([], []),
        throwsA(isA<CircuitMappingException>()),
      );
    });

    test('rejects missing ground', () {
      final components = [
        _component('r1', ComponentType.resistor, {'resistance': '1k'}),
      ];
      expect(
        () => CircuitToSpiceMapper().map(components, []),
        throwsA(
          predicate(
            (error) =>
                error is CircuitMappingException &&
                error.errors.any((msg) => msg.contains('缺少接地')),
          ),
        ),
      );
    });

    test('rejects floating endpoint', () {
      final r1 = _component('r1', ComponentType.resistor, {'resistance': '1k'});
      final gnd = _component('g1', ComponentType.ground, {});
      expect(
        () => CircuitToSpiceMapper().map(
          [r1, gnd],
          [_wire('w1', r1.id, 'p1', gnd.id, 'gnd')],
        ),
        throwsA(
          predicate(
            (error) =>
                error is CircuitMappingException &&
                error.errors.any((msg) => msg.contains('悬空端点')),
          ),
        ),
      );
    });

    test('rejects empty parameter', () {
      final r1 = _component('r1', ComponentType.resistor, {'resistance': ''});
      final gnd = _component('g1', ComponentType.ground, {});
      expect(
        () => CircuitToSpiceMapper().map(
          [r1, gnd],
          [
            _wire('w1', r1.id, 'p1', gnd.id, 'gnd'),
            _wire('w2', r1.id, 'p2', gnd.id, 'gnd'),
          ],
        ),
        throwsA(
          predicate(
            (error) =>
                error is CircuitMappingException &&
                error.errors.any((msg) => msg.contains('参数为空')),
          ),
        ),
      );
    });

    test('rejects invalid parameter', () {
      final r1 = _component('r1', ComponentType.resistor, {
        'resistance': 'abc',
      });
      final gnd = _component('g1', ComponentType.ground, {});
      expect(
        () => CircuitToSpiceMapper().map(
          [r1, gnd],
          [
            _wire('w1', r1.id, 'p1', gnd.id, 'gnd'),
            _wire('w2', r1.id, 'p2', gnd.id, 'gnd'),
          ],
        ),
        throwsA(
          predicate(
            (error) =>
                error is CircuitMappingException &&
                error.errors.any((msg) => msg.contains('参数格式无法识别')),
          ),
        ),
      );
    });
  });

  group('MockSpiceSimulator', () {
    test('returns time and node voltages for RC circuit', () async {
      final builtin = BuiltinCircuits.rcCharging();
      final circuit = CircuitToSpiceMapper().map(
        builtin.components,
        builtin.wires,
      );
      final result = await MockSpiceSimulator().runTransient(
        circuit,
        SimulationConfig(nodesToPlot: circuit.observableNodes),
      );

      expect(result.success, isTrue);
      expect(result.time.length, greaterThanOrEqualTo(200));
      expect(result.nodeVoltages, isNotEmpty);
      expect(result.nodeVoltages.values.first, isNotEmpty);
      expect(result.warnings.join('\n'), contains('Mock 仿真器'));
    });

    test('returns about 2.5V for the built-in voltage divider', () async {
      final builtin = BuiltinCircuits.voltageDivider();
      final circuit = CircuitToSpiceMapper().map(
        builtin.components,
        builtin.wires,
      );
      final result = await MockSpiceSimulator().runTransient(
        circuit,
        SimulationConfig(nodesToPlot: circuit.observableNodes),
      );

      expect(
        result.nodeVoltages.values.any(
          (series) => series.isNotEmpty && (series.last - 2.5).abs() < 0.01,
        ),
        isTrue,
      );
    });

    test('provides an ammeter reading for a simple series circuit', () async {
      final source = _component('v1', ComponentType.voltageSource, {
        'voltage': '5',
      });
      final resistor = _component('r1', ComponentType.resistor, {
        'resistance': '1k',
      });
      final ammeter = _component('am1', ComponentType.ammeter, {});
      final ground = _component('g1', ComponentType.ground, {});
      final circuit = CircuitToSpiceMapper().map(
        [source, resistor, ammeter, ground],
        [
          _wire('w1', source.id, 'p1', resistor.id, 'p1'),
          _wire('w2', resistor.id, 'p2', ammeter.id, 'p1'),
          _wire('w3', ammeter.id, 'p2', ground.id, 'gnd'),
          _wire('w4', source.id, 'p2', ground.id, 'gnd'),
        ],
      );
      final result = await MockSpiceSimulator().runTransient(
        circuit,
        SimulationConfig(nodesToPlot: circuit.observableNodes),
      );
      final state = CanvasState()
        ..addComponent(source)
        ..addComponent(resistor)
        ..addComponent(ammeter)
        ..addComponent(ground)
        ..applySimulationResult(circuit, result);

      expect(state.componentCurrent(ammeter.id), closeTo(0.005, 1e-9));
    });
  });

  group('DartMnaSpiceSimulator real solve', () {
    test('solves a 5V 1k/1k voltage divider to about 2.5V', () async {
      final builtin = BuiltinCircuits.voltageDivider();
      final circuit = CircuitToSpiceMapper().map(
        builtin.components,
        builtin.wires,
      );
      final result = await DartMnaSpiceSimulator().runTransient(
        circuit,
        const SimulationConfig(stepTime: 0.001, stopTime: 0.02),
      );

      expect(result.success, isTrue, reason: result.errors.join('\n'));
      expect(
        result.nodeVoltages.values.any(
          (series) => (series.last - 2.5).abs() < 0.01,
        ),
        isTrue,
      );
      expect(result.warnings.join('\n'), contains('MNA 数值求解器'));
      expect(result.warnings.join('\n'), isNot(contains('仅用于验证')));
    });

    test('solves RC charging at one time constant', () async {
      final builtin = BuiltinCircuits.rcCharging();
      final circuit = CircuitToSpiceMapper().map(
        builtin.components,
        builtin.wires,
      );
      final capacitor = circuit.elements.firstWhere(
        (element) => element.type == 'capacitor',
      );
      final outputNode = capacitor.node1 == '0'
          ? capacitor.node2!
          : capacitor.node1!;
      final result = await DartMnaSpiceSimulator().runTransient(
        circuit,
        const SimulationConfig(stepTime: 0.0001, stopTime: 0.05),
      );

      expect(result.success, isTrue, reason: result.errors.join('\n'));
      final indexAtTau = result.time.indexWhere((time) => time >= 0.01);
      expect(result.nodeVoltages[outputNode]![indexAtTau], closeTo(3.16, 0.08));
      expect(result.nodeVoltages[outputNode]!.last, greaterThan(4.9));
    });

    test('solves ammeter current in a 5V 1k series circuit', () async {
      final source = _component('v1', ComponentType.voltageSource, {
        'voltage': '5',
      });
      final resistor = _component('r1', ComponentType.resistor, {
        'resistance': '1k',
      });
      final ammeter = _component('am1', ComponentType.ammeter, {});
      final ground = _component('g1', ComponentType.ground, {});
      final circuit = CircuitToSpiceMapper().map(
        [source, resistor, ammeter, ground],
        [
          _wire('w1', source.id, 'p1', resistor.id, 'p1'),
          _wire('w2', resistor.id, 'p2', ammeter.id, 'p1'),
          _wire('w3', ammeter.id, 'p2', ground.id, 'gnd'),
          _wire('w4', source.id, 'p2', ground.id, 'gnd'),
        ],
      );
      final meterElement = circuit.elements.firstWhere(
        (element) => element.type == 'ammeter',
      );
      final result = await DartMnaSpiceSimulator().runTransient(
        circuit,
        const SimulationConfig(stepTime: 0.001, stopTime: 0.02),
      );

      expect(result.success, isTrue, reason: result.errors.join('\n'));
      expect(
        result.branchCurrents[meterElement.name]!.last.abs(),
        closeTo(0.005, 1e-6),
      );
    });

    test('solves RL current rise with backward Euler', () async {
      final source = _component('v1', ComponentType.voltageSource, {
        'voltage': '5',
      });
      final resistor = _component('r1', ComponentType.resistor, {
        'resistance': '100',
      });
      final inductor = _component('l1', ComponentType.inductor, {
        'inductance': '1',
      });
      final ground = _component('g1', ComponentType.ground, {});
      final circuit = CircuitToSpiceMapper().map(
        [source, resistor, inductor, ground],
        [
          _wire('w1', source.id, 'p1', resistor.id, 'p1'),
          _wire('w2', resistor.id, 'p2', inductor.id, 'p1'),
          _wire('w3', inductor.id, 'p2', ground.id, 'gnd'),
          _wire('w4', source.id, 'p2', ground.id, 'gnd'),
        ],
      );
      final inductorElement = circuit.elements.firstWhere(
        (element) => element.type == 'inductor',
      );
      final result = await DartMnaSpiceSimulator().runTransient(
        circuit,
        const SimulationConfig(stepTime: 0.0001, stopTime: 0.05),
      );

      expect(result.success, isTrue, reason: result.errors.join('\n'));
      final currents = result.branchCurrents[inductorElement.name]!;
      expect(currents[1].abs(), lessThan(currents.last.abs()));
      expect(currents.last.abs(), closeTo(0.05, 0.001));
    });

    test('records an RC response before and after a switch event', () async {
      final builtin = BuiltinCircuits.switchedRc();
      final circuit = CircuitToSpiceMapper().map(
        builtin.components,
        builtin.wires,
      );
      final switchElement = circuit.elements.firstWhere(
        (element) => element.type == 'switch',
      );
      final capacitor = circuit.elements.firstWhere(
        (element) => element.type == 'capacitor',
      );
      final outputNode = capacitor.node1 == '0'
          ? capacitor.node2!
          : capacitor.node1!;
      final result = await DartMnaSpiceSimulator().runTransient(
        circuit,
        SimulationConfig(
          stepTime: 0.0002,
          stopTime: 0.08,
          switchEvents: [
            SwitchEvent(
              componentId: switchElement.id,
              time: 0.02,
              isClosed: true,
            ),
          ],
        ),
      );

      expect(result.success, isTrue, reason: result.errors.join('\n'));
      final before = result.time.lastIndexWhere((time) => time < 0.02);
      expect(result.nodeVoltages[outputNode]![before], lessThan(0.1));
      expect(result.nodeVoltages[outputNode]!.last, greaterThan(4.8));
    });

    test('keeps inductor current continuous across a switch event', () async {
      final builtin = BuiltinCircuits.switchedRl();
      final circuit = CircuitToSpiceMapper().map(
        builtin.components,
        builtin.wires,
      );
      final switchElement = circuit.elements.firstWhere(
        (element) => element.type == 'switch',
      );
      final inductor = circuit.elements.firstWhere(
        (element) => element.type == 'inductor',
      );
      final result = await DartMnaSpiceSimulator().runTransient(
        circuit,
        SimulationConfig(
          stepTime: 0.0001,
          stopTime: 0.08,
          switchEvents: [
            SwitchEvent(
              componentId: switchElement.id,
              time: 0.02,
              isClosed: true,
            ),
          ],
        ),
      );

      expect(result.success, isTrue, reason: result.errors.join('\n'));
      final currents = result.branchCurrents[inductor.name]!;
      final before = result.time.lastIndexWhere((time) => time < 0.02);
      final after = before + 1;
      expect((currents[after] - currents[before]).abs(), lessThan(0.001));
      expect(currents.last.abs(), greaterThan(0.045));
    });

    test('solves diode forward voltage and current', () async {
      final source = _component('v1', ComponentType.voltageSource, {
        'voltage': '5',
      });
      final resistor = _component('r1', ComponentType.resistor, {
        'resistance': '1k',
      });
      final diode = _component('d1', ComponentType.diode, {
        'forwardVoltage': '0.7',
      });
      final ground = _component('g1', ComponentType.ground, {});
      final circuit = CircuitToSpiceMapper().map(
        [source, resistor, diode, ground],
        [
          _wire('w1', source.id, 'p1', resistor.id, 'p1'),
          _wire('w2', resistor.id, 'p2', diode.id, 'p1'),
          _wire('w3', diode.id, 'p2', ground.id, 'gnd'),
          _wire('w4', source.id, 'p2', ground.id, 'gnd'),
        ],
      );
      final diodeElement = circuit.elements.firstWhere(
        (element) => element.type == 'diode',
      );
      final result = await DartMnaSpiceSimulator().runTransient(
        circuit,
        const SimulationConfig(stepTime: 0.0005, stopTime: 0.02),
      );

      expect(result.success, isTrue, reason: result.errors.join('\n'));
      expect(
        result.nodeVoltages[diodeElement.node1]!.last,
        inInclusiveRange(0.6, 0.85),
      );
      expect(
        result.branchCurrents[diodeElement.name]!.last,
        greaterThan(0.003),
      );
    });

    test('uses gate voltage to control NMOS drain current', () async {
      final vdd = _component('vdd', ComponentType.voltageSource, {
        'voltage': '5',
      });
      final gateSource = _component('vg', ComponentType.voltageSource, {
        'voltage': '3',
      });
      final resistor = _component('r1', ComponentType.resistor, {
        'resistance': '1k',
      });
      final mosfet = CircuitComponent(
        id: 'm1',
        type: ComponentType.mosfet,
        position: Offset.zero,
        properties: {
          'thresholdVoltage': '2',
          'transconductance': '2m',
          'lambda': '0.02',
        },
        pins: const [
          Pin(id: 'drain', offset: Offset.zero),
          Pin(id: 'gate', offset: Offset.zero),
          Pin(id: 'source', offset: Offset.zero),
        ],
      );
      final ground = _component('g1', ComponentType.ground, {});
      final circuit = CircuitToSpiceMapper().map(
        [vdd, gateSource, resistor, mosfet, ground],
        [
          _wire('w1', vdd.id, 'p1', resistor.id, 'p1'),
          _wire('w2', resistor.id, 'p2', mosfet.id, 'drain'),
          _wire('w3', mosfet.id, 'source', ground.id, 'gnd'),
          _wire('w4', vdd.id, 'p2', ground.id, 'gnd'),
          _wire('w5', gateSource.id, 'p1', mosfet.id, 'gate'),
          _wire('w6', gateSource.id, 'p2', ground.id, 'gnd'),
        ],
      );
      final mosElement = circuit.elements.firstWhere(
        (element) => element.type == 'mosfet',
      );
      final result = await DartMnaSpiceSimulator().runTransient(
        circuit,
        const SimulationConfig(stepTime: 0.0005, stopTime: 0.02),
      );

      expect(result.success, isTrue, reason: result.errors.join('\n'));
      expect(result.branchCurrents[mosElement.name]!.last, greaterThan(0.0005));
      expect(
        result.nodeVoltages[mosElement.node1]!.last,
        inInclusiveRange(2.0, 4.8),
      );
      expect(result.netlist, contains('NMOS_APP'));
    });

    test('drives LED visual state from solved voltage and current', () async {
      final source = _component('v1', ComponentType.voltageSource, {
        'voltage': '5',
      });
      final resistor = _component('r1', ComponentType.resistor, {
        'resistance': '1k',
      });
      final led = _component('led1', ComponentType.led, {
        'forwardVoltage': '2',
        'isLit': false,
      });
      final ground = _component('g1', ComponentType.ground, {});
      final circuit = CircuitToSpiceMapper().map(
        [source, resistor, led, ground],
        [
          _wire('w1', source.id, 'p1', resistor.id, 'p1'),
          _wire('w2', resistor.id, 'p2', led.id, 'p1'),
          _wire('w3', led.id, 'p2', ground.id, 'gnd'),
          _wire('w4', source.id, 'p2', ground.id, 'gnd'),
        ],
      );
      const config = SimulationConfig(stepTime: 0.0005, stopTime: 0.02);
      final result = await DartMnaSpiceSimulator().runTransient(
        circuit,
        config,
      );
      final state = CanvasState()
        ..addComponent(source)
        ..addComponent(resistor)
        ..addComponent(led)
        ..addComponent(ground)
        ..applySimulationResult(
          circuit,
          result,
          config: config,
          resumeAt: config.stopTime,
        );

      expect(result.success, isTrue, reason: result.errors.join('\n'));
      expect(state.isLedLit(led.id), isTrue);
      state.stopSimulation();
    });
  });

  group('SimulationResult', () {
    test('round trips json', () {
      const result = SimulationResult(
        success: true,
        time: [0, 1],
        nodeVoltages: {
          'n1': [0, 5],
        },
        branchCurrents: {
          'V1': [0.0, 0.01],
        },
        rawOutput: 'raw',
        warnings: ['warn'],
        netlist: 'netlist',
      );

      final decoded = SimulationResult.fromJson(result.toJson());
      expect(decoded.success, isTrue);
      expect(decoded.time, [0, 1]);
      expect(decoded.nodeVoltages['n1'], [0, 5]);
      expect(decoded.branchCurrents['V1'], [0, 0.01]);
      expect(decoded.rawOutput, 'raw');
      expect(decoded.warnings, ['warn']);
      expect(decoded.netlist, 'netlist');
    });
  });
}

CircuitComponent _component(
  String id,
  ComponentType type,
  Map<String, dynamic> properties,
) {
  return CircuitComponent(
    id: id,
    type: type,
    position: Offset.zero,
    properties: properties,
    pins: type == ComponentType.ground
        ? const [Pin(id: 'gnd', offset: Offset.zero)]
        : const [
            Pin(id: 'p1', offset: Offset(-10, 0)),
            Pin(id: 'p2', offset: Offset(10, 0)),
          ],
  );
}

Wire _wire(
  String id,
  String fromComponentId,
  String fromPinId,
  String toComponentId,
  String toPinId,
) {
  return Wire(
    id: id,
    fromComponentId: fromComponentId,
    fromPointId: fromPinId,
    toComponentId: toComponentId,
    toPointId: toPinId,
  );
}
