import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../models/circuit_data.dart';
import '../models/component.dart';
import '../models/wire.dart';

class BuiltinCircuit extends CircuitData {
  final String description;

  BuiltinCircuit({
    required super.components,
    required super.wires,
    required super.name,
    required this.description,
  });
}

class BuiltinCircuits {
  static const _uuid = Uuid();

  static List<BuiltinCircuit> all() => [
    voltageDivider(),
    rcCharging(),
  ];

  static BuiltinCircuit voltageDivider() {
    final v1 = _component(ComponentType.voltageSource, const Offset(160, 150), {
      'voltage': '5',
    });
    final r1 = _component(ComponentType.resistor, const Offset(280, 120), {
      'resistance': '1k',
    });
    final r2 = _component(ComponentType.resistor, const Offset(280, 220), {
      'resistance': '1k',
    });
    final gnd = _component(ComponentType.ground, const Offset(160, 260), {});

    return BuiltinCircuit(
      name: '电阻分压电路',
      description: 'V1=5V, R1=1k, R2=1k，中点约 2.5V',
      components: [v1, r1, r2, gnd],
      wires: [
        _wire(v1, 'p1', r1, 'p1'),
        _wire(r1, 'p2', r2, 'p1'),
        _wire(r2, 'p2', gnd, 'gnd'),
        _wire(v1, 'p2', gnd, 'gnd'),
      ],
    );
  }

  static BuiltinCircuit rcCharging() {
    final v1 = _component(ComponentType.voltageSource, const Offset(160, 160), {
      'voltage': '5',
    });
    final r1 = _component(ComponentType.resistor, const Offset(290, 120), {
      'resistance': '1k',
    });
    final c1 = _component(ComponentType.capacitor, const Offset(290, 230), {
      'capacitance': '10u',
    });
    final gnd = _component(ComponentType.ground, const Offset(160, 280), {});

    return BuiltinCircuit(
      name: 'RC 充电电路',
      description: 'V1=5V, R1=1k, C1=10u，MNA 计算充电曲线',
      components: [v1, r1, c1, gnd],
      wires: [
        _wire(v1, 'p1', r1, 'p1'),
        _wire(r1, 'p2', c1, 'p1'),
        _wire(c1, 'p2', gnd, 'gnd'),
        _wire(v1, 'p2', gnd, 'gnd'),
      ],
    );
  }

  static CircuitComponent _component(
    ComponentType type,
    Offset position,
    Map<String, dynamic> properties,
  ) {
    return CircuitComponent(
      id: _uuid.v4(),
      type: type,
      position: position,
      properties: properties,
      pins: _pinsFor(type),
    );
  }

  static List<Pin> _pinsFor(ComponentType type) {
    switch (type) {
      case ComponentType.resistor:
      case ComponentType.inductor:
      case ComponentType.voltmeter:
      case ComponentType.ammeter:
      case ComponentType.switchComponent:
        return const [
          Pin(id: 'p1', offset: Offset(-30, 0)),
          Pin(id: 'p2', offset: Offset(30, 0)),
        ];
      case ComponentType.capacitor:
        return const [
          Pin(id: 'p1', offset: Offset(-20, 0)),
          Pin(id: 'p2', offset: Offset(20, 0)),
        ];
      case ComponentType.voltageSource:
        return const [
          Pin(id: 'p1', offset: Offset(0, -30)),
          Pin(id: 'p2', offset: Offset(0, 30)),
        ];
      case ComponentType.ground:
        return const [Pin(id: 'gnd', offset: Offset(0, -20))];
    }
  }

  static Wire _wire(
    CircuitComponent from,
    String fromPin,
    CircuitComponent to,
    String toPin,
  ) {
    return Wire(
      id: _uuid.v4(),
      fromComponentId: from.id,
      fromPointId: fromPin,
      toComponentId: to.id,
      toPointId: toPin,
    );
  }
}
