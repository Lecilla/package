import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../models/component.dart';
import '../models/wire.dart';

class CircuitStorage {
  static Future<String> saveCircuit(
    String name,
    List<CircuitComponent> components,
    List<Wire> wires,
  ) async {
    final directory = await _circuitDirectory();
    final now = DateTime.now().toIso8601String();
    final data = {
      'version': 1,
      'createdAt': now,
      'updatedAt': now,
      'components': components.map((component) => component.toJson()).toList(),
      'wires': wires.map((wire) => wire.toJson()).toList(),
    };

    final safeName = name.endsWith('.json') ? name : '$name.json';
    final file = File('${directory.path}${Platform.pathSeparator}$safeName');
    await file.writeAsString(const JsonEncoder.withIndent('  ').convert(data));
    return file.path;
  }

  static Future<List<String>> listCircuits() async {
    final directory = await _circuitDirectory();
    if (!await directory.exists()) {
      return [];
    }
    final files = await directory
        .list()
        .where((entity) => entity is File && entity.path.endsWith('.json'))
        .map((entity) => entity.path)
        .toList();
    files.sort();
    return files.reversed.toList();
  }

  static Future<Map<String, dynamic>?> loadCircuit(String path) async {
    final file = File(path);
    if (!await file.exists()) {
      return null;
    }
    return jsonDecode(await file.readAsString()) as Map<String, dynamic>;
  }

  static Future<void> shareCircuit(String path) async {
    await Share.shareXFiles([XFile(path)], text: '电路仿真文件');
  }

  static Future<Directory> _circuitDirectory() async {
    final base = await getApplicationDocumentsDirectory();
    final directory = Directory(
      '${base.path}${Platform.pathSeparator}circuits',
    );
    if (!await directory.exists()) {
      await directory.create(recursive: true);
    }
    return directory;
  }
}
