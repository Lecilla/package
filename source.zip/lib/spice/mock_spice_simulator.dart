import 'dart:math';

import '../services/netlist_generator.dart';
import 'circuit_model.dart';
import 'simulation_config.dart';
import 'simulation_result.dart';
import 'spice_simulator.dart';
import 'spice_value_parser.dart';

class MockSpiceSimulator implements SpiceSimulator {
  final NetlistGenerator netlistGenerator;

  MockSpiceSimulator({NetlistGenerator? netlistGenerator})
    : netlistGenerator = netlistGenerator ?? NetlistGenerator();

  @override
  Future<SimulationResult> runTransient(
    CircuitModel circuit,
    SimulationConfig config,
  ) async {
    final netlist = netlistGenerator.generate(circuit, config);
    final warnings = <String>[
      ...circuit.warnings,
      '当前使用 Mock 仿真器，波形仅用于验证前端显示，不代表真实 SPICE 结果。',
    ];

    final nodesToPlot = config.nodesToPlot.isEmpty
        ? circuit.observableNodes
        : config.nodesToPlot;
    if (nodesToPlot.isEmpty) {
      return SimulationResult(
        success: false,
        errors: const ['没有找到可输出的节点电压。'],
        warnings: warnings,
        netlist: netlist,
      );
    }

    final sampleCount = max(
      200,
      (config.stopTime / config.stepTime).ceil() + 1,
    );
    final stopTime = config.stopTime <= config.startTime
        ? config.startTime + 1
        : config.stopTime;
    final time = List.generate(
      sampleCount,
      (index) =>
          config.startTime +
          (stopTime - config.startTime) * index / (sampleCount - 1),
    );

    final rc = _detectRcCircuit(circuit);
    final nodeVoltages = <String, List<double>>{};
    if (rc != null) {
      for (final node in nodesToPlot) {
        if (node == rc.outputNode) {
          nodeVoltages[node] = time
              .map((t) => rc.sourceVoltage * (1 - exp(-t / rc.tau)))
              .toList();
        } else if (node == rc.sourceNode) {
          nodeVoltages[node] = time.map((_) => rc.sourceVoltage).toList();
        } else {
          nodeVoltages[node] = time.map((_) => 0.0).toList();
        }
      }
    } else {
      for (var i = 0; i < nodesToPlot.length; i++) {
        final node = nodesToPlot[i];
        nodeVoltages[node] = time
            .map((t) => 2.5 + 2.5 * sin(2 * pi * (i + 1) * t / stopTime))
            .toList();
      }
    }

    return SimulationResult(
      success: true,
      time: time,
      nodeVoltages: nodeVoltages,
      branchCurrents: const {},
      rawOutput: 'Mock simulation completed.',
      warnings: warnings,
      netlist: netlist,
    );
  }

  _RcCircuit? _detectRcCircuit(CircuitModel circuit) {
    final source = circuit.elements
        .where((element) => element.type == 'voltageSource')
        .toList();
    final resistors = circuit.elements
        .where((element) => element.type == 'resistor')
        .toList();
    final capacitors = circuit.elements
        .where((element) => element.type == 'capacitor')
        .toList();
    if (source.length != 1 || resistors.isEmpty || capacitors.isEmpty) {
      return null;
    }

    final voltageSource = source.first;
    final resistor = resistors.first;
    final capacitor = capacitors.first;
    final capNodes = {capacitor.node1, capacitor.node2};
    if (!capNodes.contains('0')) {
      return null;
    }
    final outputNode = capacitor.node1 == '0'
        ? capacitor.node2
        : capacitor.node1;
    if (outputNode == null) {
      return null;
    }

    final resistorNodes = {resistor.node1, resistor.node2};
    if (!resistorNodes.contains(outputNode)) {
      return null;
    }
    final sourceNode = resistor.node1 == outputNode
        ? resistor.node2
        : resistor.node1;
    if (sourceNode == null ||
        sourceNode == '0' ||
        !{voltageSource.node1, voltageSource.node2}.contains(sourceNode) ||
        !{voltageSource.node1, voltageSource.node2}.contains('0')) {
      return null;
    }

    final r = SpiceValueParser.parse(resistor.value).value;
    final c = SpiceValueParser.parse(capacitor.value).value;
    final v = SpiceValueParser.parse(voltageSource.value).value;
    if (r <= 0 || c <= 0) {
      return null;
    }

    return _RcCircuit(
      sourceVoltage: v,
      tau: r * c,
      outputNode: outputNode,
      sourceNode: sourceNode,
    );
  }
}

class _RcCircuit {
  final double sourceVoltage;
  final double tau;
  final String outputNode;
  final String sourceNode;

  const _RcCircuit({
    required this.sourceVoltage,
    required this.tau,
    required this.outputNode,
    required this.sourceNode,
  });
}
