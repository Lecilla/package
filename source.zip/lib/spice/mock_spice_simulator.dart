import 'dart:math';

import '../services/netlist_generator.dart';
import 'circuit_model.dart';
import 'simulation_config.dart';
import 'simulation_result.dart';
import 'spice_simulator.dart';
import 'spice_value_parser.dart';

class MockSpiceSimulator implements SpiceSimulator {
  final NetlistGenerator netlistGenerator;

  MockSpiceSimulator({NetlistGenerator? netlistGenerator})
    : netlistGenerator = netlistGenerator ?? NetlistGenerator();

  @override
  Future<SimulationResult> runTransient(
    CircuitModel circuit,
    SimulationConfig config,
  ) async {
    final netlist = netlistGenerator.generate(circuit, config);
    final warnings = <String>[
      ...circuit.warnings,
      '当前使用 Mock 仿真器，波形仅用于验证前端显示，不代表真实 SPICE 结果。',
    ];

    final nodesToPlot = config.nodesToPlot.isEmpty
        ? circuit.observableNodes
        : config.nodesToPlot;
    if (nodesToPlot.isEmpty) {
      return SimulationResult(
        success: false,
        errors: const ['没有找到可输出的节点电压。'],
        warnings: warnings,
        netlist: netlist,
      );
    }

    final sampleCount = max(
      200,
      (config.stopTime / config.stepTime).ceil() + 1,
    );
    final stopTime = config.stopTime <= config.startTime
        ? config.startTime + 1
        : config.stopTime;
    final time = List.generate(
      sampleCount,
      (index) =>
          config.startTime +
          (stopTime - config.startTime) * index / (sampleCount - 1),
    );

    final rc = _detectRcCircuit(circuit);
    final divider = _detectVoltageDivider(circuit);
    final ledCircuit = _detectLedCircuit(circuit);
    final nodeVoltages = <String, List<double>>{};
    if (rc != null) {
      for (final node in nodesToPlot) {
        if (node == rc.outputNode) {
          nodeVoltages[node] = time
              .map((t) => rc.sourceVoltage * (1 - exp(-t / rc.tau)))
              .toList();
        } else if (node == rc.sourceNode) {
          nodeVoltages[node] = time.map((_) => rc.sourceVoltage).toList();
        } else {
          nodeVoltages[node] = time.map((_) => 0.0).toList();
        }
      }
    } else if (divider != null) {
      for (final node in nodesToPlot) {
        final value = node == divider.sourceNode
            ? divider.sourceVoltage
            : node == divider.outputNode
            ? divider.outputVoltage
            : 0.0;
        nodeVoltages[node] = time.map((_) => value).toList();
      }
    } else if (ledCircuit != null) {
      for (final node in nodesToPlot) {
        final value = node == ledCircuit.sourceNode
            ? ledCircuit.sourceVoltage
            : node == ledCircuit.ledAnodeNode
            ? ledCircuit.forwardVoltage
            : 0.0;
        nodeVoltages[node] = time.map((_) => value).toList();
      }
    } else {
      for (var i = 0; i < nodesToPlot.length; i++) {
        final node = nodesToPlot[i];
        nodeVoltages[node] = time
            .map((t) => 2.5 + 2.5 * sin(2 * pi * (i + 1) * t / stopTime))
            .toList();
      }
      for (final source in circuit.elements.where(
        (element) => element.type == 'voltageSource',
      )) {
        if (!{source.node1, source.node2}.contains('0')) continue;
        final sourceNode = source.node1 == '0' ? source.node2 : source.node1;
        if (sourceNode != null && nodeVoltages.containsKey(sourceNode)) {
          final sourceVoltage = SpiceValueParser.parse(source.value).value;
          nodeVoltages[sourceNode] = time
              .map((_) => source.node1 == '0' ? -sourceVoltage : sourceVoltage)
              .toList();
        }
      }
    }

    final estimatedLoopCurrent =
        ledCircuit?.loopCurrent ?? _estimateSeriesLoopCurrent(circuit);
    final branchCurrents = _buildBranchCurrents(
      circuit,
      time,
      nodeVoltages,
      estimatedLoopCurrent,
    );

    return SimulationResult(
      success: true,
      time: time,
      nodeVoltages: nodeVoltages,
      branchCurrents: branchCurrents,
      rawOutput: 'Mock simulation completed.',
      warnings: warnings,
      netlist: netlist,
    );
  }

  Map<String, List<double>> _buildBranchCurrents(
    CircuitModel circuit,
    List<double> time,
    Map<String, List<double>> nodeVoltages,
    double? loopCurrent,
  ) {
    List<double> voltage(String? node) {
      if (node == null || node == '0') return List.filled(time.length, 0);
      return nodeVoltages[node] ?? List.filled(time.length, 0);
    }

    final currents = <String, List<double>>{};
    for (final element in circuit.elements) {
      final v1 = voltage(element.node1);
      final v2 = voltage(element.node2);
      List<double>? values;
      if (element.type == 'resistor' || element.type == 'switch') {
        final resistance = SpiceValueParser.parse(element.value).value;
        if (resistance != 0) {
          values = List.generate(
            time.length,
            (i) => (v1[i] - v2[i]) / resistance,
          );
        }
      } else if (element.type == 'capacitor') {
        final capacitance = SpiceValueParser.parse(element.value).value;
        values = List<double>.filled(time.length, 0);
        for (var i = 1; i < time.length; i++) {
          final dt = time[i] - time[i - 1];
          if (dt != 0) {
            final previous = v1[i - 1] - v2[i - 1];
            final current = v1[i] - v2[i];
            values[i] = capacitance * (current - previous) / dt;
          }
        }
        if (values.length > 1) values[0] = values[1];
      } else if (element.type == 'ammeter' ||
          element.type == 'led' ||
          element.type == 'inductor') {
        values = List.filled(time.length, loopCurrent ?? 0);
      }
      if (values != null) {
        currents[element.name] = values;
        if (element.type == 'ammeter') currents['V${element.name}'] = values;
      }
    }
    return currents;
  }

  double? _estimateSeriesLoopCurrent(CircuitModel circuit) {
    final sources = circuit.elements
        .where((element) => element.type == 'voltageSource')
        .toList();
    if (sources.length != 1) return null;
    final sourceVoltage = SpiceValueParser.parse(
      sources.first.value,
    ).value.abs();
    var resistance = 0.0;
    var diodeDrop = 0.0;
    for (final element in circuit.elements) {
      if (element.type == 'resistor' || element.type == 'switch') {
        resistance += SpiceValueParser.parse(element.value).value;
      } else if (element.type == 'led') {
        diodeDrop += SpiceValueParser.parse(element.value).value;
      }
    }
    if (resistance <= 0) return null;
    return max(0.0, (sourceVoltage - diodeDrop) / resistance);
  }

  _RcCircuit? _detectRcCircuit(CircuitModel circuit) {
    final source = circuit.elements
        .where((element) => element.type == 'voltageSource')
        .toList();
    final resistors = circuit.elements
        .where((element) => element.type == 'resistor')
        .toList();
    final capacitors = circuit.elements
        .where((element) => element.type == 'capacitor')
        .toList();
    if (source.length != 1 || resistors.isEmpty || capacitors.isEmpty) {
      return null;
    }

    final voltageSource = source.first;
    final resistor = resistors.first;
    final capacitor = capacitors.first;
    final capNodes = {capacitor.node1, capacitor.node2};
    if (!capNodes.contains('0')) {
      return null;
    }
    final outputNode = capacitor.node1 == '0'
        ? capacitor.node2
        : capacitor.node1;
    if (outputNode == null) {
      return null;
    }

    final resistorNodes = {resistor.node1, resistor.node2};
    if (!resistorNodes.contains(outputNode)) {
      return null;
    }
    final sourceNode = resistor.node1 == outputNode
        ? resistor.node2
        : resistor.node1;
    if (sourceNode == null ||
        sourceNode == '0' ||
        !{voltageSource.node1, voltageSource.node2}.contains(sourceNode) ||
        !{voltageSource.node1, voltageSource.node2}.contains('0')) {
      return null;
    }

    final r = SpiceValueParser.parse(resistor.value).value;
    final c = SpiceValueParser.parse(capacitor.value).value;
    final v = SpiceValueParser.parse(voltageSource.value).value;
    if (r <= 0 || c <= 0) {
      return null;
    }

    return _RcCircuit(
      sourceVoltage: v,
      tau: r * c,
      outputNode: outputNode,
      sourceNode: sourceNode,
    );
  }

  _VoltageDivider? _detectVoltageDivider(CircuitModel circuit) {
    final sources = circuit.elements
        .where((e) => e.type == 'voltageSource')
        .toList();
    final resistors = circuit.elements
        .where((e) => e.type == 'resistor')
        .toList();
    if (sources.length != 1 || resistors.length != 2) return null;
    final source = sources.first;
    final sourceNode = source.node1 == '0' ? source.node2 : source.node1;
    if (sourceNode == null || !{source.node1, source.node2}.contains('0')) {
      return null;
    }

    for (final upper in resistors) {
      final lower = resistors.firstWhere(
        (candidate) => candidate.id != upper.id,
      );
      final shared = {
        upper.node1,
        upper.node2,
      }.intersection({lower.node1, lower.node2});
      if (shared.length != 1) continue;
      final outputNode = shared.first;
      if (outputNode == null ||
          !{upper.node1, upper.node2}.contains(sourceNode) ||
          !{lower.node1, lower.node2}.contains('0')) {
        continue;
      }
      final r1 = SpiceValueParser.parse(upper.value).value;
      final r2 = SpiceValueParser.parse(lower.value).value;
      final sourceVoltage = SpiceValueParser.parse(source.value).value;
      if (r1 <= 0 || r2 <= 0) return null;
      return _VoltageDivider(
        sourceNode: sourceNode,
        outputNode: outputNode,
        sourceVoltage: sourceVoltage,
        outputVoltage: sourceVoltage * r2 / (r1 + r2),
      );
    }
    return null;
  }

  _LedCircuit? _detectLedCircuit(CircuitModel circuit) {
    final sources = circuit.elements
        .where((e) => e.type == 'voltageSource')
        .toList();
    final resistors = circuit.elements
        .where((e) => e.type == 'resistor')
        .toList();
    final leds = circuit.elements.where((e) => e.type == 'led').toList();
    if (sources.length != 1 || resistors.length != 1 || leds.length != 1) {
      return null;
    }
    final source = sources.first;
    final resistor = resistors.first;
    final led = leds.first;
    final sourceNode = source.node1 == '0' ? source.node2 : source.node1;
    if (sourceNode == null || !{source.node1, source.node2}.contains('0')) {
      return null;
    }
    if (!{resistor.node1, resistor.node2}.contains(sourceNode)) return null;
    final ledAnodeNode = resistor.node1 == sourceNode
        ? resistor.node2
        : resistor.node1;
    if (ledAnodeNode == null || led.node1 != ledAnodeNode || led.node2 != '0') {
      return null;
    }
    final sourceVoltage = SpiceValueParser.parse(source.value).value;
    final forwardVoltage = SpiceValueParser.parse(led.value).value;
    final resistance = SpiceValueParser.parse(resistor.value).value;
    final loopCurrent = resistance <= 0
        ? 0.0
        : max(0.0, (sourceVoltage - forwardVoltage) / resistance);
    return _LedCircuit(
      sourceNode: sourceNode,
      ledAnodeNode: ledAnodeNode,
      sourceVoltage: sourceVoltage,
      forwardVoltage: forwardVoltage,
      loopCurrent: loopCurrent,
    );
  }
}

class _RcCircuit {
  final double sourceVoltage;
  final double tau;
  final String outputNode;
  final String sourceNode;

  const _RcCircuit({
    required this.sourceVoltage,
    required this.tau,
    required this.outputNode,
    required this.sourceNode,
  });
}

class _VoltageDivider {
  final String sourceNode;
  final String outputNode;
  final double sourceVoltage;
  final double outputVoltage;

  const _VoltageDivider({
    required this.sourceNode,
    required this.outputNode,
    required this.sourceVoltage,
    required this.outputVoltage,
  });
}

class _LedCircuit {
  final String sourceNode;
  final String ledAnodeNode;
  final double sourceVoltage;
  final double forwardVoltage;
  final double loopCurrent;

  const _LedCircuit({
    required this.sourceNode,
    required this.ledAnodeNode,
    required this.sourceVoltage,
    required this.forwardVoltage,
    required this.loopCurrent,
  });
}
