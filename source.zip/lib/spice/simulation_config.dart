class SwitchEvent {
  final String componentId;
  final double time;
  final bool isClosed;

  const SwitchEvent({
    required this.componentId,
    required this.time,
    required this.isClosed,
  });
}

class SimulationConfig {
  final String analysisType;
  final double stepTime;
  final double stopTime;
  final double startTime;
  final List<String> nodesToPlot;
  final List<String> currentsToPlot;
  final List<SwitchEvent> switchEvents;

  const SimulationConfig({
    this.analysisType = 'transient',
    this.stepTime = 0.001,
    this.stopTime = 1.0,
    this.startTime = 0.0,
    this.nodesToPlot = const [],
    this.currentsToPlot = const [],
    this.switchEvents = const [],
  });

  SimulationConfig copyWith({
    String? analysisType,
    double? stepTime,
    double? stopTime,
    double? startTime,
    List<String>? nodesToPlot,
    List<String>? currentsToPlot,
    List<SwitchEvent>? switchEvents,
  }) {
    return SimulationConfig(
      analysisType: analysisType ?? this.analysisType,
      stepTime: stepTime ?? this.stepTime,
      stopTime: stopTime ?? this.stopTime,
      startTime: startTime ?? this.startTime,
      nodesToPlot: nodesToPlot ?? this.nodesToPlot,
      currentsToPlot: currentsToPlot ?? this.currentsToPlot,
      switchEvents: switchEvents ?? this.switchEvents,
    );
  }
}
