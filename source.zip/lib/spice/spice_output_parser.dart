import 'simulation_result.dart';

class SpiceOutputParser {
  SimulationResult parse({
    required String rawOutput,
    required String netlist,
    List<String> warnings = const [],
  }) {
    final lines = rawOutput.split(RegExp(r'\r?\n'));
    final time = <double>[];
    final voltages = <String, List<double>>{};
    var headers = <String>[];

    for (final line in lines) {
      final trimmed = line.trim();
      if (trimmed.isEmpty) {
        continue;
      }
      final parts = trimmed.split(RegExp(r'\s+'));
      if (parts.any((part) => part.toLowerCase() == 'time')) {
        headers = parts;
        for (final header in headers.skip(1)) {
          voltages.putIfAbsent(header, () => <double>[]);
        }
        continue;
      }
      if (headers.isEmpty || parts.length < headers.length) {
        continue;
      }

      final parsedTime = double.tryParse(parts.first);
      if (parsedTime == null) {
        continue;
      }
      time.add(parsedTime);
      for (var i = 1; i < headers.length; i++) {
        voltages[headers[i]]?.add(double.tryParse(parts[i]) ?? 0);
      }
    }

    return SimulationResult(
      success: time.isNotEmpty,
      time: time,
      nodeVoltages: voltages,
      rawOutput: rawOutput,
      warnings: warnings,
      errors: time.isEmpty ? const ['未能从 ngspice 输出中解析到波形数据。'] : const [],
      netlist: netlist,
    );
  }
}
