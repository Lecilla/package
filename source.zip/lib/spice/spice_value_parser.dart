class ParsedSpiceValue {
  final double value;
  final String normalized;
  final List<String> warnings;

  const ParsedSpiceValue({
    required this.value,
    required this.normalized,
    this.warnings = const [],
  });
}

class SpiceValueParser {
  static final RegExp _valuePattern = RegExp(
    r'^\s*([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)\s*([a-zA-Z]*)\s*$',
  );

  static const Map<String, double> _multipliers = {
    't': 1e12,
    'g': 1e9,
    'meg': 1e6,
    'k': 1e3,
    '': 1.0,
    'm': 1e-3,
    'u': 1e-6,
    'n': 1e-9,
    'p': 1e-12,
    'f': 1e-15,
  };

  static ParsedSpiceValue parse(dynamic raw) {
    if (raw == null) {
      throw const FormatException('参数为空');
    }

    if (raw is num) {
      return ParsedSpiceValue(
        value: raw.toDouble(),
        normalized: _formatDouble(raw.toDouble()),
      );
    }

    final text = raw.toString().trim();
    if (text.isEmpty) {
      throw const FormatException('参数为空');
    }

    final match = _valuePattern.firstMatch(text);
    if (match == null) {
      throw FormatException('无法识别参数格式: $text');
    }

    final base = double.parse(match.group(1)!);
    final unit = match.group(2) ?? '';
    final warnings = <String>[];
    String key;

    if (unit == 'M') {
      warnings.add('检测到单位 M。SPICE 中建议使用 Meg 表示百万，m 表示毫。');
      key = 'm';
    } else if (unit.toLowerCase() == 'meg') {
      key = 'meg';
    } else {
      key = unit.toLowerCase();
    }

    final multiplier = _multipliers[key];
    if (multiplier == null) {
      throw FormatException('无法识别单位: $unit');
    }

    return ParsedSpiceValue(
      value: base * multiplier,
      normalized: '${_formatDouble(base)}$unit',
      warnings: warnings,
    );
  }

  static String _formatDouble(double value) {
    if (value == value.roundToDouble()) {
      return value.toStringAsFixed(0);
    }
    return value.toString();
  }
}
