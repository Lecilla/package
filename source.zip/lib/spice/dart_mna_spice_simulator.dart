import 'dart:math';

import '../services/netlist_generator.dart';
import 'circuit_model.dart';
import 'simulation_config.dart';
import 'simulation_result.dart';
import 'spice_element.dart';
import 'spice_simulator.dart';
import 'spice_value_parser.dart';

/// Pure Dart transient circuit solver based on Modified Nodal Analysis (MNA).
///
/// Resistors and switches are stamped as conductances. Capacitors and inductors
/// use backward Euler companion models. This is a real numerical solve,
/// independent of the Mock simulator and of any network service.
class DartMnaSpiceSimulator implements SpiceSimulator {
  final NetlistGenerator netlistGenerator;
  final int maxSamples;
  final int maxNewtonIterations;
  final double convergenceTolerance;

  DartMnaSpiceSimulator({
    NetlistGenerator? netlistGenerator,
    this.maxSamples = 10000,
    this.maxNewtonIterations = 100,
    this.convergenceTolerance = 1e-8,
  }) : netlistGenerator = netlistGenerator ?? NetlistGenerator();

  @override
  Future<SimulationResult> runTransient(
    CircuitModel circuit,
    SimulationConfig config,
  ) async {
    final netlist = netlistGenerator.generate(circuit, config);
    try {
      return _solve(circuit, config, netlist);
    } on _SolverException catch (error) {
      return SimulationResult(
        success: false,
        errors: [error.message],
        rawOutput: error.message,
        netlist: netlist,
      );
    } catch (error) {
      return SimulationResult(
        success: false,
        errors: ['本地 MNA 求解失败：$error'],
        rawOutput: error.toString(),
        netlist: netlist,
      );
    }
  }

  SimulationResult _solve(
    CircuitModel circuit,
    SimulationConfig config,
    String netlist,
  ) {
    if (config.stepTime <= 0) {
      throw const _SolverException('仿真步长必须大于 0。');
    }
    if (config.stopTime <= config.startTime) {
      throw const _SolverException('仿真结束时间必须大于开始时间。');
    }

    final nodeNames = circuit.nodes.where((node) => node != '0').toList()
      ..sort();
    if (nodeNames.isEmpty) {
      throw const _SolverException('没有找到可求解的非接地节点。');
    }
    final nodeIndex = <String, int>{
      for (var i = 0; i < nodeNames.length; i++) nodeNames[i]: i,
    };

    final branchElements = circuit.elements
        .where(
          (element) =>
              element.type == 'voltageSource' ||
              element.type == 'ammeter' ||
              element.type == 'inductor',
        )
        .toList();
    final branchIndex = <String, int>{
      for (var i = 0; i < branchElements.length; i++)
        branchElements[i].id: nodeNames.length + i,
    };
    final matrixSize = nodeNames.length + branchElements.length;
    if (matrixSize == 0) {
      throw const _SolverException('电路没有可求解的未知量。');
    }

    final requestedSamples =
        ((config.stopTime - config.startTime) / config.stepTime).ceil() + 1;
    final sampleCount = min(maxSamples, max(200, requestedSamples));
    final dt = (config.stopTime - config.startTime) / (sampleCount - 1);
    final warnings = <String>[...circuit.warnings];
    if (requestedSamples > maxSamples) {
      warnings.add('请求的采样点过多，已限制为 $maxSamples 个采样点。');
    }
    warnings.add('当前结果由本地 Dart MNA 数值求解器根据电路方程计算。');

    final time = List<double>.generate(
      sampleCount,
      (index) => config.startTime + index * dt,
    );
    final nodeVoltages = <String, List<double>>{
      for (final node in nodeNames) node: List<double>.filled(sampleCount, 0),
    };
    final branchCurrents = <String, List<double>>{};
    for (final element in circuit.elements) {
      if (element.type != 'ground') {
        branchCurrents[element.name] = List<double>.filled(sampleCount, 0);
        if (element.type == 'ammeter') {
          branchCurrents['V${element.name}'] = branchCurrents[element.name]!;
        }
      }
    }

    var solution = List<double>.filled(matrixSize, 0);
    final capacitorVoltage = <String, double>{};
    final inductorCurrent = <String, double>{};
    final hasNonlinearDevices = circuit.elements.any(
      (element) =>
          element.type == 'diode' ||
          element.type == 'led' ||
          element.type == 'mosfet',
    );

    for (var sample = 1; sample < sampleCount; sample++) {
      var guess = List<double>.from(solution);
      var converged = false;
      for (var iteration = 0; iteration < maxNewtonIterations; iteration++) {
        final matrix = List.generate(
          matrixSize,
          (_) => List<double>.filled(matrixSize, 0),
        );
        final rhs = List<double>.filled(matrixSize, 0);

        for (var i = 0; i < nodeNames.length; i++) {
          matrix[i][i] += 1e-12;
        }

        for (final element in circuit.elements) {
          _stampElement(
            element: element,
            matrix: matrix,
            rhs: rhs,
            nodeIndex: nodeIndex,
            branchIndex: branchIndex,
            dt: dt,
            currentTime: time[sample],
            config: config,
            previousCapacitorVoltage: capacitorVoltage[element.id] ?? 0,
            previousInductorCurrent: inductorCurrent[element.id] ?? 0,
            guess: guess,
          );
        }

        final next = _solveLinearSystem(matrix, rhs);
        final damping = hasNonlinearDevices ? 0.25 : 1.0;
        var largestChange = 0.0;
        for (var i = 0; i < next.length; i++) {
          final change = (next[i] - guess[i]) * damping;
          largestChange = max(largestChange, change.abs());
          next[i] = guess[i] + change;
        }
        guess = next;
        if (largestChange < convergenceTolerance) {
          converged = true;
          break;
        }
      }
      if (!converged) {
        throw _SolverException(
          '非线性电路在 ${time[sample].toStringAsPrecision(4)} s 未能收敛，请减小步长或检查器件连接。',
        );
      }
      solution = guess;

      for (final node in nodeNames) {
        nodeVoltages[node]![sample] = solution[nodeIndex[node]!];
      }

      for (final element in circuit.elements) {
        if (element.type == 'ground') continue;
        final voltage = _elementVoltage(element, solution, nodeIndex);
        final current = _elementCurrent(
          element: element,
          voltage: voltage,
          solution: solution,
          nodeIndex: nodeIndex,
          branchIndex: branchIndex,
          dt: dt,
          currentTime: time[sample],
          config: config,
          previousCapacitorVoltage: capacitorVoltage[element.id] ?? 0,
        );
        branchCurrents[element.name]![sample] = current;
        capacitorVoltage[element.id] = element.type == 'capacitor'
            ? voltage
            : capacitorVoltage[element.id] ?? 0;
        if (element.type == 'inductor') {
          inductorCurrent[element.id] = current;
        }
      }
    }

    for (final meter in circuit.elements.where(
      (element) => element.type == 'voltmeter',
    )) {
      final positive = meter.node1 == '0'
          ? List<double>.filled(sampleCount, 0)
          : nodeVoltages[meter.node1] ?? List<double>.filled(sampleCount, 0);
      final negative = meter.node2 == '0'
          ? List<double>.filled(sampleCount, 0)
          : nodeVoltages[meter.node2] ?? List<double>.filled(sampleCount, 0);
      nodeVoltages[meter.name] = List<double>.generate(
        sampleCount,
        (index) => positive[index] - negative[index],
      );
    }

    return SimulationResult(
      success: true,
      time: time,
      nodeVoltages: nodeVoltages,
      branchCurrents: branchCurrents,
      rawOutput:
          'Local Dart MNA transient solve completed: '
          '$matrixSize unknowns, $sampleCount samples.',
      warnings: warnings,
      netlist: netlist,
    );
  }

  void _stampElement({
    required SpiceElement element,
    required List<List<double>> matrix,
    required List<double> rhs,
    required Map<String, int> nodeIndex,
    required Map<String, int> branchIndex,
    required double dt,
    required double currentTime,
    required SimulationConfig config,
    required double previousCapacitorVoltage,
    required double previousInductorCurrent,
    required List<double> guess,
  }) {
    switch (element.type) {
      case 'resistor':
        final resistance = _positiveValue(element);
        _stampConductance(
          matrix,
          nodeIndex,
          element.node1,
          element.node2,
          1 / resistance,
        );
        break;
      case 'switch':
        final resistance = _switchResistance(element, config, currentTime);
        _stampConductance(
          matrix,
          nodeIndex,
          element.node1,
          element.node2,
          1 / resistance,
        );
        break;
      case 'voltmeter':
        _stampConductance(
          matrix,
          nodeIndex,
          element.node1,
          element.node2,
          1e-12,
        );
        break;
      case 'capacitor':
        final capacitance = _positiveValue(element);
        final conductance = capacitance / dt;
        _stampConductance(
          matrix,
          nodeIndex,
          element.node1,
          element.node2,
          conductance,
        );
        _stampCurrentSource(
          rhs,
          nodeIndex,
          element.node1,
          element.node2,
          -conductance * previousCapacitorVoltage,
        );
        break;
      case 'voltageSource':
        _stampVoltageBranch(
          matrix,
          rhs,
          nodeIndex,
          branchIndex[element.id]!,
          element.node1,
          element.node2,
          SpiceValueParser.parse(element.value).value,
        );
        break;
      case 'ammeter':
        _stampVoltageBranch(
          matrix,
          rhs,
          nodeIndex,
          branchIndex[element.id]!,
          element.node1,
          element.node2,
          0,
        );
        break;
      case 'inductor':
        final inductance = _positiveValue(element);
        final index = branchIndex[element.id]!;
        _stampVoltageBranch(
          matrix,
          rhs,
          nodeIndex,
          index,
          element.node1,
          element.node2,
          -inductance * previousInductorCurrent / dt,
          branchCoefficient: -inductance / dt,
        );
        break;
      case 'diode':
      case 'led':
        final voltage = _elementVoltage(element, guess, nodeIndex);
        final model = _diodeModel(element, voltage);
        _stampConductance(
          matrix,
          nodeIndex,
          element.node1,
          element.node2,
          model.conductance,
        );
        _stampCurrentSource(
          rhs,
          nodeIndex,
          element.node1,
          element.node2,
          model.equivalentCurrent,
        );
        break;
      case 'mosfet':
        _stampMosfet(element, matrix, rhs, nodeIndex, guess);
        break;
      case 'ground':
        break;
      default:
        throw _SolverException('本地 MNA 求解器暂不支持 ${element.type} 元件。');
    }
  }

  double _elementCurrent({
    required SpiceElement element,
    required double voltage,
    required List<double> solution,
    required Map<String, int> nodeIndex,
    required Map<String, int> branchIndex,
    required double dt,
    required double currentTime,
    required SimulationConfig config,
    required double previousCapacitorVoltage,
  }) {
    switch (element.type) {
      case 'resistor':
        return voltage / _positiveValue(element);
      case 'switch':
        return voltage / _switchResistance(element, config, currentTime);
      case 'voltmeter':
        return voltage / 1e12;
      case 'capacitor':
        return _positiveValue(element) *
            (voltage - previousCapacitorVoltage) /
            dt;
      case 'voltageSource':
      case 'ammeter':
      case 'inductor':
        return solution[branchIndex[element.id]!];
      case 'diode':
      case 'led':
        return _diodeModel(element, voltage).current;
      case 'mosfet':
        final gateVoltage = _nodeVoltage(element.node3, solution, nodeIndex);
        final sourceVoltage = _nodeVoltage(element.node2, solution, nodeIndex);
        return _mosfetModel(
          element,
          voltage,
          gateVoltage - sourceVoltage,
        ).current;
      default:
        return 0;
    }
  }

  double _positiveValue(SpiceElement element) {
    final value = SpiceValueParser.parse(element.value).value;
    if (value <= 0) {
      throw _SolverException('元件 ${element.name} 的参数必须大于 0。');
    }
    return value;
  }

  double _switchResistance(
    SpiceElement element,
    SimulationConfig config,
    double time,
  ) {
    var isClosed = element.params['isClosed'] != false;
    final events =
        config.switchEvents
            .where((event) => event.componentId == element.id)
            .toList()
          ..sort((a, b) => a.time.compareTo(b.time));
    for (final event in events) {
      if (event.time <= time + 1e-12) {
        isClosed = event.isClosed;
      }
    }
    final raw = isClosed
        ? element.params['onResistance'] ?? '1m'
        : element.params['offResistance'] ?? '1Meg';
    final resistance = SpiceValueParser.parse(raw).value;
    if (resistance <= 0) {
      throw _SolverException('开关 ${element.name} 的等效电阻必须大于 0。');
    }
    return resistance;
  }

  _DiodeLinearization _diodeModel(SpiceElement element, double voltage) {
    final forwardVoltage = max(
      0.1,
      SpiceValueParser.parse(element.value).value,
    );
    const offConductance = 1e-9;
    const onConductance = 0.1;
    const smoothingVoltage = 0.02;
    final normalized = ((voltage - forwardVoltage) / smoothingVoltage).clamp(
      -40.0,
      40.0,
    );
    final exponential = exp(normalized);
    final current =
        offConductance * voltage +
        onConductance * smoothingVoltage * log(1 + exponential);
    final conductance =
        offConductance + onConductance * exponential / (1 + exponential);
    return _DiodeLinearization(
      current: current,
      conductance: conductance,
      equivalentCurrent: current - conductance * voltage,
    );
  }

  void _stampMosfet(
    SpiceElement element,
    List<List<double>> matrix,
    List<double> rhs,
    Map<String, int> nodeIndex,
    List<double> guess,
  ) {
    final drainVoltage = _nodeVoltage(element.node1, guess, nodeIndex);
    final sourceVoltage = _nodeVoltage(element.node2, guess, nodeIndex);
    final gateVoltage = _nodeVoltage(element.node3, guess, nodeIndex);
    final vds = drainVoltage - sourceVoltage;
    final vgs = gateVoltage - sourceVoltage;
    final model = _mosfetModel(element, vds, vgs);
    final equivalentCurrent = model.current - model.gds * vds - model.gm * vgs;

    _addMatrix(matrix, nodeIndex, element.node1, element.node1, model.gds);
    _addMatrix(matrix, nodeIndex, element.node1, element.node3, model.gm);
    _addMatrix(
      matrix,
      nodeIndex,
      element.node1,
      element.node2,
      -model.gds - model.gm,
    );
    _addMatrix(matrix, nodeIndex, element.node2, element.node1, -model.gds);
    _addMatrix(matrix, nodeIndex, element.node2, element.node3, -model.gm);
    _addMatrix(
      matrix,
      nodeIndex,
      element.node2,
      element.node2,
      model.gds + model.gm,
    );
    _stampCurrentSource(
      rhs,
      nodeIndex,
      element.node1,
      element.node2,
      equivalentCurrent,
    );
  }

  _MosfetLinearization _mosfetModel(
    SpiceElement element,
    double vds,
    double vgs,
  ) {
    final threshold = SpiceValueParser.parse(
      element.params['thresholdVoltage'] ?? element.value,
    ).value;
    final k = SpiceValueParser.parse(
      element.params['transconductance'] ?? 0.002,
    ).value;
    final lambda = SpiceValueParser.parse(
      element.params['lambda'] ?? 0.02,
    ).value;
    const offConductance = 1e-9;
    final overdrive = vgs - threshold;
    if (overdrive <= 0 || vds <= 0) {
      return _MosfetLinearization(
        current: offConductance * vds,
        gm: 0,
        gds: offConductance,
      );
    }
    if (vds < overdrive) {
      final base = k * (overdrive * vds - 0.5 * vds * vds);
      final channel = 1 + lambda * vds;
      return _MosfetLinearization(
        current: base * channel,
        gm: k * vds * channel,
        gds: k * (overdrive - vds) * channel + base * lambda,
      );
    }
    final base = 0.5 * k * overdrive * overdrive;
    return _MosfetLinearization(
      current: base * (1 + lambda * vds),
      gm: k * overdrive * (1 + lambda * vds),
      gds: max(1e-12, base * lambda),
    );
  }

  void _addMatrix(
    List<List<double>> matrix,
    Map<String, int> nodeIndex,
    String? rowNode,
    String? columnNode,
    double value,
  ) {
    if (rowNode == null ||
        rowNode == '0' ||
        columnNode == null ||
        columnNode == '0') {
      return;
    }
    final row = nodeIndex[rowNode];
    final column = nodeIndex[columnNode];
    if (row != null && column != null) matrix[row][column] += value;
  }

  double _elementVoltage(
    SpiceElement element,
    List<double> solution,
    Map<String, int> nodeIndex,
  ) {
    return _nodeVoltage(element.node1, solution, nodeIndex) -
        _nodeVoltage(element.node2, solution, nodeIndex);
  }

  double _nodeVoltage(
    String? node,
    List<double> solution,
    Map<String, int> nodeIndex,
  ) {
    if (node == null || node == '0') return 0;
    final index = nodeIndex[node];
    if (index == null) {
      throw _SolverException('节点 $node 不存在。');
    }
    return solution[index];
  }

  void _stampConductance(
    List<List<double>> matrix,
    Map<String, int> nodeIndex,
    String? node1,
    String? node2,
    double conductance,
  ) {
    final i = node1 == null || node1 == '0' ? null : nodeIndex[node1];
    final j = node2 == null || node2 == '0' ? null : nodeIndex[node2];
    if (i != null) matrix[i][i] += conductance;
    if (j != null) matrix[j][j] += conductance;
    if (i != null && j != null) {
      matrix[i][j] -= conductance;
      matrix[j][i] -= conductance;
    }
  }

  void _stampCurrentSource(
    List<double> rhs,
    Map<String, int> nodeIndex,
    String? node1,
    String? node2,
    double currentFromNode1ToNode2,
  ) {
    final i = node1 == null || node1 == '0' ? null : nodeIndex[node1];
    final j = node2 == null || node2 == '0' ? null : nodeIndex[node2];
    if (i != null) rhs[i] -= currentFromNode1ToNode2;
    if (j != null) rhs[j] += currentFromNode1ToNode2;
  }

  void _stampVoltageBranch(
    List<List<double>> matrix,
    List<double> rhs,
    Map<String, int> nodeIndex,
    int branch,
    String? node1,
    String? node2,
    double voltage, {
    double branchCoefficient = 0,
  }) {
    final i = node1 == null || node1 == '0' ? null : nodeIndex[node1];
    final j = node2 == null || node2 == '0' ? null : nodeIndex[node2];
    if (i != null) {
      matrix[i][branch] += 1;
      matrix[branch][i] += 1;
    }
    if (j != null) {
      matrix[j][branch] -= 1;
      matrix[branch][j] -= 1;
    }
    matrix[branch][branch] += branchCoefficient;
    rhs[branch] += voltage;
  }

  List<double> _solveLinearSystem(
    List<List<double>> sourceMatrix,
    List<double> sourceRhs,
  ) {
    final size = sourceRhs.length;
    final matrix = List.generate(
      size,
      (row) => [...sourceMatrix[row], sourceRhs[row]],
    );

    for (var pivot = 0; pivot < size; pivot++) {
      var bestRow = pivot;
      var bestValue = matrix[pivot][pivot].abs();
      for (var row = pivot + 1; row < size; row++) {
        final candidate = matrix[row][pivot].abs();
        if (candidate > bestValue) {
          bestValue = candidate;
          bestRow = row;
        }
      }
      if (bestValue < 1e-18) {
        throw const _SolverException('电路矩阵奇异，可能存在浮空节点、理想电压源短路或缺少到 GND 的参考路径。');
      }
      if (bestRow != pivot) {
        final temporary = matrix[pivot];
        matrix[pivot] = matrix[bestRow];
        matrix[bestRow] = temporary;
      }

      final pivotValue = matrix[pivot][pivot];
      for (var column = pivot; column <= size; column++) {
        matrix[pivot][column] /= pivotValue;
      }
      for (var row = 0; row < size; row++) {
        if (row == pivot) continue;
        final factor = matrix[row][pivot];
        if (factor.abs() < 1e-24) continue;
        for (var column = pivot; column <= size; column++) {
          matrix[row][column] -= factor * matrix[pivot][column];
        }
      }
    }
    return List.generate(size, (row) => matrix[row][size]);
  }
}

class _SolverException implements Exception {
  final String message;

  const _SolverException(this.message);

  @override
  String toString() => message;
}

class _DiodeLinearization {
  final double current;
  final double conductance;
  final double equivalentCurrent;

  const _DiodeLinearization({
    required this.current,
    required this.conductance,
    required this.equivalentCurrent,
  });
}

class _MosfetLinearization {
  final double current;
  final double gm;
  final double gds;

  const _MosfetLinearization({
    required this.current,
    required this.gm,
    required this.gds,
  });
}
