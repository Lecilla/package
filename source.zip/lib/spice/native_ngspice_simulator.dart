import 'package:flutter/services.dart';

import '../services/netlist_generator.dart';
import 'circuit_model.dart';
import 'simulation_config.dart';
import 'simulation_result.dart';
import 'spice_simulator.dart';

class NativeNgspiceSimulator implements SpiceSimulator {
  static const MethodChannel _channel = MethodChannel(
    'circuit_simulator/ngspice',
  );
  final NetlistGenerator netlistGenerator;

  NativeNgspiceSimulator({NetlistGenerator? netlistGenerator})
    : netlistGenerator = netlistGenerator ?? NetlistGenerator();

  @override
  Future<SimulationResult> runTransient(
    CircuitModel circuit,
    SimulationConfig config,
  ) async {
    final netlist = netlistGenerator.generate(circuit, config);
    final raw = await runNetlist(netlist);
    return SimulationResult(
      success: false,
      rawOutput: raw,
      errors: const ['当前尚未接入 ngspice 原生库，已自动使用 MockSpiceSimulator。'],
      netlist: netlist,
    );
  }

  Future<String> runNetlist(String netlist) async {
    try {
      final result = await _channel.invokeMethod<String>('runNetlist', {
        'netlist': netlist,
      });
      return result ?? '';
    } on MissingPluginException {
      return '当前尚未接入 ngspice 原生库，已自动使用 MockSpiceSimulator。';
    }
  }
}
