import 'package:flutter/services.dart';

import '../services/netlist_generator.dart';
import 'circuit_model.dart';
import 'mock_spice_simulator.dart';
import 'simulation_config.dart';
import 'simulation_result.dart';
import 'spice_output_parser.dart';
import 'spice_simulator.dart';

class NativeNgspiceSimulator implements SpiceSimulator {
  static const MethodChannel _channel = MethodChannel(
    'circuit_simulator/ngspice',
  );
  final NetlistGenerator netlistGenerator;
  final SpiceSimulator fallback;

  NativeNgspiceSimulator({
    NetlistGenerator? netlistGenerator,
    SpiceSimulator? fallback,
  }) : netlistGenerator = netlistGenerator ?? NetlistGenerator(),
       fallback = fallback ?? MockSpiceSimulator();

  @override
  Future<SimulationResult> runTransient(
    CircuitModel circuit,
    SimulationConfig config,
  ) async {
    final netlist = netlistGenerator.generate(circuit, config);
    try {
      final raw = await runNetlist(netlist);
      if (raw.trim().isEmpty || raw.contains('尚未接入 ngspice 原生库')) {
        final mockResult = await fallback.runTransient(circuit, config);
        return SimulationResult(
          success: mockResult.success,
          time: mockResult.time,
          nodeVoltages: mockResult.nodeVoltages,
          branchCurrents: mockResult.branchCurrents,
          rawOutput: raw,
          errors: mockResult.errors,
          warnings: [
            '当前尚未接入 ngspice 原生库，已自动使用 MockSpiceSimulator。',
            ...mockResult.warnings,
          ],
          netlist: netlist,
        );
      }
      return SpiceOutputParser().parse(rawOutput: raw, netlist: netlist);
    } catch (error) {
      final mockResult = await fallback.runTransient(circuit, config);
      return SimulationResult(
        success: mockResult.success,
        time: mockResult.time,
        nodeVoltages: mockResult.nodeVoltages,
        branchCurrents: mockResult.branchCurrents,
        rawOutput: error.toString(),
        errors: mockResult.errors,
        warnings: [
          'ngspice 原生调用失败，已自动使用 MockSpiceSimulator：$error',
          ...mockResult.warnings,
        ],
        netlist: netlist,
      );
    }
  }

  Future<String> runNetlist(String netlist) async {
    try {
      final result = await _channel.invokeMethod<String>('runNetlist', {
        'netlist': netlist,
      });
      return result ?? '';
    } on MissingPluginException {
      return '当前尚未接入 ngspice 原生库，已自动使用 MockSpiceSimulator。';
    }
  }
}
