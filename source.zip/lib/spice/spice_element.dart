class SpiceElement {
  final String id;
  final String type;
  final String name;
  final String? node1;
  final String? node2;
  final String? node3;
  final String value;
  final Map<String, dynamic> params;

  const SpiceElement({
    required this.id,
    required this.type,
    required this.name,
    this.node1,
    this.node2,
    this.node3,
    required this.value,
    this.params = const {},
  });

  bool get isTwoTerminal => type != 'ground';
}
