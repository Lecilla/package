import 'circuit_model.dart';
import 'simulation_config.dart';
import 'simulation_result.dart';

abstract class SpiceSimulator {
  Future<SimulationResult> runTransient(
    CircuitModel circuit,
    SimulationConfig config,
  );
}
