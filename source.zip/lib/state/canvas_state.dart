import 'dart:async';

import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/component.dart';
import '../models/wire.dart';
import '../spice/circuit_model.dart';
import '../spice/simulation_result.dart';
import '../spice/simulation_config.dart';
import '../spice/spice_element.dart';
import '../spice/spice_value_parser.dart';

enum EditMode { idle, dragging, wiring }

class CanvasState extends ChangeNotifier {
  final List<CircuitComponent> _components = [];
  final List<Wire> _wires = [];
  CircuitComponent? _selectedComponent;
  Wire? _selectedWire;
  bool _isDrawingWire = false;
  EditMode _editMode = EditMode.idle;
  String? _wireStartComponentId;
  String? _wireStartPointId;
  Offset? _wireCurrentEnd;
  bool _isSimulationLoading = false;
  bool _isSimulationRunning = false;
  SimulationResult? _simulationResult;
  CircuitModel? _simulationCircuit;
  SimulationConfig? _simulationConfig;
  final List<SwitchEvent> _switchEvents = [];
  Timer? _simulationTimer;
  int _simulationSampleIndex = 0;
  bool _isSimulationPlaying = false;
  final Map<String, SpiceElement> _simulationElements = {};

  // ========== 历史记录（撤销/重做）==========
  final List<Map<String, dynamic>> _history = [];
  int _historyIndex = -1;

  bool get canUndo => _historyIndex > 0;
  bool get canRedo => _historyIndex < _history.length - 1;

  // Getters
  List<CircuitComponent> get components => _components;
  List<Wire> get wires => _wires;
  CircuitComponent? get selectedComponent => _selectedComponent;
  Wire? get selectedWire => _selectedWire;
  bool get isDrawingWire => _isDrawingWire;
  EditMode get editMode => _editMode;
  Offset? get wireCurrentEnd => _wireCurrentEnd;
  bool get isSimulationLoading => _isSimulationLoading;
  bool get isSimulationRunning => _isSimulationRunning;
  SimulationResult? get simulationResult => _simulationResult;
  CircuitModel? get simulationCircuit => _simulationCircuit;
  SimulationConfig? get simulationConfig => _simulationConfig;
  List<SwitchEvent> get switchEvents => List.unmodifiable(_switchEvents);
  bool get isSimulationPlaying => _isSimulationPlaying;
  double get simulationTime {
    final time = _simulationResult?.time;
    if (time == null || time.isEmpty) return 0;
    return time[_simulationSampleIndex.clamp(0, time.length - 1)];
  }

  double get simulationProgress {
    final time = _simulationResult?.time;
    if (time == null || time.length < 2) return 0;
    return _simulationSampleIndex / (time.length - 1);
  }

  void setSimulationLoading(bool value) {
    if (value) {
      _simulationTimer?.cancel();
      _isSimulationPlaying = false;
    }
    _isSimulationLoading = value;
    notifyListeners();
  }

  void applySimulationResult(
    CircuitModel circuit,
    SimulationResult result, {
    SimulationConfig? config,
    double resumeAt = 0,
  }) {
    _simulationElements
      ..clear()
      ..addEntries(
        circuit.elements.map((element) => MapEntry(element.id, element)),
      );
    _simulationResult = result;
    _simulationCircuit = circuit;
    _simulationConfig = config ?? _simulationConfig ?? const SimulationConfig();
    if (config != null) {
      _switchEvents
        ..clear()
        ..addAll(config.switchEvents);
    }
    _isSimulationLoading = false;
    _isSimulationRunning = result.success;
    _startPlayback(resumeAt: resumeAt);
    notifyListeners();
  }

  SwitchEvent registerSwitchEvent(String componentId, bool isClosed) {
    final event = SwitchEvent(
      componentId: componentId,
      time: simulationTime,
      isClosed: isClosed,
    );
    _switchEvents.add(event);
    _switchEvents.sort((a, b) => a.time.compareTo(b.time));
    final component = _components.firstWhere((item) => item.id == componentId);
    component.properties['isClosed'] = isClosed;
    _simulationTimer?.cancel();
    _isSimulationPlaying = false;
    notifyListeners();
    return event;
  }

  void rollbackSwitchEvent(SwitchEvent event) {
    _switchEvents.remove(event);
    final previous = _switchEvents
        .where((item) => item.componentId == event.componentId)
        .toList();
    final initial =
        _simulationElements[event.componentId]?.params['isClosed'] != false;
    final state = previous.isEmpty ? initial : previous.last.isClosed;
    for (final component in _components) {
      if (component.id == event.componentId) {
        component.properties['isClosed'] = state;
        break;
      }
    }
    notifyListeners();
  }

  void stopSimulation() {
    _clearSimulation();
    notifyListeners();
  }

  void _startPlayback({double resumeAt = 0}) {
    _simulationTimer?.cancel();
    final time = _simulationResult?.time;
    if (!_isSimulationRunning || time == null || time.isEmpty) {
      _isSimulationPlaying = false;
      return;
    }
    _simulationSampleIndex = 0;
    for (var i = 0; i < time.length; i++) {
      if (time[i] >= resumeAt) {
        _simulationSampleIndex = i;
        break;
      }
    }
    if (_simulationSampleIndex >= time.length - 1) {
      _isSimulationPlaying = false;
      return;
    }
    _isSimulationPlaying = true;
    final samplesPerTick = ((time.length - 1) / 200).ceil().clamp(1, 1000);
    _simulationTimer = Timer.periodic(const Duration(milliseconds: 50), (_) {
      _simulationSampleIndex = (_simulationSampleIndex + samplesPerTick).clamp(
        0,
        time.length - 1,
      );
      if (_simulationSampleIndex >= time.length - 1) {
        _simulationTimer?.cancel();
        _isSimulationPlaying = false;
      }
      notifyListeners();
    });
  }

  double? componentVoltage(String componentId) {
    if (!_isSimulationRunning) return null;
    final element = _simulationElements[componentId];
    if (element == null) return null;
    return _latestNodeVoltage(element.node1) -
        _latestNodeVoltage(element.node2);
  }

  double? componentCurrent(String componentId) {
    if (!_isSimulationRunning) return null;
    final element = _simulationElements[componentId];
    if (element == null) return null;
    final currents = _simulationResult?.branchCurrents;
    if (currents == null) return null;
    for (final key in [
      element.name,
      'V${element.name}',
      'I(${element.name})',
    ]) {
      final series = currents[key];
      if (series != null && series.isNotEmpty) {
        return series[_simulationSampleIndex.clamp(0, series.length - 1)];
      }
    }
    if (element.type == 'resistor' || element.type == 'switch') {
      try {
        final resistance = SpiceValueParser.parse(element.value).value;
        final voltage = componentVoltage(componentId);
        if (voltage != null && resistance != 0) return voltage / resistance;
      } on FormatException {
        return null;
      }
    }
    return null;
  }

  bool isLedLit(String componentId) {
    CircuitComponent? component;
    for (final candidate in _components) {
      if (candidate.id == componentId) {
        component = candidate;
        break;
      }
    }
    if (component == null || component.type != ComponentType.led) return false;
    if (!_isSimulationRunning) return component.properties['isLit'] == true;
    final voltage = componentVoltage(componentId) ?? 0;
    final current = componentCurrent(componentId) ?? 0;
    final threshold = SpiceValueParser.parse(
      component.properties['forwardVoltage'] ?? 2.0,
    ).value;
    return voltage >= threshold * 0.9 || current > 0.0001;
  }

  double _latestNodeVoltage(String? node) {
    if (node == null || node == '0') return 0;
    final values = _simulationResult?.nodeVoltages[node];
    if (values == null || values.isEmpty) return 0;
    return values[_simulationSampleIndex.clamp(0, values.length - 1)];
  }

  void _clearSimulation() {
    _simulationTimer?.cancel();
    _simulationTimer = null;
    _isSimulationLoading = false;
    _isSimulationRunning = false;
    _isSimulationPlaying = false;
    _simulationSampleIndex = 0;
    _simulationResult = null;
    _simulationCircuit = null;
    _simulationConfig = null;
    _switchEvents.clear();
    _simulationElements.clear();
  }

  void _invalidateSimulation() {
    if (_isSimulationLoading ||
        _isSimulationRunning ||
        _simulationResult != null) {
      _clearSimulation();
    }
  }

  // ========== 元件操作 ==========

  void addComponent(CircuitComponent component) {
    _invalidateSimulation();
    _components.add(component);
    _saveHistory();
    notifyListeners();
  }

  void addComponentByType(ComponentType type, Offset position) {
    _invalidateSimulation();
    final id = const Uuid().v4();
    final component = _createDefaultComponent(id, type, position);
    _components.add(component);
    selectComponent(component);
    _saveHistory();
    notifyListeners();
  }

  void selectComponent(CircuitComponent? component) {
    _selectedWire = null;
    if (_selectedComponent != null) {
      _selectedComponent!.isSelected = false;
    }
    _selectedComponent = component;
    if (_selectedComponent != null) {
      _selectedComponent!.isSelected = true;
    }
    notifyListeners();
  }

  void selectWire(Wire? wire) {
    if (_selectedComponent != null) {
      _selectedComponent!.isSelected = false;
    }
    _selectedComponent = null;
    _selectedWire = wire;
    notifyListeners();
  }

  void updateComponentPosition(String id, Offset newPosition) {
    final component = _components.firstWhere((c) => c.id == id);
    _editMode = EditMode.dragging;
    component.position = newPosition;
    notifyListeners();
  }

  void finishComponentDrag() {
    _editMode = EditMode.idle;
    _saveHistory();
    notifyListeners();
  }

  void updateSelectedProperty(String key, dynamic value) {
    if (_selectedComponent == null) return;
    _invalidateSimulation();
    _selectedComponent!.properties[key] = value;
    _saveHistory();
    notifyListeners();
  }

  void updateComponentName(String id, String name) {
    final component = _components.firstWhere((c) => c.id == id);
    component.properties['name'] = name.trim();
    _saveHistory();
    notifyListeners();
  }

  void updateSelectedRotation(double rotation) {
    if (_selectedComponent == null) return;
    _selectedComponent!.rotation = rotation;
    _saveHistory();
    notifyListeners();
  }

  void deleteComponent(String id) {
    _invalidateSimulation();
    _components.removeWhere((c) => c.id == id);
    _wires.removeWhere((w) => w.fromComponentId == id || w.toComponentId == id);
    if (_selectedComponent?.id == id) {
      _selectedComponent = null;
    }
    _selectedWire = null;
    _saveHistory();
    notifyListeners();
  }

  // ========== 连线操作 ==========

  void startWire(String componentId, String pointId) {
    _selectedWire = null;
    _isDrawingWire = true;
    _editMode = EditMode.wiring;
    _wireStartComponentId = componentId;
    _wireStartPointId = pointId;
    notifyListeners();
  }

  void deleteWire(String id) {
    _invalidateSimulation();
    _wires.removeWhere((w) => w.id == id);
    if (_selectedWire?.id == id) {
      _selectedWire = null;
    }
    _saveHistory();
    notifyListeners();
  }

  void updateWireEnd(Offset position) {
    if (!_isDrawingWire) return;
    _wireCurrentEnd = position;
    notifyListeners();
  }

  void endWire(String componentId, String pointId) {
    if (_wireStartComponentId == componentId && _wireStartPointId == pointId) {
      cancelWire();
      return;
    }

    if (_wireStartComponentId != null && _wireStartPointId != null) {
      _invalidateSimulation();
      _wires.add(
        Wire(
          id: const Uuid().v4(),
          fromComponentId: _wireStartComponentId!,
          fromPointId: _wireStartPointId!,
          toComponentId: componentId,
          toPointId: pointId,
        ),
      );
      _saveHistory();
    }
    cancelWire();
  }

  void cancelWire() {
    _isDrawingWire = false;
    _editMode = EditMode.idle;
    _wireStartComponentId = null;
    _wireStartPointId = null;
    _wireCurrentEnd = null;
    notifyListeners();
  }

  // ========== 案例加载 (就是这个方法解决了你的报错！) ==========

  /// 加载内置电路案例
  void loadBuiltinCircuit(dynamic circuit) {
    _clearSimulation();
    _components.clear();
    _wires.clear();
    _selectedComponent = null;
    _selectedWire = null;
    _isDrawingWire = false;
    _editMode = EditMode.idle;
    _wireStartComponentId = null;
    _wireStartPointId = null;
    _wireCurrentEnd = null;

    if (circuit.components != null) {
      for (final component in circuit.components) {
        final snapshot = _componentToSnapshot(component);
        _components.add(_componentFromSnapshot(snapshot));
      }
    }

    if (circuit.wires != null) {
      for (final wire in circuit.wires) {
        final snapshot = _wireToSnapshot(wire);
        _wires.add(_wireFromSnapshot(snapshot));
      }
    }

    _saveHistory();
    notifyListeners();
  }

  /// 从保存文件或分享文件恢复画布。
  ///
  /// 前端已有保存/打开入口，但旧版本没有真正恢复 components/wires。
  /// 这里复用当前 CanvasState 的元件和连线结构，不引入第二套画布模型。
  void loadFromData(Map<String, dynamic> data) {
    _clearSimulation();
    final componentsData = data['components'] as List? ?? const [];
    final wiresData = data['wires'] as List? ?? const [];

    _components.clear();
    _wires.clear();
    _selectedComponent = null;
    _selectedWire = null;
    _isDrawingWire = false;
    _editMode = EditMode.idle;
    _wireStartComponentId = null;
    _wireStartPointId = null;
    _wireCurrentEnd = null;

    for (final component in componentsData) {
      _components.add(
        _componentFromSnapshot(Map<String, dynamic>.from(component as Map)),
      );
    }

    for (final wire in wiresData) {
      _wires.add(_wireFromSnapshot(Map<String, dynamic>.from(wire as Map)));
    }

    _saveHistory();
    notifyListeners();
  }

  Map<String, dynamic> toData() {
    final now = DateTime.now().toIso8601String();
    return {
      'version': 1,
      'createdAt': now,
      'updatedAt': now,
      'components': _components.map((c) => _componentToSnapshot(c)).toList(),
      'wires': _wires.map((w) => _wireToSnapshot(w)).toList(),
    };
  }

  // ========== 撤销/重做 ==========

  void undo() {
    if (!canUndo) return;
    _clearSimulation();
    _historyIndex--;
    _restoreFromHistory();
  }

  void redo() {
    if (!canRedo) return;
    _clearSimulation();
    _historyIndex++;
    _restoreFromHistory();
  }

  void _saveHistory() {
    if (_historyIndex < _history.length - 1) {
      _history.removeRange(_historyIndex + 1, _history.length);
    }

    final snapshot = {
      'components': _components.map((c) => _componentToSnapshot(c)).toList(),
      'wires': _wires.map((w) => _wireToSnapshot(w)).toList(),
    };
    _history.add(snapshot);

    if (_history.length > 50) {
      _history.removeAt(0);
    } else {
      _historyIndex++;
    }
  }

  void _restoreFromHistory() {
    if (_historyIndex < 0 || _historyIndex >= _history.length) return;

    final snapshot = _history[_historyIndex];

    _components.clear();
    _wires.clear();

    for (final json in snapshot['components']) {
      _components.add(_componentFromSnapshot(json));
    }
    for (final json in snapshot['wires']) {
      _wires.add(_wireFromSnapshot(json));
    }

    _selectedComponent = null;
    _selectedWire = null;
    _isDrawingWire = false;
    _editMode = EditMode.idle;
    _wireStartComponentId = null;
    _wireStartPointId = null;
    _wireCurrentEnd = null;

    notifyListeners();
  }

  // ========== 快照序列化 ==========

  Map<String, dynamic> _componentToSnapshot(CircuitComponent c) {
    return {
      'id': c.id,
      'type': c.type.name,
      'x': c.position.dx,
      'y': c.position.dy,
      'rotation': c.rotation,
      'properties': Map<String, dynamic>.from(c.properties),
      'pins': c.pins
          .map((p) => {'id': p.id, 'px': p.offset.dx, 'py': p.offset.dy})
          .toList(),
    };
  }

  CircuitComponent _componentFromSnapshot(Map<String, dynamic> json) {
    final rawType = json['type'];
    final type = rawType is int
        ? ComponentType.values[rawType]
        : ComponentType.values.firstWhere(
            (candidate) => candidate.name == rawType,
            orElse: () => ComponentType.resistor,
          );

    return CircuitComponent(
      id: json['id'],
      type: type,
      position: Offset(
        (json['x'] as num).toDouble(),
        (json['y'] as num).toDouble(),
      ),
      rotation: (json['rotation'] as num? ?? 0).toDouble(),
      properties: Map<String, dynamic>.from(json['properties'] as Map? ?? {}),
      pins: (json['pins'] as List? ?? const [])
          .map(
            (p) => Pin(
              id: p['id'],
              offset: Offset(
                ((p['px'] ?? p['x']) as num).toDouble(),
                ((p['py'] ?? p['y']) as num).toDouble(),
              ),
            ),
          )
          .toList(),
    );
  }

  Map<String, dynamic> _wireToSnapshot(Wire w) {
    return {
      'id': w.id,
      'fromComponentId': w.fromComponentId,
      'fromPointId': w.fromPointId,
      'toComponentId': w.toComponentId,
      'toPointId': w.toPointId,
    };
  }

  Wire _wireFromSnapshot(Map<String, dynamic> json) {
    return Wire(
      id: json['id'],
      fromComponentId: json['fromComponentId'] ?? json['fc'],
      fromPointId: json['fromPointId'] ?? json['fp'],
      toComponentId: json['toComponentId'] ?? json['tc'],
      toPointId: json['toPointId'] ?? json['tp'],
    );
  }

  // ========== 辅助 ==========

  CircuitComponent _createDefaultComponent(
    String id,
    ComponentType type,
    Offset pos,
  ) {
    switch (type) {
      case ComponentType.resistor:
        return CircuitComponent(
          id: id,
          type: type,
          position: pos,
          properties: {'resistance': 1000.0},
          pins: const [
            Pin(id: 'p1', offset: Offset(-30, 0)),
            Pin(id: 'p2', offset: Offset(30, 0)),
          ],
        );
      case ComponentType.capacitor:
        return CircuitComponent(
          id: id,
          type: type,
          position: pos,
          properties: {'capacitance': 1e-6},
          pins: const [
            Pin(id: 'p1', offset: Offset(-20, 0)),
            Pin(id: 'p2', offset: Offset(20, 0)),
          ],
        );
      case ComponentType.voltageSource:
        return CircuitComponent(
          id: id,
          type: type,
          position: pos,
          properties: {'voltage': 5.0},
          pins: const [
            Pin(id: 'p1', offset: Offset(0, -30)),
            Pin(id: 'p2', offset: Offset(0, 30)),
          ],
        );
      case ComponentType.diode:
        return CircuitComponent(
          id: id,
          type: type,
          position: pos,
          properties: {'forwardVoltage': 0.7},
          pins: const [
            Pin(id: 'anode', offset: Offset(-24, 0)),
            Pin(id: 'cathode', offset: Offset(24, 0)),
          ],
        );
      case ComponentType.led:
        return CircuitComponent(
          id: id,
          type: type,
          position: pos,
          properties: {'forwardVoltage': 2.0, 'isLit': false},
          pins: const [
            Pin(id: 'anode', offset: Offset(-24, 0)),
            Pin(id: 'cathode', offset: Offset(24, 0)),
          ],
        );
      case ComponentType.mosfet:
        return CircuitComponent(
          id: id,
          type: type,
          position: pos,
          properties: {
            'thresholdVoltage': 2.0,
            'transconductance': 0.002,
            'lambda': 0.02,
          },
          pins: const [
            Pin(id: 'drain', offset: Offset(30, -20)),
            Pin(id: 'gate', offset: Offset(-30, 0)),
            Pin(id: 'source', offset: Offset(30, 20)),
          ],
        );
      case ComponentType.ground:
        return CircuitComponent(
          id: id,
          type: type,
          position: pos,
          properties: {},
          pins: const [Pin(id: 'gnd', offset: Offset(0, -20))],
        );
      case ComponentType.inductor:
        return CircuitComponent(
          id: id,
          type: type,
          position: pos,
          properties: {'inductance': 1e-3},
          pins: const [
            Pin(id: 'p1', offset: Offset(-30, 0)),
            Pin(id: 'p2', offset: Offset(30, 0)),
          ],
        );
      case ComponentType.voltmeter:
        return CircuitComponent(
          id: id,
          type: type,
          position: pos,
          properties: {'name': '电压表'},
          pins: const [
            Pin(id: 'p1', offset: Offset(-30, 0)),
            Pin(id: 'p2', offset: Offset(30, 0)),
          ],
        );
      case ComponentType.ammeter:
        return CircuitComponent(
          id: id,
          type: type,
          position: pos,
          properties: {'name': '电流表'},
          pins: const [
            Pin(id: 'p1', offset: Offset(-30, 0)),
            Pin(id: 'p2', offset: Offset(30, 0)),
          ],
        );
      case ComponentType.switchComponent:
        return CircuitComponent(
          id: id,
          type: type,
          position: pos,
          properties: {
            'name': '开关',
            'isClosed': true,
            'onResistance': '1m',
            'offResistance': '1Meg',
          },
          pins: const [
            Pin(id: 'p1', offset: Offset(-30, 0)),
            Pin(id: 'p2', offset: Offset(30, 0)),
          ],
        );
    }
  }

  void saveCurrentStateToHistory() {
    _saveHistory();
    notifyListeners();
  }

  void clear() {
    _clearSimulation();
    _components.clear();
    _wires.clear();
    _selectedComponent = null;
    _selectedWire = null;
    cancelWire();
    _saveHistory();
    notifyListeners();
  }

  @override
  void dispose() {
    _simulationTimer?.cancel();
    super.dispose();
  }
}
