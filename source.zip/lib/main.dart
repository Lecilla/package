import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:dynamic_color/dynamic_color.dart';

import 'state/canvas_state.dart';
import 'widgets/circuit_canvas.dart';
import 'widgets/left_toolbar.dart';
import 'widgets/right_panel.dart';
import 'services/circuit_to_spice_mapper.dart';
import 'spice/simulation_config.dart';
import 'spice/mock_spice_simulator.dart';
import 'spice/simulation_result.dart';
import 'widgets/waveform_viewer.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // 启用边缘到边缘模式并优化 Android 系统栏外观
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      systemNavigationBarColor: Colors.transparent,
      systemNavigationBarIconBrightness: Brightness.light,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarContrastEnforced: false,
    ),
  );
  runApp(const CircuitSimulatorApp());
}

class CircuitSimulatorApp extends StatelessWidget {
  const CircuitSimulatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => CanvasState(),
      child: DynamicColorBuilder(
        builder: (ColorScheme? lightDynamic, ColorScheme? darkDynamic) {
          ColorScheme darkScheme;
          if (darkDynamic != null) {
            darkScheme = darkDynamic.harmonized();
          } else {
            darkScheme = ColorScheme.fromSeed(
              seedColor: const Color(0xFF0f3460),
              brightness: Brightness.dark,
            );
          }

          return MaterialApp(
            title: '电路仿真 APP',
            debugShowCheckedModeBanner: false,
            theme: ThemeData(
              useMaterial3: true,
              colorScheme: darkScheme,
              brightness: Brightness.dark,
            ),
            home: const CircuitHomePage(),
          );
        },
      ),
    );
  }
}

class CircuitHomePage extends StatelessWidget {
  const CircuitHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final bool isMobile = MediaQuery.of(context).size.width < 800;
    final state = context.watch<CanvasState>();

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        
        // 1. 如果有选中的组件，优先取消选中
        if (state.selectedComponent != null) {
          state.selectComponent(null);
          return;
        }

        // 2. 如果正在画线，取消画线
        if (state.isDrawingWire) {
          state.cancelDrawingWire();
          return;
        }

        // 3. 最后提示退出
        final shouldPop = await _showExitConfirmation(context);
        if (shouldPop && context.mounted) {
          SystemNavigator.pop();
        }
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF1a1a2e),
        appBar: isMobile
            ? AppBar(
                title: const Text('电路仿真', style: TextStyle(fontSize: 18)),
                backgroundColor: const Color(0xFF0f3460),
                actions: [
                  if (state.selectedComponent != null)
                    IconButton(
                      icon: const Icon(
                        Icons.delete_outline,
                        color: Colors.redAccent,
                      ),
                      onPressed: () {
                        HapticFeedback.mediumImpact();
                        state.deleteComponent(state.selectedComponent!.id);
                      },
                    ),
                  IconButton(
                    icon: const Icon(Icons.undo),
                    onPressed: state.canUndo
                        ? () {
                            HapticFeedback.lightImpact();
                            state.undo();
                          }
                        : null,
                  ),
                  IconButton(
                    icon: const Icon(
                      Icons.play_arrow,
                      color: Colors.greenAccent,
                    ),
                    onPressed: () => _runSimulation(context),
                  ),
                  PopupMenuButton<String>(
                    onSelected: (value) => _handleMenuAction(context, value),
                    itemBuilder: (context) => [
                      const PopupMenuItem(value: 'clear', child: Text('清空画布')),
                      const PopupMenuItem(value: 'help', child: Text('使用帮助')),
                    ],
                  ),
                  Builder(
                    builder: (context) {
                      return IconButton(
                        icon: const Icon(Icons.tune),
                        onPressed: () => Scaffold.of(context).openEndDrawer(),
                      );
                    },
                  ),
                ],
              )
            : null,
        drawer: isMobile
            ? const Drawer(width: 100, child: LeftToolbar())
            : null,
        endDrawer: isMobile
            ? const Drawer(width: 300, child: RightPanel())
            : null,
        floatingActionButton: isMobile && !state.isDrawingWire
            ? Builder(
                builder: (fabContext) => FloatingActionButton(
                  onPressed: () {
                    HapticFeedback.lightImpact();
                    Scaffold.of(fabContext).openDrawer();
                  },
                  backgroundColor: const Color(0xFF0f3460),
                  child: const Icon(Icons.add, color: Colors.white),
                ),
              )
            : null,
        body: isMobile
            ? const CircuitCanvas()
            : const Row(
                children: [
                  SizedBox(width: 70, child: SafeArea(right: false, child: LeftToolbar())),
                  Expanded(child: CircuitCanvas()),
                  SizedBox(width: 250, child: SafeArea(left: false, child: RightPanel())),
                ],
              ),
      ),
    );
  }

  Future<bool> _showExitConfirmation(BuildContext context) async {
    return await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('退出应用?'),
            content: const Text('未保存的电路更改将会丢失。'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('取消'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('确定'),
              ),
            ],
          ),
        ) ??
        false;
  }

  void _handleMenuAction(BuildContext context, String action) {
    if (action == 'clear') {
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('清空画布?'),
          content: const Text('这将删除所有当前元件和连线。'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('取消'),
            ),
            TextButton(
              onPressed: () {
                HapticFeedback.heavyImpact();
                context.read<CanvasState>().clear();
                Navigator.pop(ctx);
              },
              child: const Text('确定', style: TextStyle(color: Colors.red)),
            ),
          ],
        ),
      );
      return;
    }
    if (action == 'help') {
      _showHelp(context);
    }
  }

  void _showHelp(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('使用帮助'),
        content: const Text(
          '1. 右下角 + 打开元件栏，点击元件即可添加。\n'
          '2. 拖动元件可以移动位置，双击画布可重置视图。\n'
          '3. 点击两个引脚可以连线，再点同一个引脚可取消。\n'
          '4. 点击元件后，在属性面板中修改参数和名称。\n'
          '5. 长按元件可旋转、改名或删除。',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('知道了'),
          ),
        ],
      ),
    );
  }

  Future<void> _runSimulation(BuildContext context) async {
    final state = context.read<CanvasState>();
    if (state.components.isEmpty) return;

    HapticFeedback.mediumImpact();
    try {
      final circuit = CircuitToSpiceMapper().map(state.components, state.wires);
      final config = SimulationConfig(
        analysisType: 'transient',
        nodesToPlot: circuit.observableNodes,
      );
      final result = await MockSpiceSimulator().runTransient(circuit, config);

      if (!context.mounted) return;
      if (!result.success) {
        _showError(context, result.errors);
      } else {
        _showResult(context, result);
      }
    } catch (e) {
      _showError(context, [e.toString()]);
    }
  }

  void _showError(BuildContext context, List<String> errors) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('错误'),
        content: Text(errors.join('\n')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('关闭'),
          ),
        ],
      ),
    );
  }

  void _showResult(BuildContext context, SimulationResult result) {
    showDialog(
      context: context,
      builder: (ctx) => Dialog.fullscreen(
        child: Scaffold(
          appBar: AppBar(
            title: const Text('仿真结果'),
            leading: IconButton(
              icon: const Icon(Icons.close),
              onPressed: () => Navigator.pop(ctx),
            ),
          ),
          body: Padding(
            padding: const EdgeInsets.all(16.0),
            child: WaveformViewer(
              timeData: result.time,
              voltageSeries: result.nodeVoltages,
            ),
          ),
        ),
      ),
    );
  }
}
