import 'component.dart';
import 'wire.dart';

class CircuitData {
  List<CircuitComponent> components;
  List<Wire> wires;
  String name;

  CircuitData({
    this.components = const [],
    this.wires = const [],
    this.name = '未命名电路',
  });
}
