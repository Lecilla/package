import 'package:flutter/material.dart';

enum ComponentType {
  resistor,
  capacitor,
  inductor,
  voltageSource,
  diode,
  led,
  mosfet,
  ground,
  voltmeter,
  ammeter,
  switchComponent,
}

class Pin {
  final String id;
  final Offset offset;

  const Pin({required this.id, required this.offset});

  Map<String, dynamic> toJson() => {'id': id, 'x': offset.dx, 'y': offset.dy};

  factory Pin.fromJson(Map<String, dynamic> json) {
    return Pin(
      id: json['id'] as String,
      offset: Offset(
        (json['x'] as num).toDouble(),
        (json['y'] as num).toDouble(),
      ),
    );
  }
}

class CircuitComponent {
  String id;
  ComponentType type;
  Offset position;
  double rotation;
  Map<String, dynamic> properties;
  List<Pin> pins;
  bool isSelected;

  CircuitComponent({
    required this.id,
    required this.type,
    required this.position,
    this.rotation = 0,
    Map<String, dynamic>? properties,
    required this.pins,
    this.isSelected = false,
  }) : properties = properties ?? {};

  String get displayName {
    switch (type) {
      case ComponentType.resistor:
        return '电阻';
      case ComponentType.capacitor:
        return '电容';
      case ComponentType.inductor:
        return '电感';
      case ComponentType.voltageSource:
        return '电压源';
      case ComponentType.diode:
        return '二极管';
      case ComponentType.led:
        return 'LED';
      case ComponentType.mosfet:
        return 'NMOS 场效应管';
      case ComponentType.ground:
        return '地';
      case ComponentType.voltmeter:
        return '电压表';
      case ComponentType.ammeter:
        return '电流表';
      case ComponentType.switchComponent:
        return '开关';
    }
  }

  String get userName =>
      (properties['name'] as String?)?.trim().isNotEmpty == true
      ? properties['name'] as String
      : displayName;

  String get spiceType {
    switch (type) {
      case ComponentType.resistor:
        return 'resistor';
      case ComponentType.capacitor:
        return 'capacitor';
      case ComponentType.inductor:
        return 'inductor';
      case ComponentType.voltageSource:
        return 'voltageSource';
      case ComponentType.diode:
        return 'diode';
      case ComponentType.led:
        return 'led';
      case ComponentType.mosfet:
        return 'mosfet';
      case ComponentType.ground:
        return 'ground';
      case ComponentType.voltmeter:
        return 'voltmeter';
      case ComponentType.ammeter:
        return 'ammeter';
      case ComponentType.switchComponent:
        return 'switch';
    }
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'type': type.name,
    'x': position.dx,
    'y': position.dy,
    'rotation': rotation,
    'properties': Map<String, dynamic>.from(properties),
    'pins': pins.map((pin) => pin.toJson()).toList(),
  };

  factory CircuitComponent.fromJson(Map<String, dynamic> json) {
    final typeValue = json['type'];
    final type = typeValue is int
        ? ComponentType.values[typeValue]
        : ComponentType.values.firstWhere(
            (candidate) => candidate.name == typeValue,
            orElse: () => ComponentType.resistor,
          );

    final pinsJson = (json['pins'] as List? ?? const []);
    return CircuitComponent(
      id: json['id'] as String,
      type: type,
      position: Offset(
        (json['x'] as num).toDouble(),
        (json['y'] as num).toDouble(),
      ),
      rotation: (json['rotation'] as num? ?? 0).toDouble(),
      properties: Map<String, dynamic>.from(json['properties'] as Map? ?? {}),
      pins: pinsJson
          .map((pin) => Pin.fromJson(Map<String, dynamic>.from(pin as Map)))
          .toList(),
    );
  }
}
