class Wire {
  final String id;
  final String fromComponentId;
  final String fromPointId;
  final String toComponentId;
  final String toPointId;

  const Wire({
    required this.id,
    required this.fromComponentId,
    required this.fromPointId,
    required this.toComponentId,
    required this.toPointId,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'fromComponentId': fromComponentId,
    'fromPointId': fromPointId,
    'toComponentId': toComponentId,
    'toPointId': toPointId,
  };

  factory Wire.fromJson(Map<String, dynamic> json) {
    return Wire(
      id: json['id'] as String,
      fromComponentId: (json['fromComponentId'] ?? json['fc']) as String,
      fromPointId: (json['fromPointId'] ?? json['fp']) as String,
      toComponentId: (json['toComponentId'] ?? json['tc']) as String,
      toPointId: (json['toPointId'] ?? json['tp']) as String,
    );
  }
}
