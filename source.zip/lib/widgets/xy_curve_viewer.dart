import 'dart:math';
import 'package:flutter/material.dart';

class XyCurveViewer extends StatelessWidget {
  final List<double> xData;
  final List<double> yData;
  final String xLabel;
  final String yLabel;
  final String title;

  const XyCurveViewer({
    super.key,
    required this.xData,
    required this.yData,
    this.xLabel = 'V',
    this.yLabel = 'I',
    this.title = 'V-I 特性曲线',
  });

  @override
  Widget build(BuildContext context) {
    if (xData.isEmpty || yData.isEmpty) {
      return const Center(child: Text('暂无曲线数据', style: TextStyle(color: Colors.white38)));
    }
    
    final count = min(xData.length, yData.length);
    final minX = xData.take(count).reduce(min);
    final maxX = xData.take(count).reduce(max);
    final minY = yData.take(count).reduce(min);
    final maxY = yData.take(count).reduce(max);
    final isNearlyStatic = (maxX - minX).abs() < 1e-9 || (maxY - minY).abs() < 1e-12;

    return Container(
      color: const Color(0xFF12121A), // 统一的科技深色背景
      child: CustomPaint(
        painter: _XyCurvePainter(
          xData: xData,
          yData: yData,
          xLabel: xLabel,
          yLabel: yLabel,
          title: title,
          isNearlyStatic: isNearlyStatic,
        ),
        child: const SizedBox.expand(),
      ),
    );
  }
}

class _XyCurvePainter extends CustomPainter {
  final List<double> xData;
  final List<double> yData;
  final String xLabel;
  final String yLabel;
  final String title;
  final bool isNearlyStatic;

  const _XyCurvePainter({required this.xData, required this.yData, required this.xLabel, required this.yLabel, required this.title, required this.isNearlyStatic});

  @override
  void paint(Canvas canvas, Size size) {
    const padding = EdgeInsets.fromLTRB(50, 40, 20, 40);
    final chart = Rect.fromLTWH(padding.left, padding.top, size.width - padding.horizontal, size.height - padding.vertical);

    // 1. 绘制网格背景
    final gridPaint = Paint()..color = Colors.white.withAlpha(15)..strokeWidth = 0.5;
    for (int i = 0; i <= 5; i++) {
      double x = chart.left + (chart.width / 5) * i;
      double y = chart.top + (chart.height / 5) * i;
      canvas.drawLine(Offset(x, chart.top), Offset(x, chart.bottom), gridPaint);
      canvas.drawLine(Offset(chart.left, y), Offset(chart.right, y), gridPaint);
    }

    // 2. 准备数据
    final count = min(xData.length, yData.length);
    final points = <Offset>[for (var i = 0; i < count; i++) Offset(xData[i], yData[i])]..sort((a, b) => a.dx.compareTo(b.dx));
    var minX = points.map((p) => p.dx).reduce(min);
    var maxX = points.map((p) => p.dx).reduce(max);
    var minY = points.map((p) => p.dy).reduce(min);
    var maxY = points.map((p) => p.dy).reduce(max);
    if ((maxX - minX).abs() < 1e-12) { minX -= 1; maxX += 1; }
    if ((maxY - minY).abs() < 1e-12) { minY -= 1; maxY += 1; }

    // 3. 绘制发光曲线特效
    final path = Path();
    for (var i = 0; i < points.length; i++) {
      final x = chart.left + (points[i].dx - minX) / (maxX - minX) * chart.width;
      final y = chart.bottom - (points[i].dy - minY) / (maxY - minY) * chart.height;
      i == 0 ? path.moveTo(x, y) : path.lineTo(x, y);
    }

    // 绘制发光层
    canvas.drawPath(path, Paint()
      ..color = Colors.greenAccent.withAlpha(60)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 8
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8));

    // 绘制主线
    canvas.drawPath(path, Paint()
      ..color = Colors.greenAccent
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeJoin = StrokeJoin.round);

    // 4. 绘制坐标文字
    final tp = TextPainter(textDirection: TextDirection.ltr);
    _drawText(canvas, tp, title, Offset(chart.left, 5), Colors.white70);
    _drawText(canvas, tp, '${maxY.toStringAsPrecision(3)} $yLabel', Offset(5, chart.top - 10), Colors.white54);
    _drawText(canvas, tp, '${minY.toStringAsPrecision(3)} $yLabel', Offset(5, chart.bottom - 5), Colors.white54);
    _drawText(canvas, tp, '${minX.toStringAsPrecision(3)} $xLabel', Offset(chart.left, chart.bottom + 5), Colors.white54);
    _drawText(canvas, tp, '${maxX.toStringAsPrecision(3)} $xLabel', Offset(chart.right - 40, chart.bottom + 5), Colors.white54);
  }

  void _drawText(Canvas canvas, TextPainter tp, String text, Offset offset, Color color) {
    tp.text = TextSpan(text: text, style: TextStyle(color: color, fontSize: 10));
    tp.layout();
    tp.paint(canvas, offset);
  }

  @override
  bool shouldRepaint(covariant _XyCurvePainter oldDelegate) => true;
}