import 'dart:math';

import 'package:flutter/material.dart';

class XyCurveViewer extends StatelessWidget {
  final List<double> xData;
  final List<double> yData;
  final String xLabel;
  final String yLabel;
  final String title;

  const XyCurveViewer({
    super.key,
    required this.xData,
    required this.yData,
    this.xLabel = 'V',
    this.yLabel = 'I',
    this.title = 'V-I 特性曲线',
  });

  @override
  Widget build(BuildContext context) {
    if (xData.isEmpty || yData.isEmpty) {
      return const Center(
        child: Text('暂无曲线数据', style: TextStyle(color: Colors.white38)),
      );
    }
    final count = min(xData.length, yData.length);
    final minX = xData.take(count).reduce(min);
    final maxX = xData.take(count).reduce(max);
    final minY = yData.take(count).reduce(min);
    final maxY = yData.take(count).reduce(max);
    final isNearlyStatic =
        (maxX - minX).abs() < 1e-9 || (maxY - minY).abs() < 1e-12;
    return CustomPaint(
      painter: _XyCurvePainter(
        xData: xData,
        yData: yData,
        xLabel: xLabel,
        yLabel: yLabel,
        title: title,
        isNearlyStatic: isNearlyStatic,
      ),
      child: const SizedBox.expand(),
    );
  }
}

class _XyCurvePainter extends CustomPainter {
  final List<double> xData;
  final List<double> yData;
  final String xLabel;
  final String yLabel;
  final String title;
  final bool isNearlyStatic;

  const _XyCurvePainter({
    required this.xData,
    required this.yData,
    required this.xLabel,
    required this.yLabel,
    required this.title,
    required this.isNearlyStatic,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final axisPaint = Paint()
      ..color = Colors.white24
      ..strokeWidth = 1;
    final curvePaint = Paint()
      ..color = Colors.greenAccent
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;
    final textPainter = TextPainter(textDirection: TextDirection.ltr);
    const padding = EdgeInsets.fromLTRB(48, 34, 18, 36);
    final chart = Rect.fromLTWH(
      padding.left,
      padding.top,
      size.width - padding.horizontal,
      size.height - padding.vertical,
    );

    canvas.drawLine(chart.bottomLeft, chart.bottomRight, axisPaint);
    canvas.drawLine(chart.bottomLeft, chart.topLeft, axisPaint);
    _drawText(canvas, textPainter, title, Offset(chart.left, 8), Colors.white70);

    final count = min(xData.length, yData.length);
    if (count < 2) return;
    final points = <Offset>[
      for (var i = 0; i < count; i++) Offset(xData[i], yData[i]),
    ]..sort((a, b) => a.dx.compareTo(b.dx));

    var minX = points.map((point) => point.dx).reduce(min);
    var maxX = points.map((point) => point.dx).reduce(max);
    var minY = points.map((point) => point.dy).reduce(min);
    var maxY = points.map((point) => point.dy).reduce(max);
    if ((maxX - minX).abs() < 1e-12) {
      minX -= 1;
      maxX += 1;
    }
    if ((maxY - minY).abs() < 1e-12) {
      minY -= 1;
      maxY += 1;
    }

    _drawText(
      canvas,
      textPainter,
      '${maxY.toStringAsPrecision(3)} $yLabel',
      Offset(4, chart.top - 6),
      Colors.white54,
    );
    _drawText(
      canvas,
      textPainter,
      '${minY.toStringAsPrecision(3)} $yLabel',
      Offset(4, chart.bottom - 10),
      Colors.white54,
    );
    _drawText(
      canvas,
      textPainter,
      '${minX.toStringAsPrecision(3)} $xLabel',
      Offset(chart.left, chart.bottom + 8),
      Colors.white54,
    );
    _drawText(
      canvas,
      textPainter,
      '${maxX.toStringAsPrecision(3)} $xLabel',
      Offset(chart.right - 58, chart.bottom + 8),
      Colors.white54,
    );

    if (isNearlyStatic) {
      _drawText(
        canvas,
        textPainter,
        '当前数据变化不足，VCR 曲线可能接近一个点或一条直线',
        Offset(chart.left, chart.top + 8),
        Colors.amberAccent,
      );
    }

    final path = Path();
    for (var i = 0; i < points.length; i++) {
      final x =
          chart.left + (points[i].dx - minX) / (maxX - minX) * chart.width;
      final y =
          chart.bottom - (points[i].dy - minY) / (maxY - minY) * chart.height;
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    canvas.drawPath(path, curvePaint);
    for (final point in points) {
      final x = chart.left + (point.dx - minX) / (maxX - minX) * chart.width;
      final y = chart.bottom - (point.dy - minY) / (maxY - minY) * chart.height;
      canvas.drawCircle(Offset(x, y), 2, Paint()..color = Colors.greenAccent);
    }
  }

  void _drawText(
    Canvas canvas,
    TextPainter tp,
    String text,
    Offset offset,
    Color color,
  ) {
    tp.text = TextSpan(text: text, style: TextStyle(color: color, fontSize: 10));
    tp.layout();
    tp.paint(canvas, offset);
  }

  @override
  bool shouldRepaint(covariant _XyCurvePainter oldDelegate) => true;
}
