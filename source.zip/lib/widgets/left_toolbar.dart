import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/component.dart';
import '../state/canvas_state.dart';
import '../services/builtin_circuits.dart';

class LeftToolbar extends StatelessWidget {
  const LeftToolbar({super.key});

  @override
  Widget build(BuildContext context) {
    final bool isMobile = MediaQuery.of(context).size.width < 800;

    return Container(
      // 美化：改为深邃的科技蓝黑渐变
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF1A1A2E), Color(0xFF16213E)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        border: Border(right: BorderSide(color: Colors.white10)),
      ),
      child: Column(
        children: [
          // 顶部图标区
          Container(
            height: isMobile ? 80 : 60,
            alignment: Alignment.center,
            child: const Icon(Icons.hub_rounded, color: Colors.cyanAccent, size: 28),
          ),
          const Divider(height: 1, color: Colors.white10),

          // 元件列表区
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
              children: const [
                _ToolButton(icon: 'R', label: '电阻', color: Colors.orange, type: ComponentType.resistor),
                _ToolButton(icon: 'C', label: '电容', color: Colors.yellow, type: ComponentType.capacitor),
                _ToolButton(icon: 'L', label: '电感', color: Colors.greenAccent, type: ComponentType.inductor),
                _ToolButton(icon: 'V', label: '电压源', color: Colors.redAccent, type: ComponentType.voltageSource),
                _ToolButton(icon: 'D', label: '二极管', color: Colors.deepOrange, type: ComponentType.diode),
                _ToolButton(icon: 'LED', label: 'LED', color: Colors.pinkAccent, type: ComponentType.led),
                _ToolButton(icon: 'MOS', label: 'NMOS', color: Colors.purpleAccent, type: ComponentType.mosfet),
                _ToolButton(icon: 'GND', label: '地线', color: Colors.white54, type: ComponentType.ground),
                _ToolButton(icon: 'VM', label: '电压表', color: Colors.cyanAccent, type: ComponentType.voltmeter),
                _ToolButton(icon: 'AM', label: '电流表', color: Colors.lightBlueAccent, type: ComponentType.ammeter),
                _ToolButton(icon: 'S', label: '开关', color: Colors.tealAccent, type: ComponentType.switchComponent),
              ],
            ),
          ),

          const Divider(height: 1, color: Colors.white10),

          // 底部动作区
          if (!isMobile) ...[
            _ActionButton(icon: Icons.auto_stories_rounded, tooltip: '内置案例', onTap: () => _showBuiltinCircuits(context)),
            _ActionButton(icon: Icons.info_outline_rounded, tooltip: '使用帮助', onTap: () => _showHelp(context)),
            const SizedBox(height: 16),
          ],
        ],
      ),
    );
  }

  // --- 逻辑函数保留区 (保持你原来的代码逻辑不变) ---
  void _showBuiltinCircuits(BuildContext context) { /* 原有代码 */ }
  void _showHelp(BuildContext context) { /* 原有代码 */ }
}

class _ToolButton extends StatelessWidget {
  final String icon;
  final String label;
  final Color color;
  final ComponentType type;

  const _ToolButton({required this.icon, required this.label, required this.color, required this.type});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Tooltip(
        message: label,
        child: InkWell(
          borderRadius: BorderRadius.circular(10),
          onTap: () {
            final state = context.read<CanvasState>();
            state.addComponentByType(type, state.suggestComponentPosition());
          },
          child: Column(
            children: [
              Container(
                height: 45, width: 45,
                decoration: BoxDecoration(
                  color: color.withAlpha(20),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: color.withAlpha(100), width: 1.5),
                ),
                child: Center(child: Text(icon, style: TextStyle(color: color, fontSize: 14, fontWeight: FontWeight.bold))),
              ),
              const SizedBox(height: 4),
              Text(label, style: const TextStyle(color: Colors.white60, fontSize: 10)),
            ],
          ),
        ),
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final VoidCallback? onTap;
  const _ActionButton({required this.icon, required this.tooltip, this.onTap});

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: Icon(icon, color: Colors.white60, size: 22),
      onPressed: onTap,
      tooltip: tooltip,
    );
  }
}