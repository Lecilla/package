import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/component.dart';
import '../state/canvas_state.dart';
import '../services/builtin_circuits.dart';

class LeftToolbar extends StatelessWidget {
  const LeftToolbar({super.key});

  @override
  Widget build(BuildContext context) {
    final bool isMobile = MediaQuery.of(context).size.width < 800;

    return Container(
      color: const Color(0xFF0f3460),
      child: Column(
        children: [
          // Header / Logo
          Container(
            height: isMobile ? 80 : 50,
            padding: const EdgeInsets.only(top: 20),
            alignment: Alignment.center,
            child: const Icon(
              Icons.electrical_services,
              color: Colors.white,
              size: 32,
            ),
          ),
          const Divider(height: 1, color: Colors.white24),

          // 元件列表
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
              children: const [
                _ToolButton(
                  icon: 'R',
                  label: '电阻',
                  color: Colors.orange,
                  type: ComponentType.resistor,
                ),
                _ToolButton(
                  icon: 'C',
                  label: '电容',
                  color: Colors.yellow,
                  type: ComponentType.capacitor,
                ),
                _ToolButton(
                  icon: 'L',
                  label: '电感',
                  color: Colors.green,
                  type: ComponentType.inductor,
                ),
                _ToolButton(
                  icon: 'V',
                  label: '电压源',
                  color: Colors.red,
                  type: ComponentType.voltageSource,
                ),
                _ToolButton(
                  icon: 'D',
                  label: '二极管',
                  color: Colors.deepOrangeAccent,
                  type: ComponentType.diode,
                ),
                _ToolButton(
                  icon: 'LED',
                  label: '发光二极管',
                  color: Colors.pinkAccent,
                  type: ComponentType.led,
                ),
                _ToolButton(
                  icon: 'M',
                  label: 'NMOS',
                  color: Colors.purpleAccent,
                  type: ComponentType.mosfet,
                ),
                _ToolButton(
                  icon: 'G',
                  label: '地线',
                  color: Colors.grey,
                  type: ComponentType.ground,
                ),
                _ToolButton(
                  icon: 'VM',
                  label: '电压表',
                  color: Colors.cyan,
                  type: ComponentType.voltmeter,
                ),
                _ToolButton(
                  icon: 'AM',
                  label: '电流表',
                  color: Colors.lightBlueAccent,
                  type: ComponentType.ammeter,
                ),
                _ToolButton(
                  icon: 'S',
                  label: '开关',
                  color: Colors.tealAccent,
                  type: ComponentType.switchComponent,
                ),
              ],
            ),
          ),

          const Divider(height: 1, color: Colors.white24),

          // 底部案例按钮 (仅在非手机模式显示，手机端放在 AppBar)
          if (!isMobile)
            _ActionButton(
              icon: Icons.menu_book,
              tooltip: '内置案例',
              onTap: () => _showBuiltinCircuits(context),
            ),
          if (!isMobile)
            _ActionButton(
              icon: Icons.help_outline,
              tooltip: '使用帮助',
              onTap: () => _showHelp(context),
            ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  void _showBuiltinCircuits(BuildContext context) {
    final circuits = BuiltinCircuits.all();
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: const Color(0xFF1a1a2e),
        title: const Text('内置案例', style: TextStyle(color: Colors.white)),
        content: SizedBox(
          width: 300,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: circuits.length,
            itemBuilder: (context, index) {
              final circuit = circuits[index];
              return ListTile(
                leading: const Icon(Icons.electric_bolt, color: Colors.blue),
                title: Text(
                  circuit.name,
                  style: const TextStyle(color: Colors.white),
                ),
                subtitle: Text(
                  circuit.description,
                  style: const TextStyle(color: Colors.white54, fontSize: 11),
                ),
                onTap: () {
                  context.read<CanvasState>().loadBuiltinCircuit(circuit);
                  Navigator.pop(dialogContext);
                },
              );
            },
          ),
        ),
      ),
    );
  }

  void _showHelp(BuildContext context) {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: const Color(0xFF1a1a2e),
        title: const Text('使用帮助', style: TextStyle(color: Colors.white)),
        content: const Text(
          '1. 点击左侧元件添加到画布。\n'
          '2. 拖动元件可以调整位置。\n'
          '3. 点击两个引脚可以连线。\n'
          '4. 点击元件后可在右侧修改参数和名称。\n'
          '5. 运行仿真后可在右侧切换开关，系统会记录切换时刻并更新前后波形。\n'
          '6. 长按元件可旋转、改名或删除。',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('知道了'),
          ),
        ],
      ),
    );
  }
}

class _ToolButton extends StatelessWidget {
  final String icon;
  final String label;
  final Color color;
  final ComponentType type;

  const _ToolButton({
    required this.icon,
    required this.label,
    required this.color,
    required this.type,
  });

  @override
  Widget build(BuildContext context) {
    final bool isMobile = MediaQuery.of(context).size.width < 800;

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: () {
          final state = context.read<CanvasState>();
          state.addComponentByType(type, state.suggestComponentPosition());
          if (isMobile) {
            Navigator.pop(context); // 手机端添加完自动关闭侧边栏
          }
        },
        child: Column(
          children: [
            Container(
              height: 50,
              width: 50,
              decoration: BoxDecoration(
                color: color.withAlpha(40),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: color.withAlpha(150), width: 2),
              ),
              child: Center(
                child: Text(
                  icon,
                  style: TextStyle(
                    color: color,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            ...[
              const SizedBox(height: 4),
              Text(
                label,
                textAlign: TextAlign.center,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white70, fontSize: 11),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final VoidCallback? onTap;

  const _ActionButton({required this.icon, required this.tooltip, this.onTap});

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: Icon(icon, color: Colors.white70),
      onPressed: onTap,
      tooltip: tooltip,
    );
  }
}
