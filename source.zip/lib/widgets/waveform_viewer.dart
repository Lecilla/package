import 'dart:math';
import 'package:flutter/material.dart';

class WaveformViewer extends StatefulWidget {
  final List<double> timeData;
  final Map<String, List<double>>? voltageSeries;
  final List<double> eventTimes;
  final String unit;

  const WaveformViewer({
    super.key,
    required this.timeData,
    this.voltageSeries,
    this.eventTimes = const [],
    this.unit = 'V',
  });

  @override
  State<WaveformViewer> createState() => _WaveformViewerState();
}

class _WaveformViewerState extends State<WaveformViewer> {
  double _horizontalScale = 1.0;
  Offset? _touchPosition;

  @override
  Widget build(BuildContext context) {
    if (widget.timeData.isEmpty || (widget.voltageSeries?.isEmpty ?? true)) {
      return const Center(
        child: Text('暂无波形数据', style: TextStyle(color: Colors.white38)),
      );
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        return GestureDetector(
          onDoubleTap: () => setState(() { _horizontalScale = 1.0; _touchPosition = null; }),
          onScaleUpdate: (details) => setState(() => _horizontalScale = (_horizontalScale * details.horizontalScale).clamp(1.0, 10.0)),
          onPanUpdate: (details) => setState(() => _touchPosition = details.localPosition),
          onPanEnd: (_) => setState(() => _touchPosition = null),
          child: Container(
            color: const Color(0xFF12121A), // 统一使用深色背景
            child: Stack(
              children: [
                InteractiveViewer(
                  constrained: false,
                  scaleEnabled: false,
                  child: SizedBox(
                    width: constraints.maxWidth * _horizontalScale,
                    height: constraints.maxHeight,
                    child: CustomPaint(
                      painter: _WaveformPainter(
                        timeData: widget.timeData,
                        series: widget.voltageSeries!,
                        eventTimes: widget.eventTimes,
                        unit: widget.unit,
                        touchPosition: _touchPosition,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _WaveformPainter extends CustomPainter {
  static const _colors = [Colors.cyanAccent, Colors.greenAccent, Colors.orangeAccent, Colors.pinkAccent];
  final List<double> timeData;
  final Map<String, List<double>> series;
  final Offset? touchPosition;
  final List<double> eventTimes;
  final String unit;

  const _WaveformPainter({required this.timeData, required this.series, this.eventTimes = const [], this.unit = 'V', this.touchPosition});

  @override
  void paint(Canvas canvas, Size size) {
    const padding = EdgeInsets.fromLTRB(42, 30, 20, 32);
    final chart = Rect.fromLTWH(padding.left, padding.top, size.width - padding.horizontal, size.height - padding.vertical);
    
    // 绘制微弱的网格线
    final gridPaint = Paint()..color = Colors.white10..strokeWidth = 0.5;
    canvas.drawRect(chart, gridPaint);

    final allValues = series.values.expand((v) => v).toList();
    final minT = timeData.first;
    final maxT = timeData.last == minT ? minT + 1 : timeData.last;
    var minV = allValues.reduce(min);
    var maxV = allValues.reduce(max);
    if ((maxV - minV).abs() < 1e-12) { minV -= 1; maxV += 1; }

    var index = 0;
    for (final entry in series.entries) {
      final values = entry.value;
      final path = Path();
      for (var i = 0; i < values.length && i < timeData.length; i++) {
        final x = chart.left + (timeData[i] - minT) / (maxT - minT) * chart.width;
        final y = chart.bottom - (values[i] - minV) / (maxV - minV) * chart.height;
        i == 0 ? path.moveTo(x, y) : path.lineTo(x, y);
      }

      // 1. 填充渐变效果
      final fillPath = Path.from(path)..lineTo(chart.right, chart.bottom)..lineTo(chart.left, chart.bottom)..close();
      canvas.drawPath(fillPath, Paint()..shader = LinearGradient(
        begin: Alignment.topCenter, end: Alignment.bottomCenter,
        colors: [_colors[index % _colors.length].withAlpha(60), Colors.transparent],
      ).createShader(chart));

      // 2. 绘制平滑主线
      canvas.drawPath(path, Paint()
        ..color = _colors[index % _colors.length]
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5
        ..strokeJoin = StrokeJoin.round);
      index++;
    }
  }

  @override
  bool shouldRepaint(covariant _WaveformPainter old) => true;
}