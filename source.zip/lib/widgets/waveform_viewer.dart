import 'package:flutter/material.dart';

class WaveformViewer extends StatefulWidget {
  final List<double> timeData;
  final Map<String, List<double>>? voltageSeries;

  const WaveformViewer({super.key, required this.timeData, this.voltageSeries});

  @override
  State<WaveformViewer> createState() => _WaveformViewerState();
}

class _WaveformViewerState extends State<WaveformViewer> {
  double _horizontalScale = 1.0;
  Offset? _touchPosition;

  @override
  Widget build(BuildContext context) {
    if (widget.timeData.isEmpty || (widget.voltageSeries?.isEmpty ?? true)) {
      return const Center(
        child: Text('暂无波形数据', style: TextStyle(color: Colors.white38)),
      );
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        return GestureDetector(
          onScaleUpdate: (details) {
            setState(() {
              _horizontalScale = (_horizontalScale * details.horizontalScale)
                  .clamp(1.0, 10.0);
            });
          },
          onPanUpdate: (details) {
            setState(() {
              _touchPosition = details.localPosition;
            });
          },
          onPanEnd: (_) {
            setState(() {
              _touchPosition = null;
            });
          },
          child: Stack(
            children: [
              InteractiveViewer(
                constrained: false,
                scaleEnabled: false,
                child: SizedBox(
                  width: constraints.maxWidth * _horizontalScale,
                  height: constraints.maxHeight,
                  child: CustomPaint(
                    painter: _WaveformPainter(
                      timeData: widget.timeData,
                      series: widget.voltageSeries!,
                      touchPosition: _touchPosition,
                    ),
                  ),
                ),
              ),
              if (_touchPosition != null)
                Positioned(
                  top: 10,
                  right: 10,
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.black.withAlpha(150),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.white24),
                    ),
                    child: _buildValueTooltip(),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildValueTooltip() {
    if (_touchPosition == null) {
      return const SizedBox.shrink();
    }

    // 估算最接近的数据点
    final totalWidth = MediaQuery.of(context).size.width * _horizontalScale;
    const paddingLeft = 42.0;
    const paddingRight = 14.0;
    final chartWidth = totalWidth - paddingLeft - paddingRight;

    final relativeX = (_touchPosition!.dx - paddingLeft) / chartWidth;
    if (relativeX < 0 || relativeX > 1) {
      return const Text('---', style: TextStyle(color: Colors.white));
    }

    final dataIndex = (relativeX * (widget.timeData.length - 1)).round().clamp(
      0,
      widget.timeData.length - 1,
    );
    final time = widget.timeData[dataIndex];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          '时间: ${time.toStringAsFixed(4)} s',
          style: const TextStyle(color: Colors.white70, fontSize: 12),
        ),
        const Divider(height: 8, color: Colors.white24),
        ...widget.voltageSeries!.entries.map((e) {
          final val = e.value[dataIndex];
          return Text(
            '${e.key}: ${val.toStringAsFixed(2)} V',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
          );
        }),
      ],
    );
  }
}

class _WaveformPainter extends CustomPainter {
  static const _colors = [
    Colors.lightBlueAccent,
    Colors.greenAccent,
    Colors.orangeAccent,
    Colors.pinkAccent,
    Colors.purpleAccent,
  ];

  final List<double> timeData;
  final Map<String, List<double>> series;
  final Offset? touchPosition;

  const _WaveformPainter({
    required this.timeData,
    required this.series,
    this.touchPosition,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final axisPaint = Paint()
      ..color = Colors.white24
      ..strokeWidth = 1;
    final textPainter = TextPainter(textDirection: TextDirection.ltr);
    const padding = EdgeInsets.fromLTRB(42, 30, 14, 32);
    final chart = Rect.fromLTWH(
      padding.left,
      padding.top,
      size.width - padding.horizontal,
      size.height - padding.vertical,
    );

    canvas.drawLine(chart.bottomLeft, chart.bottomRight, axisPaint);
    canvas.drawLine(chart.bottomLeft, chart.topLeft, axisPaint);

    final allValues = series.values.expand((v) => v).toList();
    if (allValues.isEmpty) {
      return;
    }

    final minT = timeData.first;
    final maxT = timeData.last == minT ? minT + 1 : timeData.last;
    var minV = allValues.reduce((a, b) => a < b ? a : b);
    var maxV = allValues.reduce((a, b) => a > b ? a : b);
    if ((maxV - minV).abs() < 1e-12) {
      minV -= 1;
      maxV += 1;
    }

    _drawText(
      canvas,
      textPainter,
      '${maxV.toStringAsFixed(1)}V',
      Offset(4, chart.top - 6),
      Colors.white54,
    );
    _drawText(
      canvas,
      textPainter,
      '${minV.toStringAsFixed(1)}V',
      Offset(4, chart.bottom - 10),
      Colors.white54,
    );

    var index = 0;
    for (final entry in series.entries) {
      final values = entry.value;
      if (values.isEmpty) {
        continue;
      }

      final path = Path();
      for (var i = 0; i < values.length && i < timeData.length; i++) {
        final x =
            chart.left + (timeData[i] - minT) / (maxT - minT) * chart.width;
        final y =
            chart.bottom - (values[i] - minV) / (maxV - minV) * chart.height;
        if (i == 0) {
          path.moveTo(x, y);
        } else {
          path.lineTo(x, y);
        }
      }

      final color = _colors[index % _colors.length];
      canvas.drawPath(
        path,
        Paint()
          ..color = color
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2,
      );
      index++;
    }

    // 绘制触摸垂线
    if (touchPosition != null &&
        touchPosition!.dx >= chart.left &&
        touchPosition!.dx <= chart.right) {
      canvas.drawLine(
        Offset(touchPosition!.dx, chart.top),
        Offset(touchPosition!.dx, chart.bottom),
        Paint()
          ..color = Colors.white54
          ..strokeWidth = 1
          ..style = PaintingStyle.stroke,
      );
    }
  }

  void _drawText(
    Canvas canvas,
    TextPainter tp,
    String text,
    Offset offset,
    Color color,
  ) {
    tp.text = TextSpan(
      text: text,
      style: TextStyle(color: color, fontSize: 10),
    );
    tp.layout();
    tp.paint(canvas, offset);
  }

  @override
  bool shouldRepaint(covariant _WaveformPainter old) => true;
}
