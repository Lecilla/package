import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../models/component.dart';
import '../models/wire.dart';
import '../state/canvas_state.dart';
import '../spice/simulation_result.dart';

class CircuitCanvas extends StatefulWidget {
  const CircuitCanvas({super.key});

  @override
  State<CircuitCanvas> createState() => _CircuitCanvasState();
}

class _CircuitCanvasState extends State<CircuitCanvas> {
  final TransformationController _transformationController =
      TransformationController();

  void _resetView() {
    _transformationController.value = Matrix4.identity();
    HapticFeedback.mediumImpact();
  }

  void _showComponentMenu(
    BuildContext context,
    CanvasState state,
    CircuitComponent component,
  ) {
    HapticFeedback.heavyImpact();
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1a1a2e),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                '元件操作: ${component.displayName}',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            ListTile(
              leading: const Icon(
                Icons.edit_outlined,
                color: Colors.greenAccent,
              ),
              title: Text(
                '名称: ${component.userName}',
                style: const TextStyle(color: Colors.white),
              ),
              onTap: () {
                Navigator.pop(context);
                _showRenameDialog(context, state, component);
              },
            ),
            ListTile(
              leading: const Icon(Icons.rotate_right, color: Colors.blueAccent),
              title: const Text(
                '旋转 90°',
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                state.selectComponent(component);
                state.updateSelectedRotation((component.rotation + 90) % 360);
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(
                Icons.delete_outline,
                color: Colors.redAccent,
              ),
              title: const Text('删除元件', style: TextStyle(color: Colors.white)),
              onTap: () {
                state.deleteComponent(component.id);
                Navigator.pop(context);
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  void _showRenameDialog(
    BuildContext context,
    CanvasState state,
    CircuitComponent component,
  ) {
    final controller = TextEditingController(text: component.userName);
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: const Color(0xFF1a1a2e),
        title: const Text('修改元件名称', style: TextStyle(color: Colors.white)),
        content: TextField(
          controller: controller,
          autofocus: true,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(
            labelText: '名称',
            labelStyle: TextStyle(color: Colors.white70),
          ),
          onSubmitted: (_) {
            state.updateComponentName(component.id, controller.text);
            Navigator.pop(dialogContext);
          },
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () {
              state.updateComponentName(component.id, controller.text);
              Navigator.pop(dialogContext);
            },
            child: const Text('保存'),
          ),
        ],
      ),
    );
  }

  void _showWireMenu(BuildContext context, CanvasState state, Wire wire) {
    HapticFeedback.heavyImpact();
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1a1a2e),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                '连线操作',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            ListTile(
              leading: const Icon(
                Icons.delete_outline,
                color: Colors.redAccent,
              ),
              title: const Text('删除连线', style: TextStyle(color: Colors.white)),
              onTap: () {
                state.deleteWire(wire.id);
                Navigator.pop(context);
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  Wire? _findWireAt(CanvasState state, Offset scenePoint) {
    final componentsById = {
      for (final component in state.components) component.id: component,
    };
    for (final wire in state.wires.reversed) {
      final from = _pinOffset(
        componentsById[wire.fromComponentId],
        wire.fromPointId,
      );
      final to = _pinOffset(componentsById[wire.toComponentId], wire.toPointId);
      if (from == null || to == null) {
        continue;
      }
      if (_distanceToSegment(scenePoint, from, to) <= 14) {
        return wire;
      }
    }
    return null;
  }

  Offset? _pinOffset(CircuitComponent? component, String pinId) {
    if (component == null) {
      return null;
    }
    for (final pin in component.pins) {
      if (pin.id == pinId) {
        return component.position + pin.offset;
      }
    }
    return null;
  }

  double _distanceToSegment(Offset point, Offset start, Offset end) {
    final segment = end - start;
    final lengthSquared = segment.dx * segment.dx + segment.dy * segment.dy;
    if (lengthSquared == 0) {
      return (point - start).distance;
    }
    final rawT =
        ((point.dx - start.dx) * segment.dx +
            (point.dy - start.dy) * segment.dy) /
        lengthSquared;
    final t = rawT.clamp(0.0, 1.0);
    final projection = Offset(
      start.dx + segment.dx * t,
      start.dy + segment.dy * t,
    );
    return (point - projection).distance;
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<CanvasState>(
      builder: (context, state, child) {
        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapUp: (details) {
            final scenePoint = _transformationController.toScene(
              details.localPosition,
            );
            final wire = _findWireAt(state, scenePoint);
            if (wire != null) {
              state.selectWire(wire);
              HapticFeedback.selectionClick();
            } else {
              state.selectComponent(null);
            }
          },
          onLongPressStart: (details) {
            final scenePoint = _transformationController.toScene(
              details.localPosition,
            );
            final wire = _findWireAt(state, scenePoint);
            if (wire != null) {
              state.selectWire(wire);
              _showWireMenu(context, state, wire);
            }
          },
          onDoubleTap: _resetView,
          child: InteractiveViewer(
            transformationController: _transformationController,
            boundaryMargin: const EdgeInsets.all(1000),
            minScale: 0.2,
            maxScale: 3.0,
            // 允许平移以在手机上导航大画布
            panEnabled: true,
            scaleEnabled: true,
            child: Container(
              width: 2000,
              height: 2000,
              color: Colors.transparent,
              child: CustomPaint(
                painter: _CircuitPainter(
                  components: state.components,
                  wires: state.wires,
                  selectedWireId: state.selectedWire?.id,
                ),
                child: Stack(
                  children: [
                    for (final component in state.components)
                      Positioned(
                        left: component.position.dx - 48,
                        top: component.position.dy - 34,
                        child: GestureDetector(
                          onTap: () {
                            if (component.type == ComponentType.switchComponent) {
                              state.toggleSwitch(component.id);
                              HapticFeedback.lightImpact();
                            } else {
                              state.selectComponent(component);
                              HapticFeedback.selectionClick();
                            }
                          },
                          onLongPress: () =>
                              _showComponentMenu(context, state, component),
                          onDoubleTap: () =>
                              _showRenameDialog(context, state, component),
                          onPanUpdate: (details) {
                            state.selectComponent(component);
                            final scale = _transformationController.value
                                .getMaxScaleOnAxis()
                                .clamp(0.2, 3.0);
                            state.updateComponentPosition(
                              component.id,
                              component.position + details.delta / scale,
                            );
                          },
                          onPanEnd: (_) {
                            // 拖动结束保存历史
                            state.saveCurrentStateToHistory();
                          },
                          child: _ComponentHitBox(component: component),
                        ),
                      ),
                    for (final component in state.components)
                      for (final pin in component.pins)
                        Positioned(
                          left: component.position.dx + pin.offset.dx - 20,
                          top: component.position.dy + pin.offset.dy - 20,
                          child: GestureDetector(
                            onTap: () {
                              if (state.isDrawingWire) {
                                state.endWire(component.id, pin.id);
                                HapticFeedback.heavyImpact();
                              } else {
                                state.startWire(component.id, pin.id);
                                HapticFeedback.lightImpact();
                              }
                            },
                            child: Container(
                              width: 40,
                              height: 40,
                              color: Colors.transparent,
                              child: Center(
                                child: Container(
                                  width: 12,
                                  height: 12,
                                  decoration: BoxDecoration(
                                    color:
                                        state.isDrawingWire &&
                                            state.selectedComponent?.id ==
                                                component.id
                                        ? Colors.orange
                                        : Colors.white,
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: Colors.blueAccent,
                                      width: 2,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _ComponentHitBox extends StatelessWidget {
  final CircuitComponent component;
  const _ComponentHitBox({required this.component});

  @override
  Widget build(BuildContext context) {
    return Transform.rotate(
      angle: component.rotation * 3.141592653589793 / 180,
      child: Container(
        width: 96,
        height: 68,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: component.isSelected
              ? Colors.blue.withAlpha(40)
              : Colors.transparent,
          border: Border.all(
            color: component.isSelected
                ? Colors.blueAccent
                : Colors.transparent,
            width: 2,
          ),
          borderRadius: BorderRadius.circular(8),
          boxShadow: [
            if (component.type == ComponentType.led &&
                (component.properties['isLit'] ?? false))
              BoxShadow(
                color: Colors.redAccent.withAlpha(100),
                blurRadius: 12,
                spreadRadius: 1,
              ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              _label(component),
              style: TextStyle(
                color: _color(component),
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 2),
            _buildReading(context),
            Text(
              component.userName,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.white70, fontSize: 10),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildReading(BuildContext context) {
    final state = context.watch<CanvasState>();
    final result = state.lastSimulationResult;
    if (result == null || !result.success) return const SizedBox.shrink();

    String reading = '';
    if (component.type == ComponentType.voltmeter) {
      // 简单模拟：获取最后一个时间点的读数
      final value = _getVoltmeterValue(state, result);
      reading = '${value.toStringAsFixed(2)}V';
    } else if (component.type == ComponentType.ammeter) {
      final value = _getAmmeterValue(state, result);
      reading = '${(value * 1000).toStringAsFixed(1)}mA';
    }

    if (reading.isEmpty) return const SizedBox.shrink();

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
      decoration: BoxDecoration(
        color: Colors.black54,
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(
        reading,
        style: const TextStyle(
          color: Colors.greenAccent,
          fontSize: 10,
          fontFamily: 'monospace',
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  double _getVoltmeterValue(CanvasState state, SimulationResult result) {
    final pinMap = result.componentNodeMap[component.id];
    if (pinMap == null) return 0.0;

    // 获取电压表两端的节点名称
    final n1 = pinMap['p1'];
    final n2 = pinMap['p2'];

    // 从仿真结果中提取最后时刻的电压值
    final v1 = (n1 == '0' || n1 == null) ? 0.0 : (result.nodeVoltages[n1]?.last ?? 0.0);
    final v2 = (n2 == '0' || n2 == null) ? 0.0 : (result.nodeVoltages[n2]?.last ?? 0.0);

    return (v1 - v2).abs();
  }

  double _getAmmeterValue(CanvasState state, SimulationResult result) {
    final pinMap = result.componentNodeMap[component.id];
    if (pinMap == null) return 0.0;

    final spiceName = pinMap['__name__'];
    if (spiceName != null) {
      // 在 NetlistGenerator 中，ammeter 对应的是 V+name，例如 VAM1
      final currentKey = 'i(v$spiceName)'.toLowerCase();
      for (final entry in result.branchCurrents.entries) {
        if (entry.key.toLowerCase() == currentKey) {
          return entry.value.last.abs();
        }
      }
    }

    // Fallback logic
    final n1 = pinMap['p1'];
    final n2 = pinMap['p2'];
    final v1 = (n1 == '0' || n1 == null) ? 0.0 : (result.nodeVoltages[n1]?.last ?? 0.0);
    final v2 = (n2 == '0' || n2 == null) ? 0.0 : (result.nodeVoltages[n2]?.last ?? 0.0);
    
    return (v1 - v2).abs() / 100.0;
  }

  String _label(CircuitComponent component) {
    switch (component.type) {
      case ComponentType.resistor:
        return 'R';
      case ComponentType.capacitor:
        return 'C';
      case ComponentType.inductor:
        return 'L';
      case ComponentType.voltageSource:
        return 'V';
      case ComponentType.led:
        return component.properties['isLit'] == true ? '● LED' : '○ LED';
      case ComponentType.ground:
        return 'GND';
      case ComponentType.voltmeter:
        return 'V表';
      case ComponentType.ammeter:
        return 'A表';
      case ComponentType.switchComponent:
        return component.properties['isClosed'] == false ? '断开' : '闭合';
    }
  }

  Color _color(CircuitComponent component) {
    if (component.type == ComponentType.switchComponent) {
      return (component.properties['isClosed'] ?? false)
          ? Colors.greenAccent
          : Colors.redAccent;
    }
    switch (component.type) {
      case ComponentType.resistor:
        return Colors.orange;
      case ComponentType.capacitor:
        return Colors.yellow;
      case ComponentType.inductor:
        return Colors.greenAccent;
      case ComponentType.voltageSource:
        return Colors.redAccent;
      case ComponentType.led:
        return (component.properties['isLit'] ?? false)
            ? Colors.redAccent
            : Colors.purpleAccent;
      case ComponentType.ground:
        return Colors.white70;
      case ComponentType.voltmeter:
        return Colors.cyanAccent;
      case ComponentType.ammeter:
        return Colors.lightBlueAccent;
      case ComponentType.switchComponent:
        return Colors.tealAccent;
    }
  }
}

class _CircuitPainter extends CustomPainter {
  final List<CircuitComponent> components;
  final List<Wire> wires;
  final String? selectedWireId;

  const _CircuitPainter({
    required this.components,
    required this.wires,
    this.selectedWireId,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final gridPaint = Paint()
      ..color = Colors.white.withAlpha(15)
      ..strokeWidth = 1;
    for (var x = 0.0; x < 2000; x += 40) {
      canvas.drawLine(Offset(x, 0), Offset(x, 2000), gridPaint);
    }
    for (var y = 0.0; y < 2000; y += 40) {
      canvas.drawLine(Offset(0, y), Offset(2000, y), gridPaint);
    }

    final byId = {for (final component in components) component.id: component};
    for (final wire in wires) {
      final from = _pinOffset(byId[wire.fromComponentId], wire.fromPointId);
      final to = _pinOffset(byId[wire.toComponentId], wire.toPointId);
      if (from != null && to != null) {
        final isSelected = wire.id == selectedWireId;
        final wirePaint = Paint()
          ..color = isSelected ? Colors.redAccent : Colors.cyanAccent
          ..strokeWidth = isSelected ? 6 : 3
          ..style = PaintingStyle.stroke
          ..strokeCap = StrokeCap.round;
        canvas.drawLine(from, to, wirePaint);
      }
    }
  }

  Offset? _pinOffset(CircuitComponent? component, String pinId) {
    if (component == null) return null;
    for (final pin in component.pins) {
      if (pin.id == pinId) return component.position + pin.offset;
    }
    return null;
  }

  @override
  bool shouldRepaint(covariant _CircuitPainter oldDelegate) => true;
}
