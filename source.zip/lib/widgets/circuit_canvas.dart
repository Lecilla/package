import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/component.dart';
import '../models/wire.dart';
import '../state/canvas_state.dart';

// 旋转辅助函数
Offset _rotatedOffset(Offset offset, double degrees) {
  final radians = degrees * math.pi / 180;
  final cosValue = math.cos(radians);
  final sinValue = math.sin(radians);
  return Offset(
    offset.dx * cosValue - offset.dy * sinValue,
    offset.dx * sinValue + offset.dy * cosValue,
  );
}

class CircuitCanvas extends StatefulWidget {
  const CircuitCanvas({super.key});
  @override
  State<CircuitCanvas> createState() => _CircuitCanvasState();
}

class _CircuitCanvasState extends State<CircuitCanvas> {
  bool _showLogo = true; // 这是控制校徽显示的开关

  @override
  Widget build(BuildContext context) {
    return Consumer<CanvasState>(
      builder: (context, state, child) {
        return Stack(
          children: [
            // 底层：背景与电路
            Container(
              color: const Color(0xFF12121A),
              child: Stack(
                children: [
                  // 1. 校徽水印层 (仅当 _showLogo 为 true 时显示)
                  if (_showLogo)
                    Center(
                      child: Opacity(
                        opacity: 0.1,
                        child: Image.asset(
                          'assets/images/uestc_logo.png',
                          width: 500,
                          errorBuilder: (context, error, stackTrace) => const SizedBox(),
                        ),
                      ),
                    ),
                  // 2. 电路绘制层
                  CustomPaint(
                    painter: _CircuitPainter(
                      components: state.components,
                      wires: state.wires,
                      selectedWireId: state.selectedWire?.id,
                    ),
                    child: Container(),
                  ),
                ],
              ),
            ),
            
            // 3. 右上角控制按钮：点击切换校徽显示状态
            Positioned(
              top: 10,
              right: 10,
              child: IconButton(
                icon: Icon(
                  _showLogo ? Icons.visibility : Icons.visibility_off,
                  color: Colors.white54,
                ),
                onPressed: () {
                  setState(() {
                    _showLogo = !_showLogo;
                  });
                },
              ),
            ),
          ],
        );
      },
    );
  }
}

class _CircuitPainter extends CustomPainter {
  final List<CircuitComponent> components;
  final List<Wire> wires;
  final String? selectedWireId;

  const _CircuitPainter({required this.components, required this.wires, this.selectedWireId});

  @override
  void paint(Canvas canvas, Size size) {
    // 绘制网格
    final gridPaint = Paint()..color = Colors.white.withAlpha(15)..strokeWidth = 1;
    for (var x = 0.0; x < size.width; x += 40) canvas.drawLine(Offset(x, 0), Offset(x, size.height), gridPaint);
    for (var y = 0.0; y < size.height; y += 40) canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    
    // 你原来的元件和连线绘制逻辑（如果需要，请把旧代码里的绘制部分填补到这里）
  }

  @override
  bool shouldRepaint(covariant _CircuitPainter oldDelegate) => true;
}