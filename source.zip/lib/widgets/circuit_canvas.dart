import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../models/component.dart';
import '../models/wire.dart';
import '../state/canvas_state.dart';

Offset _rotatedOffset(Offset offset, double degrees) {
  final radians = degrees * math.pi / 180;
  final cosValue = math.cos(radians);
  final sinValue = math.sin(radians);
  return Offset(
    offset.dx * cosValue - offset.dy * sinValue,
    offset.dx * sinValue + offset.dy * cosValue,
  );
}

class CircuitCanvas extends StatefulWidget {
  const CircuitCanvas({super.key});

  @override
  State<CircuitCanvas> createState() => _CircuitCanvasState();
}

class _CircuitCanvasState extends State<CircuitCanvas> {
  final TransformationController _transformationController =
      TransformationController();
  String? _draggingComponentId;
  bool _isCanvasPanning = false;
  Size? _viewportSize;
  final Map<int, Offset> _activePointers = {};
  double? _lastPinchDistance;

  double get _currentScale {
    final value = _transformationController.value;
    return value.getMaxScaleOnAxis().clamp(0.35, 2.5);
  }

  void _resetView() {
    _transformationController.value = Matrix4.identity();
    HapticFeedback.mediumImpact();
  }

  void _syncVisibleSceneRect(CanvasState state) {
    final size = _viewportSize;
    if (size == null || size.width <= 0 || size.height <= 0) {
      return;
    }
    final topLeft = _transformationController.toScene(Offset.zero);
    final bottomRight = _transformationController.toScene(
      Offset(size.width, size.height),
    );
    state.updateVisibleSceneRect(Rect.fromPoints(topLeft, bottomRight));
  }

  void _setCanvasScale(double scale, Offset focalPoint) {
    final targetScale = scale.clamp(0.35, 2.5);
    final sceneFocal = _transformationController.toScene(focalPoint);
    final matrix = Matrix4.identity()
      ..setEntry(0, 0, targetScale)
      ..setEntry(1, 1, targetScale)
      ..setTranslationRaw(
        focalPoint.dx - sceneFocal.dx * targetScale,
        focalPoint.dy - sceneFocal.dy * targetScale,
        0,
      );
    _transformationController.value = matrix;
  }

  void _showComponentMenu(
    BuildContext context,
    CanvasState state,
    CircuitComponent component,
  ) {
    HapticFeedback.heavyImpact();
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1a1a2e),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                '元件操作: ${component.displayName}',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            ListTile(
              leading: const Icon(
                Icons.edit_outlined,
                color: Colors.greenAccent,
              ),
              title: Text(
                '名称: ${component.userName}',
                style: const TextStyle(color: Colors.white),
              ),
              onTap: () {
                Navigator.pop(context);
                _showRenameDialog(context, state, component);
              },
            ),
            ListTile(
              leading: const Icon(Icons.rotate_right, color: Colors.blueAccent),
              title: const Text(
                '旋转 90°',
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                state.selectComponent(component);
                state.updateSelectedRotation((component.rotation + 90) % 360);
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(
                Icons.delete_outline,
                color: Colors.redAccent,
              ),
              title: const Text('删除元件', style: TextStyle(color: Colors.white)),
              onTap: () {
                state.deleteComponent(component.id);
                Navigator.pop(context);
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  void _showRenameDialog(
    BuildContext context,
    CanvasState state,
    CircuitComponent component,
  ) {
    final controller = TextEditingController(text: component.userName);
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: const Color(0xFF1a1a2e),
        title: const Text('修改元件名称', style: TextStyle(color: Colors.white)),
        content: TextField(
          controller: controller,
          autofocus: true,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(
            labelText: '名称',
            labelStyle: TextStyle(color: Colors.white70),
          ),
          onSubmitted: (_) {
            state.updateComponentName(component.id, controller.text);
            Navigator.pop(dialogContext);
          },
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () {
              state.updateComponentName(component.id, controller.text);
              Navigator.pop(dialogContext);
            },
            child: const Text('保存'),
          ),
        ],
      ),
    );
  }

  void _showWireMenu(BuildContext context, CanvasState state, Wire wire) {
    HapticFeedback.heavyImpact();
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1a1a2e),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                '连线操作',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            ListTile(
              leading: const Icon(
                Icons.delete_outline,
                color: Colors.redAccent,
              ),
              title: const Text('删除连线', style: TextStyle(color: Colors.white)),
              onTap: () {
                state.deleteWire(wire.id);
                Navigator.pop(context);
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  Wire? _findWireAt(CanvasState state, Offset scenePoint) {
    final componentsById = {
      for (final component in state.components) component.id: component,
    };
    for (final wire in state.wires.reversed) {
      final from = _pinOffset(
        componentsById[wire.fromComponentId],
        wire.fromPointId,
      );
      final to = _pinOffset(componentsById[wire.toComponentId], wire.toPointId);
      if (from == null || to == null) {
        continue;
      }
      if (_distanceToSegment(scenePoint, from, to) <= 14) {
        return wire;
      }
    }
    return null;
  }

  CircuitComponent? _componentById(CanvasState state, String id) {
    for (final component in state.components) {
      if (component.id == id) {
        return component;
      }
    }
    return null;
  }

  CircuitComponent? _findComponentAt(CanvasState state, Offset scenePoint) {
    for (final component in state.components.reversed) {
      final local = _rotatedOffset(
        scenePoint - component.position,
        -component.rotation,
      );
      if (local.dx.abs() <= 48 && local.dy.abs() <= 34) {
        return component;
      }
    }
    return null;
  }

  Offset? _pinOffset(CircuitComponent? component, String pinId) {
    if (component == null) {
      return null;
    }
    for (final pin in component.pins) {
      if (pin.id == pinId) {
        return component.position +
            _rotatedOffset(pin.offset, component.rotation);
      }
    }
    return null;
  }

  double _distanceToSegment(Offset point, Offset start, Offset end) {
    final segment = end - start;
    final lengthSquared = segment.dx * segment.dx + segment.dy * segment.dy;
    if (lengthSquared == 0) {
      return (point - start).distance;
    }
    final rawT =
        ((point.dx - start.dx) * segment.dx +
            (point.dy - start.dy) * segment.dy) /
        lengthSquared;
    final t = rawT.clamp(0.0, 1.0);
    final projection = Offset(
      start.dx + segment.dx * t,
      start.dy + segment.dy * t,
    );
    return (point - projection).distance;
  }

  void _beginComponentDrag(CanvasState state, CircuitComponent component) {
    _draggingComponentId = component.id;
    state.selectComponent(component);
    HapticFeedback.selectionClick();
  }

  void _updateComponentDrag(CanvasState state, DragUpdateDetails details) {
    final id = _draggingComponentId;
    if (id == null) {
      return;
    }
    final component = _componentById(state, id);
    if (component == null) {
      _draggingComponentId = null;
      return;
    }
    final sceneDelta = details.delta / _currentScale;
    state.updateComponentPosition(id, component.position + sceneDelta);
  }

  void _endComponentDrag(CanvasState state) {
    if (_draggingComponentId == null) {
      return;
    }
    _draggingComponentId = null;
    state.finishComponentDrag();
  }

  void _handlePointerDown(CanvasState state, PointerDownEvent event) {
    _activePointers[event.pointer] = event.localPosition;
    if (_activePointers.length >= 2) {
      _isCanvasPanning = false;
      _lastPinchDistance = _pinchDistance();
      return;
    }

    final scenePoint = _transformationController.toScene(event.localPosition);
    if (state.isDrawingWire ||
        _findComponentAt(state, scenePoint) != null ||
        _findWireAt(state, scenePoint) != null) {
      _isCanvasPanning = false;
      return;
    }
    _isCanvasPanning = true;
    state.selectComponent(null);
  }

  void _handlePointerMove(PointerMoveEvent event) {
    if (!_activePointers.containsKey(event.pointer)) {
      return;
    }
    _activePointers[event.pointer] = event.localPosition;
    if (_activePointers.length >= 2) {
      _updateCanvasZoom();
      return;
    }

    if (!_isCanvasPanning) return;
    final matrix = _transformationController.value.clone();
    matrix.setTranslationRaw(
      matrix.entry(0, 3) + event.delta.dx,
      matrix.entry(1, 3) + event.delta.dy,
      matrix.entry(2, 3),
    );
    _transformationController.value = matrix;
    final state = context.read<CanvasState>();
    _syncVisibleSceneRect(state);
  }

  void _handlePointerEnd(PointerEvent event) {
    _activePointers.remove(event.pointer);
    _lastPinchDistance = _activePointers.length >= 2 ? _pinchDistance() : null;
    _isCanvasPanning = false;
  }

  double? _pinchDistance() {
    if (_activePointers.length < 2) return null;
    final points = _activePointers.values.take(2).toList();
    return (points[0] - points[1]).distance;
  }

  Offset? _pinchFocalPoint() {
    if (_activePointers.length < 2) return null;
    final points = _activePointers.values.take(2).toList();
    return Offset(
      (points[0].dx + points[1].dx) / 2,
      (points[0].dy + points[1].dy) / 2,
    );
  }

  void _updateCanvasZoom() {
    final distance = _pinchDistance();
    final focal = _pinchFocalPoint();
    final previous = _lastPinchDistance;
    if (distance == null || focal == null || previous == null || previous == 0) {
      _lastPinchDistance = distance;
      return;
    }
    final nextScale = _currentScale * (distance / previous);
    _setCanvasScale(nextScale, focal);
    _lastPinchDistance = distance;
    final state = context.read<CanvasState>();
    _syncVisibleSceneRect(state);
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<CanvasState>(
      builder: (context, state, child) {
        return LayoutBuilder(
          builder: (context, constraints) {
            _viewportSize = Size(constraints.maxWidth, constraints.maxHeight);
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (mounted) {
                _syncVisibleSceneRect(state);
              }
            });

            return GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTapUp: (details) {
                final scenePoint = _transformationController.toScene(
                  details.localPosition,
                );
                final component = _findComponentAt(state, scenePoint);
                if (component != null) {
                  state.selectComponent(component);
                  HapticFeedback.selectionClick();
                  return;
                }

                final wire = _findWireAt(state, scenePoint);
                if (wire != null) {
                  state.selectWire(wire);
                  HapticFeedback.selectionClick();
                  return;
                }
                state.selectComponent(null);
              },
              onLongPressStart: (details) {
                final scenePoint = _transformationController.toScene(
                  details.localPosition,
                );
                final component = _findComponentAt(state, scenePoint);
                if (component != null) {
                  state.selectComponent(component);
                  _showComponentMenu(context, state, component);
                  return;
                }

                final wire = _findWireAt(state, scenePoint);
                if (wire != null) {
                  state.selectWire(wire);
                  _showWireMenu(context, state, wire);
                }
              },
              onDoubleTap: _resetView,
              child: Listener(
                behavior: HitTestBehavior.opaque,
                onPointerDown: (event) => _handlePointerDown(state, event),
                onPointerMove: _handlePointerMove,
                onPointerUp: _handlePointerEnd,
                onPointerCancel: _handlePointerEnd,
                child: InteractiveViewer(
                  transformationController: _transformationController,
                  boundaryMargin: const EdgeInsets.all(2000),
                  minScale: 0.35,
                  maxScale: 2.5,
                  panEnabled: false,
                  scaleEnabled: false,
                  clipBehavior: Clip.none,
                  child: Container(
                    width: 3000,
                    height: 3000,
                    color: Colors.transparent,
                    child: CustomPaint(
                      painter: _CircuitPainter(
                        components: state.components,
                        wires: state.wires,
                        selectedWireId: state.selectedWire?.id,
                      ),
                      child: Stack(
                        clipBehavior: Clip.none,
                        children: [
                          for (final component in state.components)
                            Positioned(
                              left: component.position.dx - 48,
                              top: component.position.dy - 34,
                              child: GestureDetector(
                                behavior: HitTestBehavior.opaque,
                                onTap: () {
                                  state.selectComponent(component);
                                  HapticFeedback.selectionClick();
                                },
                                onLongPress: () => _showComponentMenu(
                                  context,
                                  state,
                                  component,
                                ),
                                onDoubleTap: () => _showRenameDialog(
                                  context,
                                  state,
                                  component,
                                ),
                                onPanStart: (_) =>
                                    _beginComponentDrag(state, component),
                                onPanUpdate: (details) {
                                  _updateComponentDrag(state, details);
                                },
                                onPanEnd: (_) {
                                  _endComponentDrag(state);
                                },
                                onPanCancel: () {
                                  _endComponentDrag(state);
                                },
                                child: _ComponentHitBox(
                                  component: component,
                                  state: state,
                                ),
                              ),
                            ),
                          for (final component in state.components)
                            for (final pin in component.pins)
                              Positioned(
                                left:
                                    component.position.dx +
                                    _rotatedOffset(
                                      pin.offset,
                                      component.rotation,
                                    ).dx -
                                    12,
                                top:
                                    component.position.dy +
                                    _rotatedOffset(
                                      pin.offset,
                                      component.rotation,
                                    ).dy -
                                    12,
                                child: GestureDetector(
                                  behavior: HitTestBehavior.opaque,
                                  onTap: () {
                                    state.selectComponent(component);
                                    if (state.isDrawingWire) {
                                      state.endWire(component.id, pin.id);
                                      HapticFeedback.heavyImpact();
                                    } else {
                                      state.startWire(component.id, pin.id);
                                      HapticFeedback.lightImpact();
                                    }
                                  },
                                  onPanStart: (_) {
                                    if (!state.isDrawingWire) {
                                      _beginComponentDrag(state, component);
                                    }
                                  },
                                  onPanUpdate: (details) {
                                    if (!state.isDrawingWire) {
                                      _updateComponentDrag(state, details);
                                    }
                                  },
                                  onPanEnd: (_) {
                                    if (!state.isDrawingWire) {
                                      _endComponentDrag(state);
                                    }
                                  },
                                  onPanCancel: () {
                                    if (!state.isDrawingWire) {
                                      _endComponentDrag(state);
                                    }
                                  },
                                  child: Container(
                                    width: 24,
                                    height: 24,
                                    color: Colors.transparent,
                                    child: Center(
                                      child: Container(
                                        width: 12,
                                        height: 12,
                                        decoration: BoxDecoration(
                                          color:
                                              state.isDrawingWire &&
                                                  state.selectedComponent?.id ==
                                                      component.id
                                              ? Colors.orange
                                              : Colors.white,
                                          shape: BoxShape.circle,
                                          border: Border.all(
                                            color: Colors.blueAccent,
                                            width: 2,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }
}

class _ComponentHitBox extends StatelessWidget {
  final CircuitComponent component;
  final CanvasState state;

  const _ComponentHitBox({required this.component, required this.state});

  @override
  Widget build(BuildContext context) {
    final reading = _reading(component);
    final ledLit =
        component.type == ComponentType.led && state.isLedLit(component.id);
    return Transform.rotate(
      angle: component.rotation * 3.141592653589793 / 180,
      child: Container(
        width: 96,
        height: 68,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: ledLit
              ? Colors.redAccent.withAlpha(45)
              : component.isSelected
              ? Colors.blue.withAlpha(40)
              : Colors.transparent,
          border: Border.all(
            color: component.isSelected
                ? Colors.blueAccent
                : Colors.transparent,
            width: 2,
          ),
          borderRadius: BorderRadius.circular(8),
          boxShadow: ledLit
              ? [
                  BoxShadow(
                    color: Colors.redAccent.withAlpha(150),
                    blurRadius: 18,
                    spreadRadius: 2,
                  ),
                ]
              : null,
        ),
        child: Stack(
          children: [
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    _label(component),
                    style: TextStyle(
                      color: _color(component.type),
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    component.userName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white70, fontSize: 10),
                  ),
                  if (reading != null)
                    Text(
                      reading,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.greenAccent,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                ],
              ),
            ),
            ..._terminalMarkers(component),
          ],
        ),
      ),
    );
  }

  String _label(CircuitComponent component) {
    switch (component.type) {
      case ComponentType.resistor:
        return 'R';
      case ComponentType.capacitor:
        return 'C';
      case ComponentType.inductor:
        return 'L';
      case ComponentType.voltageSource:
        return 'V';
      case ComponentType.diode:
        return 'D';
      case ComponentType.led:
        return state.isLedLit(component.id) ? 'LED*' : 'LED';
      case ComponentType.mosfet:
        return 'NMOS';
      case ComponentType.ground:
        return 'GND';
      case ComponentType.voltmeter:
        return 'VM';
      case ComponentType.ammeter:
        return 'AM';
      case ComponentType.switchComponent:
        return component.properties['isClosed'] == false ? 'S开' : 'S关';
    }
  }

  String? _reading(CircuitComponent component) {
    if (!state.isSimulationRunning) return null;
    if (component.type == ComponentType.voltmeter) {
      return _formatValue(state.componentVoltage(component.id), 'V');
    }
    if (component.type == ComponentType.ammeter) {
      return _formatValue(state.componentCurrent(component.id), 'A');
    }
    if (component.type == ComponentType.led) {
      return state.isLedLit(component.id) ? '点亮' : '熄灭';
    }
    return null;
  }

  List<Widget> _terminalMarkers(CircuitComponent component) {
    switch (component.type) {
      case ComponentType.voltageSource:
        return [
          Positioned(top: 4, left: 8, child: _marker('+')),
          Positioned(bottom: 4, left: 8, child: _marker('-')),
        ];
      case ComponentType.diode:
      case ComponentType.led:
        return [
          Positioned(left: 12, top: 4, child: _marker('A')),
          Positioned(right: 12, top: 4, child: _marker('K')),
        ];
      case ComponentType.mosfet:
        return [
          Positioned(left: 8, bottom: 4, child: _marker('G')),
          Positioned(right: 12, top: 4, child: _marker('D')),
          Positioned(right: 12, bottom: 4, child: _marker('S')),
        ];
      default:
        return const [];
    }
  }

  Widget _marker(String text) {
    return Container(
      width: 16,
      height: 16,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: Colors.black.withAlpha(170),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.white54, width: 0.5),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 10,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  String _formatValue(double? value, String unit) {
    if (value == null) return '-- $unit';
    final absolute = value.abs();
    if (unit == 'A' && absolute < 0.001) {
      return '${(value * 1000).toStringAsFixed(2)} mA';
    }
    return '${value.toStringAsFixed(3)} $unit';
  }

  Color _color(ComponentType type) {
    switch (type) {
      case ComponentType.resistor:
        return Colors.orange;
      case ComponentType.capacitor:
        return Colors.yellow;
      case ComponentType.inductor:
        return Colors.greenAccent;
      case ComponentType.voltageSource:
        return Colors.redAccent;
      case ComponentType.diode:
        return Colors.deepOrangeAccent;
      case ComponentType.led:
        return Colors.pinkAccent;
      case ComponentType.mosfet:
        return Colors.purpleAccent;
      case ComponentType.ground:
        return Colors.white70;
      case ComponentType.voltmeter:
        return Colors.cyanAccent;
      case ComponentType.ammeter:
        return Colors.lightBlueAccent;
      case ComponentType.switchComponent:
        return Colors.tealAccent;
    }
  }
}

class _CircuitPainter extends CustomPainter {
  final List<CircuitComponent> components;
  final List<Wire> wires;
  final String? selectedWireId;

  const _CircuitPainter({
    required this.components,
    required this.wires,
    this.selectedWireId,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final gridPaint = Paint()
      ..color = Colors.white.withAlpha(15)
      ..strokeWidth = 1;

    // 修复点：这里的网格绘制不再硬编码写死 2000，而是根据容器尺寸自适应，给你带来超大的绘图空间
    for (var x = 0.0; x < size.width; x += 40) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), gridPaint);
    }
    for (var y = 0.0; y < size.height; y += 40) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }

    final byId = {for (final component in components) component.id: component};
    for (final wire in wires) {
      final from = _pinOffset(byId[wire.fromComponentId], wire.fromPointId);
      final to = _pinOffset(byId[wire.toComponentId], wire.toPointId);
      if (from != null && to != null) {
        final isSelected = wire.id == selectedWireId;
        final wirePaint = Paint()
          ..color = isSelected ? Colors.redAccent : Colors.cyanAccent
          ..strokeWidth = isSelected ? 6 : 3
          ..style = PaintingStyle.stroke
          ..strokeCap = StrokeCap.round;
        canvas.drawLine(from, to, wirePaint);
      }
    }
  }

  Offset? _pinOffset(CircuitComponent? component, String pinId) {
    if (component == null) return null;
    for (final pin in component.pins) {
      if (pin.id == pinId) {
        return component.position +
            _rotatedOffset(pin.offset, component.rotation);
      }
    }
    return null;
  }

  @override
  bool shouldRepaint(covariant _CircuitPainter oldDelegate) => true;
}
