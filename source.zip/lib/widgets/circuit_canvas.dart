import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../models/component.dart';
import '../models/wire.dart';
import '../state/canvas_state.dart';

class CircuitCanvas extends StatefulWidget {
  const CircuitCanvas({super.key});

  @override
  State<CircuitCanvas> createState() => _CircuitCanvasState();
}

class _CircuitCanvasState extends State<CircuitCanvas> {
  final TransformationController _transformationController = TransformationController();
  bool _isDraggingComponent = false;

  void _resetView() {
    _transformationController.value = Matrix4.identity();
    HapticFeedback.mediumImpact();
  }

  void _showComponentMenu(BuildContext context, CanvasState state, CircuitComponent component) {
    HapticFeedback.heavyImpact();
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1a1a2e),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                '元件操作: ${component.displayName}',
                style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.rotate_right, color: Colors.blueAccent),
              title: const Text('旋转 90°', style: TextStyle(color: Colors.white)),
              onTap: () {
                state.selectComponent(component);
                state.updateSelectedRotation((component.rotation + 90) % 360);
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline, color: Colors.redAccent),
              title: const Text('删除元件', style: TextStyle(color: Colors.white)),
              onTap: () {
                state.deleteComponent(component.id);
                Navigator.pop(context);
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<CanvasState>(
      builder: (context, state, child) {
        return GestureDetector(
          onTap: () => state.selectComponent(null),
          onDoubleTap: _resetView,
          child: InteractiveViewer(
            transformationController: _transformationController,
            boundaryMargin: const EdgeInsets.all(1000),
            minScale: 0.2,
            maxScale: 3.0,
            // 仅在正在拖动元件时禁用平移
            panEnabled: !_isDraggingComponent, 
            child: Container(
              width: 2000,
              height: 2000,
              color: Colors.transparent,
              child: CustomPaint(
                painter: _CircuitPainter(
                  components: state.components,
                  wires: state.wires,
                ),
                child: Stack(
                  children: [
                    for (final component in state.components)
                      Positioned(
                        left: component.position.dx - 38,
                        top: component.position.dy - 30,
                        child: GestureDetector(
                          onTap: () {
                            state.selectComponent(component);
                            HapticFeedback.selectionClick();
                          },
                          onLongPress: () => _showComponentMenu(context, state, component),
                          onPanStart: (_) {
                            setState(() => _isDraggingComponent = true);
                          },
                          onPanUpdate: (details) {
                            state.updateComponentPosition(
                              component.id,
                              component.position + details.delta,
                            );
                          },
                          onPanEnd: (_) {
                            setState(() => _isDraggingComponent = false);
                            // 拖动结束保存历史
                            state.saveCurrentStateToHistory();
                          },
                          child: _ComponentHitBox(component: component),
                        ),
                      ),
                    for (final component in state.components)
                      for (final pin in component.pins)
                        Positioned(
                          left: component.position.dx + pin.offset.dx - 20,
                          top: component.position.dy + pin.offset.dy - 20,
                          child: GestureDetector(
                            onTap: () {
                              if (state.isDrawingWire) {
                                state.endWire(component.id, pin.id);
                                HapticFeedback.heavyImpact();
                              } else {
                                state.startWire(component.id, pin.id);
                                HapticFeedback.lightImpact();
                              }
                            },
                            child: Container(
                              width: 40,
                              height: 40,
                              color: Colors.transparent,
                              child: Center(
                                child: Container(
                                  width: 12,
                                  height: 12,
                                  decoration: BoxDecoration(
                                    color: state.isDrawingWire && state.selectedComponent?.id == component.id ? Colors.orange : Colors.white,
                                    shape: BoxShape.circle,
                                    border: Border.all(color: Colors.blueAccent, width: 2),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _ComponentHitBox extends StatelessWidget {
  final CircuitComponent component;
  const _ComponentHitBox({required this.component});

  @override
  Widget build(BuildContext context) {
    return Transform.rotate(
      angle: component.rotation * 3.141592653589793 / 180,
      child: Container(
        width: 76,
        height: 60,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: component.isSelected ? Colors.blue.withAlpha(40) : Colors.transparent,
          border: Border.all(
            color: component.isSelected ? Colors.blueAccent : Colors.transparent,
            width: 2,
          ),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(
          _label(component),
          style: TextStyle(
            color: _color(component.type),
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  String _label(CircuitComponent component) {
    switch (component.type) {
      case ComponentType.resistor: return 'R';
      case ComponentType.capacitor: return 'C';
      case ComponentType.inductor: return 'L';
      case ComponentType.voltageSource: return 'V';
      case ComponentType.led: return component.properties['isLit'] == true ? 'LED*' : 'LED';
      case ComponentType.ground: return 'GND';
    }
  }

  Color _color(ComponentType type) {
    switch (type) {
      case ComponentType.resistor: return Colors.orange;
      case ComponentType.capacitor: return Colors.yellow;
      case ComponentType.inductor: return Colors.greenAccent;
      case ComponentType.voltageSource: return Colors.redAccent;
      case ComponentType.led: return Colors.purpleAccent;
      case ComponentType.ground: return Colors.white70;
    }
  }
}

class _CircuitPainter extends CustomPainter {
  final List<CircuitComponent> components;
  final List<Wire> wires;
  const _CircuitPainter({required this.components, required this.wires});

  @override
  void paint(Canvas canvas, Size size) {
    final gridPaint = Paint()..color = Colors.white.withAlpha(15)..strokeWidth = 1;
    for (var x = 0.0; x < 2000; x += 40) {
      canvas.drawLine(Offset(x, 0), Offset(x, 2000), gridPaint);
    }
    for (var y = 0.0; y < 2000; y += 40) {
      canvas.drawLine(Offset(0, y), Offset(2000, y), gridPaint);
    }

    final byId = {for (final component in components) component.id: component};
    final wirePaint = Paint()
      ..color = Colors.cyanAccent
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    for (final wire in wires) {
      final from = _pinOffset(byId[wire.fromComponentId], wire.fromPointId);
      final to = _pinOffset(byId[wire.toComponentId], wire.toPointId);
      if (from != null && to != null) {
        canvas.drawLine(from, to, wirePaint);
      }
    }
  }

  Offset? _pinOffset(CircuitComponent? component, String pinId) {
    if (component == null) return null;
    for (final pin in component.pins) {
      if (pin.id == pinId) return component.position + pin.offset;
    }
    return null;
  }

  @override
  bool shouldRepaint(covariant _CircuitPainter oldDelegate) => true;
}
