import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/component.dart';
import '../state/canvas_state.dart';
import 'waveform_viewer.dart';
import '../services/circuit_storage.dart';
import '../services/circuit_to_spice_mapper.dart';
import '../spice/mock_spice_simulator.dart';
import '../spice/simulation_config.dart';
import '../spice/simulation_result.dart';

class RightPanel extends StatelessWidget {
  const RightPanel({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFF0f3460),
      child: Column(
        children: [
          _SimulationControls(),
          const Divider(height: 1, color: Colors.white24),
          const Expanded(child: _PropertySection()),
          const Divider(height: 1, color: Colors.white24),
          _FileOperations(),
        ],
      ),
    );
  }
}

class _SimulationControls extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          SizedBox(
            width: double.infinity,
            height: 44,
            child: ElevatedButton.icon(
              onPressed: () => _runSimulation(context),
              icon: const Icon(Icons.play_arrow, color: Colors.white),
              label: const Text(
                '运行仿真',
                style: TextStyle(color: Colors.white, fontSize: 14),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Consumer<CanvasState>(
            // 已修正 << 为 <
            builder: (context, state, child) {
              return Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: state.isDrawingWire ? Colors.orange : Colors.green,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    state.isDrawingWire ? '连线中...' : '就绪',
                    style: const TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }

  Future<void> _runSimulation(BuildContext context) async {
    final state = context.read<CanvasState>();
    try {
      final circuit = CircuitToSpiceMapper().map(state.components, state.wires);
      final config = SimulationConfig(
        analysisType: 'transient',
        stepTime: 0.001,
        stopTime: 1,
        nodesToPlot: circuit.observableNodes,
      );
      // 默认使用 MockSpiceSimulator。接入 iOS ngspice 原生库后，可在这里切换为
      // NativeNgspiceSimulator，或做一个配置开关选择真实仿真器。
      final simulator = MockSpiceSimulator();
      final result = await simulator.runTransient(circuit, config);

      if (!context.mounted) return;
      if (!result.success) {
        _showErrorDialog(context, result.errors, result.netlist);
        return;
      }
      for (final warning in result.warnings) {
        debugPrint('SPICE warning: $warning');
      }
      _showResultDialog(context, result);
    } on CircuitMappingException catch (e) {
      if (!context.mounted) return;
      _showErrorDialog(context, e.errors, '');
    } catch (e) {
      if (!context.mounted) return;
      _showErrorDialog(context, ['仿真失败: $e'], '');
    }
  }

  void _showErrorDialog(
    BuildContext context,
    List<String> errors,
    String netlist,
  ) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1a1a2e),
        title: const Text('仿真错误', style: TextStyle(color: Colors.white)),
        content: SingleChildScrollView(
          child: Text(
            [
              ...errors,
              if (netlist.isNotEmpty) '\n生成的 netlist:\n$netlist',
            ].join('\n'),
            style: const TextStyle(color: Colors.white70),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('关闭'),
          ),
        ],
      ),
    );
  }

  void _showResultDialog(BuildContext context, SimulationResult result) {
    final screenSize = MediaQuery.of(context).size;
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: const Color(0xFF1a1a2e),
        insetPadding: const EdgeInsets.all(10),
        child: Container(
          width: screenSize.width * 0.9,
          height: screenSize.height * 0.8,
          constraints: const BoxConstraints(
            maxWidth: 800,
            maxHeight: 600,
          ),
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    '仿真结果',
                    style: TextStyle(color: Colors.white, fontSize: 16),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close, color: Colors.white),
                  ),
                ],
              ),
              Expanded(
                flex: 3,
                child: WaveformViewer(
                  timeData: result.time,
                  voltageSeries: result.nodeVoltages,
                ),
              ),
              const SizedBox(height: 12),
              Expanded(
                flex: 2,
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.black.withAlpha(60),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: Colors.white12),
                  ),
                  child: SingleChildScrollView(
                    child: SelectableText(
                      [
                        if (result.warnings.isNotEmpty)
                          'Warnings:\n${result.warnings.join('\n')}\n',
                        'Netlist:\n${result.netlist}',
                      ].join('\n'),
                      style: const TextStyle(
                        color: Colors.white70,
                        fontFamily: 'monospace',
                        fontSize: 11,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PropertySection extends StatefulWidget {
  const _PropertySection();

  @override
  State<_PropertySection> createState() => _PropertySectionState();
}

class _PropertySectionState extends State<_PropertySection> {
  final Map<String, TextEditingController> _controllers = {};
  String? _lastSelectedId;

  void _clearControllers() {
    for (var controller in _controllers.values) {
      controller.dispose();
    }
    _controllers.clear();
  }

  @override
  void dispose() {
    _clearControllers();
    super.dispose();
  }

  TextEditingController _getController(String key, String initialValue) {
    if (!_controllers.containsKey(key)) {
      _controllers[key] = TextEditingController(text: initialValue);
    } else {
      if (_controllers[key]!.text != initialValue &&
          !_controllers[key]!.selection.isValid) {
        _controllers[key]!.text = initialValue;
      }
    }
    return _controllers[key]!;
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<CanvasState>(
      // 已修正 << 为 <
      builder: (context, state, child) {
        final selected = state.selectedComponent;

        if (selected?.id != _lastSelectedId) {
          _clearControllers();
          _lastSelectedId = selected?.id;
        }

        if (selected == null) {
          return const Center(
            child: Text(
              '点击元件\n编辑属性',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white38, fontSize: 14),
            ),
          );
        }

        return SingleChildScrollView(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: const BoxDecoration(
                      color: Colors.blue,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    selected.displayName,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              ..._buildFields(context, selected),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: () => state.deleteComponent(selected.id),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.red,
                    side: const BorderSide(color: Colors.red),
                  ),
                  child: const Text('删除元件'),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  List<Widget> _buildFields(BuildContext context, CircuitComponent comp) {
    // 已修正 << 为 <
    final state = context.read<CanvasState>(); // 已修正 << 为 <
    final List<Widget> fields = []; // 已修正 << 为 <

    switch (comp.type) {
      case ComponentType.resistor:
        fields.add(
          _buildField(
            '${comp.id}_res',
            '阻值 (Ω)',
            comp.properties['resistance'] ?? 1000.0,
            (v) => state.updateSelectedProperty('resistance', v),
          ),
        );
        break;
      case ComponentType.capacitor:
        fields.add(
          _buildField(
            '${comp.id}_cap',
            '电容 (F)',
            comp.properties['capacitance'] ?? 1e-6,
            (v) => state.updateSelectedProperty('capacitance', v),
          ),
        );
        break;
      case ComponentType.inductor:
        fields.add(
          _buildField(
            '${comp.id}_ind',
            '电感 (H)',
            comp.properties['inductance'] ?? 1e-3,
            (v) => state.updateSelectedProperty('inductance', v),
          ),
        );
        break;
      case ComponentType.voltageSource:
        fields.add(
          _buildField(
            '${comp.id}_vol',
            '电压 (V)',
            comp.properties['voltage'] ?? 5.0,
            (v) => state.updateSelectedProperty('voltage', v),
          ),
        );
        break;
      case ComponentType.led:
        fields.add(
          _buildField(
            '${comp.id}_led',
            '导通电压 (V)',
            comp.properties['forwardVoltage'] ?? 2.0,
            (v) => state.updateSelectedProperty('forwardVoltage', v),
          ),
        );

        final bool isLit = comp.properties['isLit'] ?? false;
        fields.add(
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  '点亮状态',
                  style: TextStyle(color: Colors.white54, fontSize: 12),
                ),
                Switch(
                  value: isLit,
                  onChanged: (value) {
                    state.updateSelectedProperty('isLit', value);
                  },
                  activeThumbColor:
                      Colors.red, // 顺便修正：已将过时的 activeColor 替换为 activeThumbColor
                  activeTrackColor: Colors.red.withAlpha(128),
                ),
              ],
            ),
          ),
        );
        break;
      case ComponentType.ground:
        fields.add(const Text('地节点', style: TextStyle(color: Colors.white70)));
        break;
    }

    fields.add(const SizedBox(height: 8));
    fields.add(
      _buildField('${comp.id}_rot', '旋转 (°)', comp.rotation, (v) {
        final rotation = v is num
            ? v.toDouble()
            : double.tryParse(v.toString());
        if (rotation != null) {
          state.updateSelectedRotation(rotation);
        }
      }),
    );

    return fields;
  }

  Widget _buildField(
    String cacheKey,
    String label,
    dynamic value,
    Function(dynamic) onChanged,
  ) {
    final controller = _getController(cacheKey, value.toString());

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(color: Colors.white54, fontSize: 12),
          ),
          const SizedBox(height: 4),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: controller,
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                  keyboardType: TextInputType.text, // 允许输入单位后缀
                  decoration: InputDecoration(
                    isDense: true,
                    filled: true,
                    fillColor: const Color(0xFF1a1a2e),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(6),
                      borderSide: const BorderSide(color: Colors.white24),
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 10,
                    ),
                  ),
                  onSubmitted: (text) => onChanged(text),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          // 为手机用户提供快捷单位按钮
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: ['p', 'n', 'u', 'm', 'k', 'Meg'].map((suffix) {
                return Padding(
                  padding: const EdgeInsets.only(right: 4),
                  child: InkWell(
                    onTap: () {
                      final text = controller.text;
                      // 如果末尾已经是字母，则替换，否则追加
                      final newText = text.replaceAll(RegExp(r'[a-zA-Z]+$'), '') + suffix;
                      controller.text = newText;
                      onChanged(newText);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.white10,
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        suffix,
                        style: const TextStyle(color: Colors.blueAccent, fontSize: 12),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }
}

class _FileOperations extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _FileButton(
            icon: Icons.save_outlined,
            label: '保存',
            onTap: () => _saveCircuit(context),
          ),
          _FileButton(
            icon: Icons.folder_open_outlined,
            label: '打开',
            onTap: () => _openCircuit(context),
          ),
          _FileButton(
            icon: Icons.share_outlined,
            label: '分享',
            onTap: () => _shareCircuit(context),
          ),
        ],
      ),
    );
  }

  void _saveCircuit(BuildContext context) async {
    final state = context.read<CanvasState>(); // 已修正 << 为 <
    if (state.components.isEmpty) {
      _showSnack(context, '画布为空，无需保存');
      return;
    }

    final name = 'circuit_${DateTime.now().millisecondsSinceEpoch}';
    try {
      await CircuitStorage.saveCircuit(name, state.components, state.wires);
      if (!context.mounted) return;
      _showSnack(context, '已保存');
    } catch (e) {
      if (!context.mounted) return;
      _showSnack(context, '保存失败: $e');
    }
  }

  void _openCircuit(BuildContext context) async {
    final state = context.read<CanvasState>(); // 已修正 << 为 <
    try {
      final files = await CircuitStorage.listCircuits();
      if (files.isEmpty) {
        if (!context.mounted) return;
        _showSnack(context, '没有保存的电路');
        return;
      }

      if (!context.mounted) return;

      showDialog(
        context: context,
        builder: (dialogContext) => AlertDialog(
          backgroundColor: const Color(0xFF1a1a2e),
          title: const Text('打开电路', style: TextStyle(color: Colors.white)),
          content: SizedBox(
            width: 300,
            height: 200,
            child: ListView.builder(
              itemCount: files.length,
              itemBuilder: (listViewContext, index) {
                final file = files[index];
                final name = file.split('/').last;
                return ListTile(
                  title: Text(
                    name,
                    style: const TextStyle(color: Colors.white),
                  ),
                  onTap: () async {
                    Navigator.pop(dialogContext);
                    final data = await CircuitStorage.loadCircuit(file);

                    if (data != null && context.mounted) {
                      state.loadFromData(data);
                      _showSnack(context, '已打开电路');
                    }
                  },
                );
              },
            ),
          ),
        ),
      );
    } catch (e) {
      if (!context.mounted) return;
      _showSnack(context, '读取失败: $e');
    }
  }

  void _shareCircuit(BuildContext context) async {
    final state = context.read<CanvasState>(); // 已修正 << 为 <
    if (state.components.isEmpty) {
      _showSnack(context, '画布为空');
      return;
    }

    try {
      final name = 'circuit_${DateTime.now().millisecondsSinceEpoch}';
      final path = await CircuitStorage.saveCircuit(
        name,
        state.components,
        state.wires,
      );
      await CircuitStorage.shareCircuit(path);
    } catch (e) {
      if (!context.mounted) return;
      _showSnack(context, '分享失败: $e');
    }
  }

  void _showSnack(BuildContext context, String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }
}

class _FileButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _FileButton({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: Colors.white70, size: 20),
          const SizedBox(height: 2),
          Text(
            label,
            style: const TextStyle(color: Colors.white54, fontSize: 10),
          ),
        ],
      ),
    );
  }
}
