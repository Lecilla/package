import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/component.dart';
import '../state/canvas_state.dart';
import 'waveform_viewer.dart';
import '../services/circuit_storage.dart';
import '../services/circuit_to_spice_mapper.dart';
import '../spice/dart_mna_spice_simulator.dart';
import '../spice/simulation_config.dart';
import '../spice/simulation_result.dart';

class RightPanel extends StatelessWidget {
  const RightPanel({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFF0f3460),
      child: Column(
        children: [
          _SimulationControls(),
          const Divider(height: 1, color: Colors.white24),
          const Expanded(child: _PropertySection()),
          const Divider(height: 1, color: Colors.white24),
          _FileOperations(),
        ],
      ),
    );
  }
}

class _SimulationControls extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<CanvasState>(
      builder: (context, state, child) => Container(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            SizedBox(
              width: double.infinity,
              height: 44,
              child: ElevatedButton.icon(
                onPressed: state.isSimulationLoading
                    ? null
                    : state.isSimulationRunning
                    ? state.stopSimulation
                    : () => _runSimulation(context),
                icon: state.isSimulationLoading
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : Icon(
                        state.isSimulationRunning
                            ? Icons.stop
                            : Icons.play_arrow,
                        color: Colors.white,
                      ),
                label: Text(
                  state.isSimulationLoading
                      ? '正在计算...'
                      : state.isSimulationRunning
                      ? '停止仿真'
                      : '运行仿真',
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: state.isSimulationRunning
                      ? Colors.redAccent
                      : Colors.green,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
            ),
            if (state.isSimulationRunning && state.simulationResult != null)
              TextButton.icon(
                onPressed: () => _showResultDialog(
                  context,
                  state.simulationResult!,
                  eventTimes: state.switchEvents
                      .map((event) => event.time)
                      .toList(),
                ),
                icon: const Icon(Icons.show_chart, size: 18),
                label: const Text('查看波形与 Netlist'),
              ),
            if (state.isSimulationRunning)
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: state.isRecording
                          ? null
                          : state.startRecording,
                      icon: const Icon(Icons.fiber_manual_record, size: 16),
                      label: const Text('开始记录'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: state.isRecording ? state.stopRecording : null,
                      icon: const Icon(Icons.stop_circle_outlined, size: 16),
                      label: const Text('停止记录'),
                    ),
                  ),
                ],
              ),
            const SizedBox(height: 4),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: state.isSimulationRunning
                        ? Colors.redAccent
                        : state.isDrawingWire
                        ? Colors.orange
                        : Colors.green,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  state.isSimulationRunning
                      ? state.isSimulationPlaying
                            ? 'MNA 时间轴运行中，可切换开关'
                            : '仿真完成，可查看读数和波形'
                      : state.isDrawingWire
                      ? '连线中...'
                      : '就绪',
                  style: const TextStyle(color: Colors.white70, fontSize: 12),
                ),
              ],
            ),
            if (state.isSimulationRunning) ...[
              const SizedBox(height: 6),
              LinearProgressIndicator(
                value: state.simulationProgress,
                minHeight: 3,
                color: Colors.greenAccent,
                backgroundColor: Colors.white12,
              ),
              const SizedBox(height: 4),
              Text(
                't = ${state.simulationTime.toStringAsFixed(3)} s'
                '${state.switchEvents.isEmpty ? '' : '  |  开关事件 ${state.switchEvents.length} 次'}'
                '${state.isRecording ? '  |  记录中' : ''}',
                style: const TextStyle(color: Colors.white54, fontSize: 11),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _runSimulation(BuildContext context) async {
    final state = context.read<CanvasState>();
    state.setSimulationLoading(true);
    try {
      final circuit = CircuitToSpiceMapper().map(state.components, state.wires);
      final config = SimulationConfig(
        analysisType: 'transient',
        stepTime: 0.02,
        stopTime: 60,
        nodesToPlot: circuit.observableNodes,
      );
      final simulator = DartMnaSpiceSimulator();
      final result = await simulator.runTransient(circuit, config);

      if (!context.mounted) return;
      if (!result.success) {
        state.setSimulationLoading(false);
        _showErrorDialog(context, result.errors, result.netlist);
        return;
      }
      state.clearMeterRecords();
      state.applySimulationResult(circuit, result, config: config);
      state.startRecording();
      for (final warning in result.warnings) {
        debugPrint('SPICE warning: $warning');
      }
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('MNA 求解完成，点击元件可查看真实计算读数。')));
    } on CircuitMappingException catch (e) {
      state.setSimulationLoading(false);
      if (!context.mounted) return;
      _showErrorDialog(context, e.errors, '');
    } catch (e) {
      state.setSimulationLoading(false);
      if (!context.mounted) return;
      _showErrorDialog(context, ['仿真失败: $e'], '');
    }
  }

  void _showErrorDialog(
    BuildContext context,
    List<String> errors,
    String netlist,
  ) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1a1a2e),
        title: const Text('仿真错误', style: TextStyle(color: Colors.white)),
        content: SingleChildScrollView(
          child: Text(
            [
              ...errors,
              if (netlist.isNotEmpty) '\n生成的 netlist:\n$netlist',
            ].join('\n'),
            style: const TextStyle(color: Colors.white70),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('关闭'),
          ),
        ],
      ),
    );
  }

  void _showResultDialog(
    BuildContext context,
    SimulationResult result, {
    List<double> eventTimes = const [],
  }) {
    final screenSize = MediaQuery.of(context).size;
    showDialog(
      context: context,
      builder: (context) => DefaultTabController(
        length: 2,
        child: Dialog(
          backgroundColor: const Color(0xFF1a1a2e),
          insetPadding: const EdgeInsets.all(10),
          child: Container(
            width: screenSize.width * 0.9,
            height: screenSize.height * 0.8,
            constraints: const BoxConstraints(maxWidth: 800, maxHeight: 600),
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      '仿真结果',
                      style: TextStyle(color: Colors.white, fontSize: 16),
                    ),
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.close, color: Colors.white),
                    ),
                  ],
                ),
                Expanded(
                  flex: 3,
                  child: Column(
                    children: [
                      const TabBar(
                        tabs: [
                          Tab(text: '节点/电压表电压'),
                          Tab(text: '支路/电流表电流'),
                        ],
                      ),
                      Expanded(
                        child: TabBarView(
                          children: [
                            WaveformViewer(
                              timeData: result.time,
                              voltageSeries: result.nodeVoltages,
                              eventTimes: eventTimes,
                            ),
                            WaveformViewer(
                              timeData: result.time,
                              voltageSeries: result.branchCurrents,
                              eventTimes: eventTimes,
                              unit: 'A',
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                Expanded(
                  flex: 2,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.black.withAlpha(60),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: Colors.white12),
                    ),
                    child: SingleChildScrollView(
                      child: SelectableText(
                        [
                          if (result.warnings.isNotEmpty)
                            'Warnings:\n${result.warnings.join('\n')}\n',
                          'Netlist:\n${result.netlist}',
                        ].join('\n'),
                        style: const TextStyle(
                          color: Colors.white70,
                          fontFamily: 'monospace',
                          fontSize: 11,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _PropertySection extends StatefulWidget {
  const _PropertySection();

  @override
  State<_PropertySection> createState() => _PropertySectionState();
}

class _PropertySectionState extends State<_PropertySection> {
  final Map<String, TextEditingController> _controllers = {};
  String? _lastSelectedId;

  void _clearControllers() {
    for (var controller in _controllers.values) {
      controller.dispose();
    }
    _controllers.clear();
  }

  @override
  void dispose() {
    _clearControllers();
    super.dispose();
  }

  TextEditingController _getController(String key, String initialValue) {
    if (!_controllers.containsKey(key)) {
      _controllers[key] = TextEditingController(text: initialValue);
    } else {
      if (_controllers[key]!.text != initialValue &&
          !_controllers[key]!.selection.isValid) {
        _controllers[key]!.text = initialValue;
      }
    }
    return _controllers[key]!;
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<CanvasState>(
      // 已修正 << 为 <
      builder: (context, state, child) {
        final selected = state.selectedComponent;
        final selectedWire = state.selectedWire;

        if (selected?.id != _lastSelectedId || selectedWire != null) {
          _clearControllers();
          _lastSelectedId = selected?.id;
        }

        if (selectedWire != null) {
          return Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Icon(Icons.timeline, color: Colors.cyanAccent, size: 18),
                    SizedBox(width: 8),
                    Text(
                      '已选中连线',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  '${selectedWire.fromComponentId}:${selectedWire.fromPointId}\n'
                  '→ ${selectedWire.toComponentId}:${selectedWire.toPointId}',
                  style: const TextStyle(color: Colors.white54, fontSize: 12),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: () => state.deleteWire(selectedWire.id),
                    icon: const Icon(Icons.delete_outline),
                    label: const Text('删除连线'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.redAccent,
                      side: const BorderSide(color: Colors.redAccent),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  '也可以在画布上长按连线删除。',
                  style: TextStyle(color: Colors.white38, fontSize: 12),
                ),
              ],
            ),
          );
        }

        if (selected == null) {
          return const Center(
            child: Text(
              '点击元件\n编辑属性',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white38, fontSize: 14),
            ),
          );
        }

        return SingleChildScrollView(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: const BoxDecoration(
                      color: Colors.blue,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: InkWell(
                      onTap: () => _showRenameDialog(context, state, selected),
                      child: Text(
                        selected.userName,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  IconButton(
                    tooltip: '修改名称',
                    icon: const Icon(
                      Icons.edit_outlined,
                      color: Colors.white70,
                      size: 18,
                    ),
                    onPressed: () =>
                        _showRenameDialog(context, state, selected),
                  ),
                ],
              ),
              Text(
                selected.displayName,
                style: const TextStyle(color: Colors.white38, fontSize: 12),
              ),
              if (state.isSimulationRunning ||
                  state.meterRecordsFor(selected.id).isNotEmpty) ...[
                const SizedBox(height: 10),
                _buildSimulationReadout(state, selected),
              ],
              const SizedBox(height: 12),
              ..._buildFields(context, selected),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: () => state.deleteComponent(selected.id),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.red,
                    side: const BorderSide(color: Colors.red),
                  ),
                  child: const Text('删除元件'),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  List<Widget> _buildFields(BuildContext context, CircuitComponent comp) {
    // 已修正 << 为 <
    final state = context.read<CanvasState>(); // 已修正 << 为 <
    final List<Widget> fields = []; // 已修正 << 为 <

    switch (comp.type) {
      case ComponentType.resistor:
        fields.add(
          _buildField(
            '${comp.id}_res',
            '阻值 (Ω)',
            comp.properties['resistance'] ?? 1000.0,
            (v) => state.updateSelectedProperty('resistance', v),
          ),
        );
        break;
      case ComponentType.capacitor:
        fields.add(
          _buildField(
            '${comp.id}_cap',
            '电容 (F)',
            comp.properties['capacitance'] ?? 1e-6,
            (v) => state.updateSelectedProperty('capacitance', v),
          ),
        );
        break;
      case ComponentType.inductor:
        fields.add(
          _buildField(
            '${comp.id}_ind',
            '电感 (H)',
            comp.properties['inductance'] ?? 1e-3,
            (v) => state.updateSelectedProperty('inductance', v),
          ),
        );
        break;
      case ComponentType.voltageSource:
        fields.add(
          _buildField(
            '${comp.id}_vol',
            '电压 (V)',
            comp.properties['voltage'] ?? 5.0,
            (v) => state.updateSelectedProperty('voltage', v),
          ),
        );
        break;
      case ComponentType.diode:
        fields.add(
          _buildField(
            '${comp.id}_diode_vf',
            '正向压降 (V)',
            comp.properties['forwardVoltage'] ?? 0.7,
            (v) => state.updateSelectedProperty('forwardVoltage', v),
          ),
        );
        break;
      case ComponentType.led:
        fields.add(
          _buildField(
            '${comp.id}_led_vf',
            '正向压降 (V)',
            comp.properties['forwardVoltage'] ?? 2.0,
            (v) => state.updateSelectedProperty('forwardVoltage', v),
          ),
        );
        break;
      case ComponentType.mosfet:
        fields.addAll([
          _buildField(
            '${comp.id}_mos_vth',
            '阈值电压 Vth (V)',
            comp.properties['thresholdVoltage'] ?? 2.0,
            (v) => state.updateSelectedProperty('thresholdVoltage', v),
          ),
          _buildField(
            '${comp.id}_mos_k',
            '跨导系数 K (A/V²)',
            comp.properties['transconductance'] ?? 0.002,
            (v) => state.updateSelectedProperty('transconductance', v),
          ),
          _buildField(
            '${comp.id}_mos_lambda',
            '沟道调制 λ',
            comp.properties['lambda'] ?? 0.02,
            (v) => state.updateSelectedProperty('lambda', v),
          ),
        ]);
        break;
      case ComponentType.ground:
        fields.add(const Text('地节点', style: TextStyle(color: Colors.white70)));
        break;
      case ComponentType.voltmeter:
        fields.add(
          const Text(
            '电压表用于观察两端节点电压，仿真中按高阻抗处理。',
            style: TextStyle(color: Colors.white70, fontSize: 12),
          ),
        );
        break;
      case ComponentType.ammeter:
        fields.add(
          const Text(
            '电流表用于观察支路电流，仿真中按 0V 电压源占位处理。',
            style: TextStyle(color: Colors.white70, fontSize: 12),
          ),
        );
        break;
      case ComponentType.switchComponent:
        final isClosed = comp.properties['isClosed'] != false;
        fields.add(
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  '闭合状态',
                  style: TextStyle(color: Colors.white54, fontSize: 12),
                ),
                Switch(
                  value: isClosed,
                  onChanged: (value) => state.isSimulationRunning
                      ? _toggleSwitchDuringSimulation(
                          context,
                          state,
                          comp,
                          value,
                        )
                      : state.updateSelectedProperty('isClosed', value),
                  activeThumbColor: Colors.tealAccent,
                  activeTrackColor: Colors.teal.withAlpha(128),
                ),
              ],
            ),
          ),
        );
        break;
    }

    fields.add(const SizedBox(height: 8));
    fields.add(
      _buildField('${comp.id}_rot', '旋转 (°)', comp.rotation, (v) {
        final rotation = v is num
            ? v.toDouble()
            : double.tryParse(v.toString());
        if (rotation != null) {
          state.updateSelectedRotation(rotation);
        }
      }),
    );

    return fields;
  }

  Future<void> _toggleSwitchDuringSimulation(
    BuildContext context,
    CanvasState state,
    CircuitComponent component,
    bool isClosed,
  ) async {
    final circuit = state.simulationCircuit;
    final previousConfig = state.simulationConfig;
    if (circuit == null || previousConfig == null) return;
    final event = state.registerSwitchEvent(component.id, isClosed);
    final config = previousConfig.copyWith(switchEvents: state.switchEvents);
    state.setSimulationLoading(true);
    final result = await DartMnaSpiceSimulator().runTransient(circuit, config);
    if (!context.mounted) return;
    if (!result.success) {
      state.rollbackSwitchEvent(event);
      state.setSimulationLoading(false);
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(result.errors.join('\n'))));
      return;
    }
    state.applySimulationResult(
      circuit,
      result,
      config: config,
      resumeAt: event.time,
    );
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          '已记录 t=${event.time.toStringAsFixed(3)} s '
          '${isClosed ? '闭合' : '断开'}事件，波形已更新。',
        ),
      ),
    );
  }

  Widget _buildSimulationReadout(
    CanvasState state,
    CircuitComponent component,
  ) {
    final voltage = state.componentVoltage(component.id);
    final current = state.componentCurrent(component.id);
    final rows = <Widget>[_readingRow('两端电压', _formatReading(voltage, 'V'))];
    if (current != null || component.type == ComponentType.ammeter) {
      rows.add(_readingRow('支路电流', _formatReading(current, 'A')));
    }
    if (component.type == ComponentType.voltmeter) {
      rows.add(_readingRow('电压表读数', _formatReading(voltage, 'V')));
    }
    if (component.type == ComponentType.ammeter) {
      rows.add(_readingRow('电流表读数', _formatReading(current, 'A')));
    }
    if (component.type == ComponentType.led) {
      rows.add(
        _readingRow('LED 状态', state.isLedLit(component.id) ? '点亮' : '熄灭'),
      );
    }
    final records = state.meterRecordsFor(component.id);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.black.withAlpha(45),
        border: Border.all(color: Colors.greenAccent.withAlpha(90)),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '当前仿真读数',
            style: TextStyle(
              color: Colors.greenAccent,
              fontWeight: FontWeight.bold,
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 6),
          ...rows,
          if (records.isNotEmpty) ...[
            const Divider(height: 14, color: Colors.white24),
            _buildMeterRecordList(records),
          ],
        ],
      ),
    );
  }

  Widget _buildMeterRecordList(List<MeterRecord> records) {
    final recent = records.length > 8
        ? records.sublist(records.length - 8)
        : records;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '本表记录 (${records.length} 条)',
          style: const TextStyle(color: Colors.amberAccent, fontSize: 12),
        ),
        const SizedBox(height: 4),
        ...recent.map(
          (record) => _readingRow(
            '${record.time.toStringAsFixed(3)} s',
            _formatReading(record.value, record.unit),
          ),
        ),
      ],
    );
  }

  Widget _readingRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(color: Colors.white54, fontSize: 11),
          ),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  String _formatReading(double? value, String unit) {
    if (value == null) return '--';
    if (unit == 'A' && value.abs() < 0.001) {
      return '${(value * 1000).toStringAsFixed(3)} mA';
    }
    return '${value.toStringAsFixed(3)} $unit';
  }

  void _showRenameDialog(
    BuildContext context,
    CanvasState state,
    CircuitComponent component,
  ) {
    final controller = TextEditingController(text: component.userName);
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: const Color(0xFF1a1a2e),
        title: const Text('修改元件名称', style: TextStyle(color: Colors.white)),
        content: TextField(
          controller: controller,
          autofocus: true,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(
            labelText: '名称',
            labelStyle: TextStyle(color: Colors.white70),
          ),
          onSubmitted: (_) {
            state.updateComponentName(component.id, controller.text);
            Navigator.pop(dialogContext);
          },
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () {
              state.updateComponentName(component.id, controller.text);
              Navigator.pop(dialogContext);
            },
            child: const Text('保存'),
          ),
        ],
      ),
    );
  }

  Widget _buildField(
    String cacheKey,
    String label,
    dynamic value,
    Function(dynamic) onChanged,
  ) {
    final controller = _getController(cacheKey, value.toString());

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(color: Colors.white54, fontSize: 12),
          ),
          const SizedBox(height: 4),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: controller,
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                  keyboardType: TextInputType.text, // 允许输入单位后缀
                  decoration: InputDecoration(
                    isDense: true,
                    filled: true,
                    fillColor: const Color(0xFF1a1a2e),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(6),
                      borderSide: const BorderSide(color: Colors.white24),
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 10,
                    ),
                  ),
                  onSubmitted: (text) => onChanged(text),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          // 为手机用户提供快捷单位按钮
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: ['p', 'n', 'u', 'm', 'k', 'Meg'].map((suffix) {
                return Padding(
                  padding: const EdgeInsets.only(right: 4),
                  child: InkWell(
                    onTap: () {
                      final text = controller.text;
                      // 如果末尾已经是字母，则替换，否则追加
                      final newText =
                          text.replaceAll(RegExp(r'[a-zA-Z]+$'), '') + suffix;
                      controller.text = newText;
                      onChanged(newText);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white10,
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        suffix,
                        style: const TextStyle(
                          color: Colors.blueAccent,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }
}

class _FileOperations extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _FileButton(
            icon: Icons.save_outlined,
            label: '保存',
            onTap: () => _saveCircuit(context),
          ),
          _FileButton(
            icon: Icons.folder_open_outlined,
            label: '打开',
            onTap: () => _openCircuit(context),
          ),
          _FileButton(
            icon: Icons.share_outlined,
            label: '分享',
            onTap: () => _shareCircuit(context),
          ),
        ],
      ),
    );
  }

  void _saveCircuit(BuildContext context) async {
    final state = context.read<CanvasState>(); // 已修正 << 为 <
    if (state.components.isEmpty) {
      _showSnack(context, '画布为空，无需保存');
      return;
    }

    final name = 'circuit_${DateTime.now().millisecondsSinceEpoch}';
    try {
      await CircuitStorage.saveCircuit(name, state.components, state.wires);
      if (!context.mounted) return;
      _showSnack(context, '已保存');
    } catch (e) {
      if (!context.mounted) return;
      _showSnack(context, '保存失败: $e');
    }
  }

  void _openCircuit(BuildContext context) async {
    final state = context.read<CanvasState>(); // 已修正 << 为 <
    try {
      final files = await CircuitStorage.listCircuits();
      if (files.isEmpty) {
        if (!context.mounted) return;
        _showSnack(context, '没有保存的电路');
        return;
      }

      if (!context.mounted) return;

      showDialog(
        context: context,
        builder: (dialogContext) => AlertDialog(
          backgroundColor: const Color(0xFF1a1a2e),
          title: const Text('打开电路', style: TextStyle(color: Colors.white)),
          content: SizedBox(
            width: 300,
            height: 200,
            child: ListView.builder(
              itemCount: files.length,
              itemBuilder: (listViewContext, index) {
                final file = files[index];
                final name = file.split('/').last;
                return ListTile(
                  title: Text(
                    name,
                    style: const TextStyle(color: Colors.white),
                  ),
                  onTap: () async {
                    Navigator.pop(dialogContext);
                    final data = await CircuitStorage.loadCircuit(file);

                    if (data != null && context.mounted) {
                      state.loadFromData(data);
                      _showSnack(context, '已打开电路');
                    }
                  },
                );
              },
            ),
          ),
        ),
      );
    } catch (e) {
      if (!context.mounted) return;
      _showSnack(context, '读取失败: $e');
    }
  }

  void _shareCircuit(BuildContext context) async {
    final state = context.read<CanvasState>(); // 已修正 << 为 <
    if (state.components.isEmpty) {
      _showSnack(context, '画布为空');
      return;
    }

    try {
      final name = 'circuit_${DateTime.now().millisecondsSinceEpoch}';
      final path = await CircuitStorage.saveCircuit(
        name,
        state.components,
        state.wires,
      );
      await CircuitStorage.shareCircuit(path);
    } catch (e) {
      if (!context.mounted) return;
      _showSnack(context, '分享失败: $e');
    }
  }

  void _showSnack(BuildContext context, String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }
}

class _FileButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _FileButton({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: Colors.white70, size: 20),
          const SizedBox(height: 2),
          Text(
            label,
            style: const TextStyle(color: Colors.white54, fontSize: 10),
          ),
        ],
      ),
    );
  }
}
