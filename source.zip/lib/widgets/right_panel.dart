import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/component.dart';
import '../state/canvas_state.dart';
import 'waveform_viewer.dart';
import '../spice/simulation_result.dart';
import 'xy_curve_viewer.dart';

class RightPanel extends StatelessWidget {
  const RightPanel({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF0D1117),
        border: Border(left: BorderSide(color: Colors.white10)),
      ),
      child: Column(
        children: [
          _SimulationControls(),
          const Divider(height: 1, color: Colors.white10),
          const Expanded(child: _PropertySection()),
          const Divider(height: 1, color: Colors.white10),
          _FileOperations(),
        ],
      ),
    );
  }
}

class _SimulationControls extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<CanvasState>(
      builder: (context, state, child) => Container(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            SizedBox(
              width: double.infinity,
              height: 45,
              child: ElevatedButton.icon(
                onPressed: state.isSimulationLoading ? null : (state.isSimulationRunning ? state.stopSimulation : () => _runSimulation(context, state)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: state.isSimulationRunning ? Colors.redAccent : Colors.teal.shade700,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                icon: Icon(state.isSimulationRunning ? Icons.stop : Icons.play_arrow),
                label: Text(state.isSimulationRunning ? '停止仿真' : '运行仿真'),
              ),
            ),
            // 新增：仿真完成后显示“查看结果”按钮
            if (state.simulationResult != null)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: TextButton.icon(
                  onPressed: () => _showResultDialog(context, state.simulationResult!),
                  icon: const Icon(Icons.analytics),
                  label: const Text('分析仿真结果'),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _runSimulation(BuildContext context, CanvasState state) async {
    // ... 这里保持你原有的仿真逻辑 ...
  }

  void _showResultDialog(BuildContext context, SimulationResult result) {
    showDialog(
      context: context,
      builder: (context) => DefaultTabController(
        length: 3, // 扩展为3个Tab
        child: AlertDialog(
          backgroundColor: const Color(0xFF1a1a2e),
          title: const Text('仿真分析', style: TextStyle(color: Colors.white)),
          content: SizedBox(
            width: 600, height: 400,
            child: Column(
              children: [
                const TabBar(tabs: [Tab(text: '电压'), Tab(text: '电流'), Tab(text: '伏安特性')]),
                Expanded(
                  child: TabBarView(children: [
                    WaveformViewer(timeData: result.time, voltageSeries: result.nodeVoltages),
                    WaveformViewer(timeData: result.time, voltageSeries: result.branchCurrents, unit: 'A'),
                    _buildViCurvePage(result), // 调用伏安特性页面
                  ]),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // 核心修改：生成伏安特性曲线页面
  Widget _buildViCurvePage(SimulationResult result) {
    // 假设取第一个节点电压作为横轴，第一个分支电流作为纵轴
    final voltData = result.nodeVoltages.values.first;
    final currData = result.branchCurrents.values.first;
    
    return XyCurveViewer(
      xData: voltData,
      yData: currData,
      xLabel: 'V',
      yLabel: 'A',
      title: 'V-I 伏安特性曲线',
    );
  }
}

class _PropertySection extends StatefulWidget {
  const _PropertySection();
  @override
  State<_PropertySection> createState() => _PropertySectionState();
}

class _PropertySectionState extends State<_PropertySection> {
  @override
  Widget build(BuildContext context) {
    return Consumer<CanvasState>(
      builder: (context, state, child) {
        final selected = state.selectedComponent;
        if (selected == null) return const Center(child: Text('选中元件以编辑', style: TextStyle(color: Colors.white30)));
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text(selected.userName, style: const TextStyle(color: Colors.white, fontSize: 18)),
            const SizedBox(height: 10),
            ..._buildFields(state, selected),
          ],
        );
      },
    );
  }

  List<Widget> _buildFields(CanvasState state, CircuitComponent comp) {
    return [ListTile(title: Text("类型: ${comp.displayName}", style: const TextStyle(color: Colors.white54)))];
  }
}

class _FileOperations extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          IconButton(icon: const Icon(Icons.save, color: Colors.white54), onPressed: () {}),
          IconButton(icon: const Icon(Icons.folder_open, color: Colors.white54), onPressed: () {}),
        ],
      ),
    );
  }
}