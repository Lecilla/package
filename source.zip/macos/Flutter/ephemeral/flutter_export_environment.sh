#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=C:\Users\i\Downloads\flutter_windows_3.41.9-stable\flutter"
export "FLUTTER_APPLICATION_PATH=D:\软件\xwechat_files\wxid_drqq4fe6mkcv22_58cc\msg\file\2026-06\电路仿真APP_交互记录修复版_20260619(8)\电路仿真APP_交互记录修复版_20260619"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
