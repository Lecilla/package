class SimulationResult {
  final bool success;
  final List<double> time;
  final Map<String, List<double>> nodeVoltages;
  final Map<String, List<double>> branchCurrents;
  final String rawOutput;
  final List<String> errors;
  final List<String> warnings;
  final String netlist;
  final Map<String, Map<String, String>> componentNodeMap; // componentId -> {pinId: nodeName}

  const SimulationResult({
    required this.success,
    this.time = const [],
    this.nodeVoltages = const {},
    this.branchCurrents = const {},
    this.rawOutput = '',
    this.errors = const [],
    this.warnings = const [],
    this.netlist = '',
    this.componentNodeMap = const {},
  });

  Map<String, dynamic> toJson() => {
    'success': success,
    'time': time,
    'nodeVoltages': nodeVoltages,
    'branchCurrents': branchCurrents,
    'rawOutput': rawOutput,
    'errors': errors,
    'warnings': warnings,
    'netlist': netlist,
    'componentNodeMap': componentNodeMap,
  };

  factory SimulationResult.fromJson(Map<String, dynamic> json) {
    Map<String, List<double>> readSeries(String key) {
      final raw = Map<String, dynamic>.from(json[key] as Map? ?? {});
      return raw.map(
        (name, values) => MapEntry(
          name,
          (values as List).map((value) => (value as num).toDouble()).toList(),
        ),
      );
    }

    final rawNodeMap = Map<String, dynamic>.from(json['componentNodeMap'] as Map? ?? {});
    final componentNodeMap = rawNodeMap.map(
      (k, v) => MapEntry(k, Map<String, String>.from(v as Map)),
    );

    return SimulationResult(
      success: json['success'] as bool? ?? false,
      time: (json['time'] as List? ?? const [])
          .map((value) => (value as num).toDouble())
          .toList(),
      nodeVoltages: readSeries('nodeVoltages'),
      branchCurrents: readSeries('branchCurrents'),
      rawOutput: json['rawOutput'] as String? ?? '',
      errors: (json['errors'] as List? ?? const []).cast<String>(),
      warnings: (json['warnings'] as List? ?? const []).cast<String>(),
      netlist: json['netlist'] as String? ?? '',
      componentNodeMap: componentNodeMap,
    );
  }
}
