import 'spice_element.dart';

class SpiceWire {
  final String id;
  final String fromNode;
  final String toNode;
  final String fromPin;
  final String toPin;

  const SpiceWire({
    required this.id,
    required this.fromNode,
    required this.toNode,
    required this.fromPin,
    required this.toPin,
  });
}

class CircuitModel {
  final List<SpiceElement> elements;
  final List<SpiceWire> wires;
  final Set<String> nodes;
  final String? groundNode;
  final List<String> warnings;
  final Map<String, Map<String, String>> componentNodeMap; // componentId -> {pinId: nodeName}

  const CircuitModel({
    required this.elements,
    required this.wires,
    required this.nodes,
    this.groundNode,
    this.warnings = const [],
    this.componentNodeMap = const {},
  });

  List<String> get observableNodes {
    final result = nodes.where((node) => node != '0').toList()..sort();
    return result;
  }
}
