import 'simulation_result.dart';

class SpiceOutputParser {
  SimulationResult parse({
    required String rawOutput,
    required String netlist,
    List<String> warnings = const [],
  }) {
    final lines = rawOutput.split(RegExp(r'\r?\n'));
    final time = <double>[];
    final voltages = <String, List<double>>{};
    final currents = <String, List<double>>{};
    var headers = <String>[];

    for (final line in lines) {
      final trimmed = line.trim();
      if (trimmed.isEmpty) {
        continue;
      }
      final parts = trimmed.split(RegExp(r'\s+'));
      if (parts.any((part) => part.toLowerCase() == 'time')) {
        headers = parts;
        for (final header in headers.skip(1)) {
          if (header.toLowerCase().startsWith('i(')) {
            currents.putIfAbsent(header, () => <double>[]);
          } else {
            voltages.putIfAbsent(header, () => <double>[]);
          }
        }
        continue;
      }
      if (headers.isEmpty || parts.length < headers.length) {
        continue;
      }

      final parsedTime = double.tryParse(parts.first);
      if (parsedTime == null) {
        continue;
      }
      time.add(parsedTime);
      for (var i = 1; i < headers.length; i++) {
        final header = headers[i];
        final value = double.tryParse(parts[i]) ?? 0;
        if (header.toLowerCase().startsWith('i(')) {
          currents[header]?.add(value);
        } else {
          voltages[header]?.add(value);
        }
      }
    }

    return SimulationResult(
      success: time.isNotEmpty,
      time: time,
      nodeVoltages: voltages,
      branchCurrents: currents,
      rawOutput: rawOutput,
      warnings: warnings,
      errors: time.isEmpty ? const ['未能从 ngspice 输出中解析到波形数据。'] : const [],
      netlist: netlist,
    );
  }
}
