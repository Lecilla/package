import '../models/component.dart';
import '../models/wire.dart';
import '../spice/circuit_model.dart';
import '../spice/spice_element.dart';
import '../spice/spice_value_parser.dart';

class CircuitMappingException implements Exception {
  final List<String> errors;
  final List<String> warnings;

  const CircuitMappingException(this.errors, [this.warnings = const []]);

  @override
  String toString() => errors.join('\n');
}

class CircuitToSpiceMapper {
  CircuitModel map(List<CircuitComponent> components, List<Wire> wires) {
    final errors = <String>[];
    final warnings = <String>[];

    if (components.isEmpty) {
      throw const CircuitMappingException(['当前画布没有元件，无法仿真。']);
    }

    if (!components.any(
      (component) => component.type == ComponentType.ground,
    )) {
      errors.add('电路缺少接地 GND。SPICE 仿真必须至少有一个 0 节点。');
    }

    final pinKeys = <String>{};
    for (final component in components) {
      for (final pin in component.pins) {
        pinKeys.add(_pinKey(component.id, pin.id));
      }
    }

    final unionFind = _UnionFind(pinKeys);
    final connectedPins = <String>{};

    for (final wire in wires) {
      final fromKey = _pinKey(wire.fromComponentId, wire.fromPointId);
      final toKey = _pinKey(wire.toComponentId, wire.toPointId);
      if (!pinKeys.contains(fromKey) || !pinKeys.contains(toKey)) {
        errors.add('连线 ${wire.id} 引用了不存在的元件引脚，请检查连线。');
        continue;
      }
      unionFind.union(fromKey, toKey);
      connectedPins.add(fromKey);
      connectedPins.add(toKey);
    }

    final groundRoots = <String>{};
    for (final component in components.where(
      (c) => c.type == ComponentType.ground,
    )) {
      for (final pin in component.pins) {
        groundRoots.add(unionFind.find(_pinKey(component.id, pin.id)));
      }
    }

    final rootToNode = <String, String>{};
    var nextNode = 1;
    for (final key in pinKeys) {
      final root = unionFind.find(key);
      if (groundRoots.contains(root)) {
        rootToNode[root] = '0';
      } else {
        rootToNode.putIfAbsent(root, () => 'n${nextNode++}');
      }
    }

    final spiceWires = <SpiceWire>[];
    for (final wire in wires) {
      final fromKey = _pinKey(wire.fromComponentId, wire.fromPointId);
      final toKey = _pinKey(wire.toComponentId, wire.toPointId);
      if (!pinKeys.contains(fromKey) || !pinKeys.contains(toKey)) {
        continue;
      }
      spiceWires.add(
        SpiceWire(
          id: wire.id,
          fromNode: rootToNode[unionFind.find(fromKey)]!,
          toNode: rootToNode[unionFind.find(toKey)]!,
          fromPin: fromKey,
          toPin: toKey,
        ),
      );
    }

    final elements = <SpiceElement>[];
    final nameCounters = <String, int>{};
    final componentNodeMap = <String, Map<String, String>>{};

    for (final component in components) {
      final type = component.type;
      
      // 保存引脚到节点的映射
      final pinMap = <String, String>{};
      for (final pin in component.pins) {
        final key = _pinKey(component.id, pin.id);
        final root = unionFind.find(key);
        pinMap[pin.id] = rootToNode[root] ?? '0';
      }
      
      final prefix = _prefixFor(type);
      final count = (nameCounters[prefix] ?? 0) + 1;
      nameCounters[prefix] = count;
      final spiceName = prefix != null ? '$prefix$count' : 'U$count';
      pinMap['__name__'] = spiceName;

      componentNodeMap[component.id] = pinMap;

      if (type != ComponentType.ground && component.pins.length < 2) {
        errors.add(
          '元件 ${component.displayName}(${component.id}) 存在悬空端点，请检查连线。',
        );
        continue;
      }

      for (final pin in component.pins) {
        final key = _pinKey(component.id, pin.id);
        if (type != ComponentType.ground && !connectedPins.contains(key)) {
          errors.add(
            '元件 ${component.displayName}(${component.id}) 存在悬空端点，请检查连线。',
          );
          break;
        }
      }

      final prefix = _prefixFor(type);
      if (prefix == null) {
        errors.add('当前暂不支持 ${component.displayName} 类型元件仿真。');
        continue;
      }

      final value = _readValue(component, warnings, errors);
      if (value == null && type != ComponentType.ground) {
        continue;
      }

      final spiceName = componentNodeMap[component.id]?['__name__'] ?? '${prefix}X';

      final node1 = component.pins.isNotEmpty
          ? rootToNode[unionFind.find(
              _pinKey(component.id, component.pins.first.id),
            )]
          : null;
      final node2 = component.pins.length > 1
          ? rootToNode[unionFind.find(
              _pinKey(component.id, component.pins[1].id),
            )]
          : null;

      elements.add(
        SpiceElement(
          id: component.id,
          type: component.spiceType,
          name: spiceName,
          node1: type == ComponentType.ground ? '0' : node1,
          node2: node2,
          value: value ?? '0',
          params: Map<String, dynamic>.from(component.properties),
        ),
      );
    }

    final nodes = rootToNode.values.toSet();
    if (!nodes.contains('0')) {
      errors.add('电路缺少接地 GND。SPICE 仿真必须至少有一个 0 节点。');
    }
    if (!nodes.any((node) => node != '0')) {
      errors.add('没有找到可输出的节点电压。');
    }

    if (errors.isNotEmpty) {
      throw CircuitMappingException(errors.toSet().toList(), warnings);
    }

    return CircuitModel(
      elements: elements,
      wires: spiceWires,
      nodes: nodes,
      groundNode: '0',
      warnings: warnings,
      componentNodeMap: componentNodeMap,
    );
  }

  String? _readValue(
    CircuitComponent component,
    List<String> warnings,
    List<String> errors,
  ) {
    if (component.type == ComponentType.ground) {
      return '0';
    }
    if (component.type == ComponentType.voltmeter ||
        component.type == ComponentType.ammeter) {
      return '0';
    }
    if (component.type == ComponentType.switchComponent) {
      final isClosed = component.properties['isClosed'] != false;
      return (isClosed
                  ? component.properties['onResistance']
                  : component.properties['offResistance'])
              ?.toString() ??
          (isClosed ? '1m' : '1Meg');
    }

    final key = switch (component.type) {
      ComponentType.resistor => 'resistance',
      ComponentType.capacitor => 'capacitance',
      ComponentType.inductor => 'inductance',
      ComponentType.voltageSource => 'voltage',
      ComponentType.led => 'forwardVoltage',
      ComponentType.ground => '',
      ComponentType.voltmeter => '',
      ComponentType.ammeter => '',
      ComponentType.switchComponent => '',
    };

    final raw = component.properties[key];
    if (raw == null || raw.toString().trim().isEmpty) {
      errors.add(
        '元件 ${component.displayName}(${component.id}) 的参数为空，请先在属性面板中设置参数。',
      );
      return null;
    }

    try {
      final parsed = SpiceValueParser.parse(raw);
      warnings.addAll(parsed.warnings);
      return parsed.normalized;
    } on FormatException {
      errors.add(
        '元件 ${component.displayName}(${component.id}) 的参数格式无法识别，例如 1k、10u、5m 这类格式才是合法格式。',
      );
      return null;
    }
  }

  String? _prefixFor(ComponentType type) {
    switch (type) {
      case ComponentType.resistor:
        return 'R';
      case ComponentType.capacitor:
        return 'C';
      case ComponentType.inductor:
        return 'L';
      case ComponentType.voltageSource:
        return 'V';
      case ComponentType.led:
        return 'D';
      case ComponentType.ground:
        return 'GND';
      case ComponentType.voltmeter:
        return 'VM';
      case ComponentType.ammeter:
        return 'AM';
      case ComponentType.switchComponent:
        return 'SW';
    }
  }

  String _pinKey(String componentId, String pinId) => '$componentId:$pinId';
}

class _UnionFind {
  final Map<String, String> _parent = {};

  _UnionFind(Iterable<String> keys) {
    for (final key in keys) {
      _parent[key] = key;
    }
  }

  String find(String key) {
    final parent = _parent[key] ?? key;
    if (parent == key) {
      return key;
    }
    final root = find(parent);
    _parent[key] = root;
    return root;
  }

  void union(String a, String b) {
    final rootA = find(a);
    final rootB = find(b);
    if (rootA != rootB) {
      _parent[rootB] = rootA;
    }
  }
}
